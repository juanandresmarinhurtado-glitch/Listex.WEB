const fs = require('fs');

// 1. Fix backend server.js
let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

// Fix the attribute values check which throws if false
serverJs = serverJs.replace(
    'if (v.product_template_attribute_value_ids.length > 0)',
    'if (v.product_template_attribute_value_ids && v.product_template_attribute_value_ids.length > 0)'
);

// Add better error logging
serverJs = serverJs.replace(
    'res.status(500).json({ error: error.message });',
    'console.error("GET Product Error:", error); res.status(500).json({ error: error.message || String(error) });'
);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');


// 2. Fix frontend proveedores.html
let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// Make the toast show the exact error from backend if any
const catchRegex = /} catch \(err\) {\s*showToast\('Error cargando producto para edición'\);\s*}/;
const newCatch = `
                } else {
                    throw new Error(data.error || "Error desconocido");
                }
            } catch (err) {
                showToast('Error cargando: ' + err.message);
                console.error("Edit Modal Error:", err);
            }
`;

html = html.replace(catchRegex, newCatch);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("Error handling improved and bugs patched.");
