const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

common.methodCall('authenticate', [db, username, password, {}], function (error, uid) {
    if (error) return console.error(error);

    models.methodCall('execute_kw', [db, uid, password, 'stock.location', 'search_read', [[['usage', '=', 'internal']], ['id', 'complete_name']], 0, 5], function (err, result) {
        if (err) return console.error(err);
        console.log("Locations:", result);
    });

    models.methodCall('execute_kw', [db, uid, password, 'product.public.category', 'search_read', [[], ['id', 'name']]], function (err, result) {
        if (err) return console.error(err);
        console.log("Categories:", result);
    });
});
