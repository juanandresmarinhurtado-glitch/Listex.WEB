/* =============================================
   PRODUCT PAGE LOGIC - Listex Mayorista
   product-page.js
   ============================================= */

(function () {
    'use strict';

    let currentVariants = [];
    let baseProduct = null;
    let attributesData = {}; // { 'Color': ['Rojo', 'Azul'], 'Talla': ['S', 'M'] }
    let selectedState = {};  // { 'Color': 'Rojo', 'Talla': 'M' }
    let images = [];

    // Trigger on DOMContentLoaded and check if catalog is ready
    document.addEventListener('DOMContentLoaded', () => {
        if (typeof productIndex !== 'undefined' && Object.keys(productIndex).length > 0) {
            initProductPage();
        } else {
            // Wait for app.js to build productIndex
            document.addEventListener('CatalogLoaded', initProductPage);
        }
    });

    function initProductPage() {
        const urlParams = new URLSearchParams(window.location.search);
        const handleParam = urlParams.get('handle');

        if (!handleParam) {
            showNotFound();
            return;
        }

        const handle = decodeURIComponent(handleParam);
        
        if (productIndex && productIndex[handle]) {
            currentVariants = productIndex[handle];
        } else if (typeof allProducts !== 'undefined') {
            currentVariants = allProducts.filter(p => (p.nombre || '').toLowerCase() === handle.toLowerCase());
        }

        if (!currentVariants || currentVariants.length === 0) {
            showNotFound();
            return;
        }

        baseProduct = currentVariants[0];
        processVariantsData();
        renderProductPage();
    }

    function processVariantsData() {
        attributesData = {};
        images = [];

        currentVariants.forEach(v => {
            if (v.imagen_url && !images.includes(v.imagen_url)) {
                images.push(v.imagen_url);
            }
            if (v.variantes && Array.isArray(v.variantes)) {
                v.variantes.forEach(attr => {
                    const key = (attr.atributo || '').trim();
                    const val = (attr.valor || '').trim();
                    if (!key || !val) return;
                    
                    if (!attributesData[key]) {
                        attributesData[key] = [];
                    }
                    if (!attributesData[key].includes(val)) {
                        attributesData[key].push(val);
                    }
                });
            }
        });

        if (images.length === 0) images.push('');

        // Initialize selected state with first available options
        for (const attr in attributesData) {
            if (attributesData[attr].length > 0) {
                selectedState[attr] = attributesData[attr][0];
            }
        }
    }

    function renderProductPage() {
        const container = document.getElementById('product-page-container');
        if (!container) return;

        const currency = baseProduct.moneda || '$';
        const basePrice = parseFloat(baseProduct.precio_base) || 0;

        let html = '<div class="product-page-layout">';
        
        // LEFT: Image Gallery
        html += '<div class="product-gallery">';
        html += `<div class="product-main-image" id="pageMainImage">
            ${images[0] ? `<img src="${escapeHTML(images[0])}" alt="Producto">` : `<div style="color:var(--gray-400)">Sin imagen</div>`}
        </div>`;
        
        if (images.length > 1) {
            html += '<div class="product-thumbnails">';
            images.forEach((img, idx) => {
                html += `<div class="product-thumbnail ${idx === 0 ? 'active' : ''}" onclick="window.switchPageImage('${escapeHTML(img)}', this)">
                    <img src="${escapeHTML(img)}" alt="Miniatura">
                </div>`;
            });
            html += '</div>';
        }
        html += '</div>';

        // RIGHT: Product Info
        html += '<div class="product-info">';
        html += `<div class="product-category">${escapeHTML(baseProduct.categoria_principal || '')}</div>`;
        html += `<h1 class="product-title">${escapeHTML(baseProduct.nombre)}</h1>`;
        
        html += `<div class="product-price-container">
            <span class="product-price" id="pageProductPrice">${currency}${formatPrice(basePrice)}</span>
        </div>`;

        if (baseProduct.descripcion) {
            html += `<div class="product-description">${escapeHTML(baseProduct.descripcion)}</div>`;
        }

        if (baseProduct.tarifas_multiples && baseProduct.tarifas_multiples.length > 0) {
            html += '<div class="product-tariffs">';
            html += '<div class="product-tariffs-title">Precios por escala:</div>';
            html += '<div class="product-tariffs-list">';
            baseProduct.tarifas_multiples.forEach(t => {
                html += `<span class="tariff-badge">${escapeHTML(t.nombre_tarifa)}: ${currency}${formatPrice(t.precio_fijo || t.precio || 0)}</span>`;
            });
            html += '</div></div>';
        }

        // Variants Container
        html += '<div class="product-variants" id="pageVariantsContainer">';
        // Will be populated dynamically based on state
        html += '</div>';

        // Actions
        html += '<div class="product-actions">';
        html += `<div class="qty-selector">
            <button class="qty-btn" onclick="window.changePageQty(-1)">-</button>
            <input type="number" id="pageQtyInput" class="qty-input" value="1" min="1" max="9999" onchange="window.validatePageQty()">
            <button class="qty-btn" onclick="window.changePageQty(1)">+</button>
        </div>`;
        html += `<button class="add-to-cart-btn" onclick="window.addToCartFromPage()">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
            Añadir a Cotización
        </button>`;
        html += '</div>';

        html += '</div>'; // End info
        html += '</div>'; // End layout

        container.innerHTML = html;

        // Render variants initially
        renderVariantButtons();
        
        // Try to update price based on initial variant selection
        updatePriceDisplay();
    }

    function renderVariantButtons() {
        const container = document.getElementById('pageVariantsContainer');
        if (!container) return;

        // --- Custom Logic for Docena Cerrada / Bulto ---
        // If 'Presentacin' or 'Presentacion' is selected as 'Docena cerrada' or 'Bulto',
        // we hide all other attributes and force them to 'Surtido' or similar if available.
        let isWholesaleSpecial = false;
        
        for (const attr in selectedState) {
            if (attr.toLowerCase().includes('presentaci')) {
                const val = (selectedState[attr] || '').toLowerCase();
                if (val === 'docena cerrada' || val === 'bulto') {
                    isWholesaleSpecial = true;
                    break;
                }
            }
        }

        // If wholesale special is active, automatically select 'Surtido' for other attributes
        if (isWholesaleSpecial) {
            for (const attr in attributesData) {
                if (!attr.toLowerCase().includes('presentaci')) {
                    // Try to find a value that says "surtido"
                    const surtidoVal = attributesData[attr].find(v => v.toLowerCase().includes('surtido'));
                    if (surtidoVal) {
                        selectedState[attr] = surtidoVal;
                    }
                }
            }
        }
        // ------------------------------------------------

        let html = '';
        const attrKeys = Object.keys(attributesData);

        if (attrKeys.length === 0) {
            container.style.display = 'none';
            return;
        }

        attrKeys.forEach(attr => {
            // Hide non-presentation attributes if wholesale special is active
            if (isWholesaleSpecial && !attr.toLowerCase().includes('presentaci')) {
                return; 
            }

            html += `<div class="variant-group">`;
            html += `<div class="variant-label">${escapeHTML(attr)} <span class="variant-selected-value">${escapeHTML(selectedState[attr] || '')}</span></div>`;
            html += `<div class="variant-buttons">`;
            
            attributesData[attr].forEach(val => {
                const isActive = selectedState[attr] === val;
                html += `<button class="variant-btn ${isActive ? 'active' : ''}" 
                    onclick="window.selectVariantOption('${escapeHTML(attr)}', '${escapeHTML(val)}')">
                    ${escapeHTML(val)}
                </button>`;
            });
            
            html += `</div></div>`;
        });

        container.innerHTML = html;
    }

    window.selectVariantOption = function(attr, value) {
        selectedState[attr] = value;
        renderVariantButtons(); // Re-render to update active states and apply wholesale logic
        updatePriceDisplay();
    };

    function updatePriceDisplay() {
        const priceEl = document.getElementById('pageProductPrice');
        if (!priceEl) return;

        const matched = findMatchingVariant();
        if (matched) {
            const price = parseFloat(matched.precio_base) || 0;
            const currency = matched.moneda || '$';
            priceEl.textContent = `${currency}${formatPrice(price)}`;
            
            // If the matching variant has a specific image, show it
            if (matched.imagen_url) {
                window.switchPageImage(matched.imagen_url);
            }
        }
    }

    function findMatchingVariant() {
        return currentVariants.find(v => {
            if (!v.variantes || v.variantes.length === 0) return true; // Base product without strict variants
            
            // Check if all selectedState values match the variant's attributes
            for (const attr in selectedState) {
                const variantHasAttr = v.variantes.find(va => va.atributo === attr && va.valor === selectedState[attr]);
                // If the variant lacks the attribute or it has a different value, it's not a match
                if (!variantHasAttr) return false;
            }
            return true;
        }) || currentVariants[0]; // fallback
    }

    window.switchPageImage = function(src, thumbnailEl) {
        const mainEl = document.getElementById('pageMainImage');
        if (mainEl && src) {
            mainEl.innerHTML = `<img src="${escapeHTML(src)}" alt="Producto">`;
        }
        if (thumbnailEl) {
            document.querySelectorAll('.product-thumbnail').forEach(t => t.classList.remove('active'));
            thumbnailEl.classList.add('active');
        } else {
            // Find the thumbnail that matches the src
            document.querySelectorAll('.product-thumbnail').forEach(t => {
                t.classList.remove('active');
                const img = t.querySelector('img');
                if (img && img.getAttribute('src') === src) {
                    t.classList.add('active');
                }
            });
        }
    };

    window.changePageQty = function(delta) {
        const input = document.getElementById('pageQtyInput');
        if (!input) return;
        let val = parseInt(input.value) || 1;
        val += delta;
        if (val < 1) val = 1;
        if (val > 9999) val = 9999;
        input.value = val;
    };

    window.validatePageQty = function() {
        const input = document.getElementById('pageQtyInput');
        if (!input) return;
        let val = parseInt(input.value);
        if (isNaN(val) || val < 1) val = 1;
        if (val > 9999) val = 9999;
        input.value = val;
    };

    window.addToCartFromPage = function() {
        const input = document.getElementById('pageQtyInput');
        const qty = parseInt(input ? input.value : 1) || 1;
        
        const matched = findMatchingVariant();
        const productToAdd = matched || baseProduct;
        
        if (typeof addToCart === 'function') {
            addToCart(productToAdd, qty);
            
            // Optional: Show the drawer
            const overlay = document.getElementById('cart-drawer-overlay');
            const drawer = document.getElementById('cart-drawer');
            if (overlay) overlay.classList.add('active');
            if (drawer) drawer.classList.add('active');
        } else {
            if (typeof showToast === 'function') showToast('Funcionalidad de carrito no disponible', 'error');
        }
    };

    function showNotFound() {
        const container = document.getElementById('product-page-container');
        if (container) {
            container.innerHTML = `
                <div class="product-not-found">
                    <h2>Producto no encontrado</h2>
                    <p>Lo sentimos, el producto que buscas no existe o ha sido eliminado.</p>
                    <a href="index.html" class="btn btn-primary">Volver al catálogo</a>
                </div>
            `;
        }
    }

    function escapeHTML(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

})();
