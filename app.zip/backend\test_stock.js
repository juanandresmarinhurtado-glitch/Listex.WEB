const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        const variants = await executeKw('product.product', 'search_read', [
            [['qty_available', '=', 0]],
            ['id', 'name', 'qty_available']
        ], { limit: 1 });
        
        if (variants.length === 0) {
            console.log("No variants found");
            return;
        }
        
        const variantId = variants[0].id;
        console.log("Testing on variant:", variantId, variants[0].name);
        
        const stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal']]], { fields: ['id', 'complete_name'], limit: 1 });
        console.log("Location found:", stockLocations[0]);
        const locId = stockLocations[0].id;
        
        const existingQuant = await executeKw('stock.quant', 'search_read', [[['product_id', '=', variantId], ['location_id', '=', locId]]], { fields: ['id'], limit: 1 });
        
        if (existingQuant.length > 0) {
            await executeKw('stock.quant', 'write', [[existingQuant[0].id], { inventory_quantity: 15 }]);
            await executeKw('stock.quant', 'action_apply_inventory', [[existingQuant[0].id]]);
            console.log("Quant updated and applied");
        } else {
            const quantId = await executeKw('stock.quant', 'create', [{ product_id: variantId, location_id: locId, inventory_quantity: 15 }]);
            await executeKw('stock.quant', 'action_apply_inventory', [[quantId]]);
            console.log("Quant created and applied:", quantId);
        }
        
        const check = await executeKw('product.product', 'search_read', [
            [['id', '=', variantId]],
            ['qty_available']
        ]);
        console.log("Final qty_available:", check[0].qty_available);
        
    } catch (e) {
        console.error("Error:", e);
    }
});
