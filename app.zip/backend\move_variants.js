const fs = require('fs');

let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

const variantManagerHTML = `
    <!-- Variants Manager (Visible only in Edit Mode) -->
    <div id="variants-manager-section" class="form-section hidden" style="margin-top:30px; grid-column:1 / -1;">
        <h3><ion-icon name="images-outline"></ion-icon> Variantes y Stock</h3>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 15px;">Sube fotos exclusivas para cada variante y actualiza tu inventario disponible en tiempo real.</p>
        <div id="inline-variants-list" style="display:flex; flex-direction:column; gap:15px;"></div>
    </div>
`;

// Remove ALL occurrences of variantManagerHTML (ignoring whitespace variations)
const removeRegex = /<!-- Variants Manager \(Visible only in Edit Mode\) -->[\s\S]*?<div id="inline-variants-list"[^>]*><\/div>\s*<\/div>/g;
html = html.replace(removeRegex, '');

// Now inject it correctly BEFORE the create product button
const btnRegex = /<button type="submit"[^>]*id="btn-create-product"[^>]*>/;
html = html.replace(btnRegex, (match) => variantManagerHTML + '\n                            ' + match);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("Variants moved to correct place.");
