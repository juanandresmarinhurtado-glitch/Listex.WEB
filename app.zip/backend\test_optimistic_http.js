const http = require('http');

async function test() {
    const postData = JSON.stringify({
        email: 'juanandresmarinhurtado@gmail.com',
        password: 'Seguridad400%'
    });

    const loginReq = http.request({
        hostname: 'localhost',
        port: 3000,
        path: '/api/supplier/login',
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData) }
    }, res => {
        let body = '';
        res.on('data', d => body += d);
        res.on('end', () => {
            const loginData = JSON.parse(body);
            console.log("Login:", loginData);
            if(!loginData.token) return;
            
            const prodData = JSON.stringify({
                name: "Test Optimistic", cost: 10, priceUnidad: 20, isStorable: true,
                customAttributes: [{ name: "Talla", values: ["S", "M"] }]
            });
            
            const createReq = http.request({
                hostname: 'localhost', port: 3000, path: '/api/supplier/products', method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(prodData), 'Authorization': 'Bearer ' + loginData.token }
            }, res2 => {
                let body2 = '';
                res2.on('data', d => body2 += d);
                res2.on('end', () => {
                    const createData = JSON.parse(body2);
                    console.log("Create:", createData);
                    
                    if(createData.productId) {
                        http.get({
                            hostname: 'localhost', port: 3000, path: '/api/supplier/products/' + createData.productId,
                            headers: { 'Authorization': 'Bearer ' + loginData.token }
                        }, res3 => {
                            let body3 = '';
                            res3.on('data', d => body3 += d);
                            res3.on('end', () => {
                                console.log("Get:", JSON.parse(body3));
                            });
                        });
                    }
                });
            });
            createReq.write(prodData); createReq.end();
        });
    });
    loginReq.write(postData); loginReq.end();
}
test();
