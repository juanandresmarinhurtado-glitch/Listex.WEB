$baseUrl = "http://localhost:3000"

Write-Host "--- Testing /api/cart/create ---"
try {
    $create = Invoke-RestMethod -Uri "$baseUrl/api/cart/create" -Method Post
    Write-Host "Create Result:"
    $create | ConvertTo-Json
    
    if ($create.success) {
        $orderId = $create.order_id
        Write-Host "--- Testing /api/cart/add-line ---"
        $body = @{
            order_id = $orderId
            product_id = "31599"
            quantity = 1
        } | ConvertTo-Json
        
        $add = Invoke-RestMethod -Uri "$baseUrl/api/cart/add-line" -Method Post -ContentType "application/json" -Body $body
        Write-Host "Add Result:"
        $add | ConvertTo-Json
    }
} catch {
    Write-Error "Request failed: $_"
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $reader.BaseStream.Position = 0
        $body = $reader.ReadToEnd()
        Write-Host "Error Body: $body"
    }
}
