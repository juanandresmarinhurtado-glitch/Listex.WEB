const express = require('express');
const router = express.Router();
const { executeKw } = require('../services/odooApi');

// Obtener o crear un Partner Genérico Web
async function getWebPartnerId() {
    const records = await executeKw('res.partner', 'search', [[['name', '=', 'Cliente Web (Listex)']]], { limit: 1 });
    if (records && records.length > 0) {
        return records[0];
    }
    const newPartnerId = await executeKw('res.partner', 'create', [{
        name: 'Cliente Web (Listex)',
        comment: 'Cliente genérico usado dinámicamente desde el carrito de la web.'
    }]);
    return newPartnerId;
}

router.post('/cart/create', async (req, res) => {
    try {
        const partnerId = await getWebPartnerId();
        const orderId = await executeKw('sale.order', 'create', [{
            partner_id: partnerId,
            state: 'draft'
        }]);
        res.json({ success: true, order_id: orderId });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post('/cart/add-line', async (req, res) => {
    const { order_id, product_id, quantity, price_unit, presentacion, surtido, line_description } = req.body;
    try {
        if (!order_id || !product_id || !quantity) {
            return res.status(400).json({ success: false, error: "Datos insuficientes" });
        }
        const lineData = {
            order_id: parseInt(order_id),
            product_id: parseInt(product_id),
            product_uom_qty: parseFloat(quantity),
        };
        if (price_unit !== undefined && price_unit !== null) {
            lineData.price_unit = parseFloat(price_unit);
        }
        // Descripción de la línea (incluye presentación y si es surtido)
        if (line_description) {
            lineData.name = line_description;
        }

        // Enriquecer línea con Tipo de Venta y variante surtido correcta
        let addLineTmplId = null;
        try {
            const vd = await executeKw('product.product', 'read', [[parseInt(product_id)], ['product_tmpl_id']]);
            addLineTmplId = vd[0]?.product_tmpl_id?.[0];
        } catch(e) {}

        if (addLineTmplId) {
            const ptavList = await executeKw('product.template.attribute.value', 'search_read', [
                [['product_tmpl_id', '=', addLineTmplId]]
            ], { fields: ['id', 'name'] });

            if (surtido && presentacion && presentacion !== 'detal') {
                // Buscar variante surtido (Color:Surtido, Talla:Surtido)
                const allVars = await executeKw('product.product', 'search_read', [
                    [['product_tmpl_id', '=', addLineTmplId], ['active', '=', true]]
                ], { fields: ['id', 'product_template_attribute_value_ids'] });
                const ptavById = {};
                ptavList.forEach(p => { ptavById[p.id] = p; });

                for (const v of allVars) {
                    const varPtavs = v.product_template_attribute_value_ids
                        .map(id => ptavById[id]).filter(p => p);
                    const relevant = varPtavs.filter(p => p.name !== 'Unidad'
                        && !['Combo (surtido)', 'Docena (surtido)', 'Bulto (surtido)'].includes(p.name));
                    if (relevant.length > 0 && relevant.every(p => p.name.toLowerCase() === 'surtido')) {
                        lineData.product_id = v.id;
                        break;
                    }
                }

                // PTAV Tipo de Venta surtido
                const presValMap = { docena:'Docena (surtido)', bulto:'Bulto (surtido)', combo:'Combo (surtido)' };
                const tvName = presValMap[presentacion];
                if (tvName) {
                    const ptav = ptavList.find(p => p.name === tvName);
                    if (ptav) lineData.product_no_variant_attribute_value_ids = [[6, 0, [ptav.id]]];
                }
            } else {
                // VARIADO / DETAL: PTAV Tipo de Venta: Unidad
                const ptav = ptavList.find(p => p.name === 'Unidad');
                if (ptav) lineData.product_no_variant_attribute_value_ids = [[6, 0, [ptav.id]]];
            }
        }

        const lineId = await executeKw('sale.order.line', 'create', [lineData]);
        res.json({ success: true, line_id: lineId });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post('/checkout', async (req, res) => {
    const { order_id, cart_items, customer_data } = req.body;
    try {
        if (!customer_data) {
            return res.status(400).json({ success: false, error: "Faltan datos del cliente" });
        }

        // Si no hay order_id previo, crear uno nuevo
        let parsedOrderId = order_id ? parseInt(order_id) : null;
        const partnerId = await getWebPartnerId();

        if (!parsedOrderId) {
            parsedOrderId = await executeKw('sale.order', 'create', [{
                partner_id: partnerId,
                state: 'draft'
            }]);
            console.log('[CHECKOUT] Nueva orden creada:', parsedOrderId);
        }

        // Eliminar líneas previas del background sync para re-crearlas correctamente
        // (el background sync puede haber creado líneas sin PTAV ni agrupación de combo)
        try {
            const existingLines = await executeKw('sale.order.line', 'search_read',
                [[['order_id', '=', parsedOrderId]]], { fields: ['id'] });
            if (existingLines.length > 0) {
                await executeKw('sale.order.line', 'unlink', [existingLines.map(l => l.id)]);
            }
        } catch(e) { console.warn('[CHECKOUT] No se pudieron limpiar líneas previas:', e.message); }

        // Agregar líneas del carrito con lógica correcta
        if (cart_items && cart_items.length > 0) {
            // Para Combo/Docena/Bulto VARIADO: crear 1 línea POR PIEZA
            // con precio_pieza = precio_presentación / total_piezas
            // Así cada variante tiene su precio unitario y el total cuadra con el precio de la presentación
            const groupedItems = [];
            const usedIndices = new Set();

            for (let i = 0; i < cart_items.length; i++) {
                if (usedIndices.has(i)) continue;
                const item = cart_items[i];
                const pres = item.presentacion || 'detal';

                // Combo/Docena/Bulto VARIADO → dividir precio entre piezas, 1 línea por variante
                if (!item.surtido && pres !== 'detal') {
                    const pieces = [item];
                    for (let j = i + 1; j < cart_items.length; j++) {
                        if (!usedIndices.has(j) && cart_items[j].presentacion === pres
                            && cart_items[j].product_name === item.product_name
                            && !cart_items[j].surtido) {
                            pieces.push(cart_items[j]);
                            usedIndices.add(j);
                        }
                    }
                    usedIndices.add(i);

                    const totalPiezas = pieces.length;
                    const precioTotal = parseFloat(item.price) || 0;
                    // precio por pieza = precio_presentación / nro_piezas (redondeado a 2 decimales)
                    const precioPieza = totalPiezas > 0 ? Math.round((precioTotal / totalPiezas) * 100) / 100 : precioTotal;
                    const presLabels = { combo:'Combo', docena:'Docena', bulto:'Bulto' };

                    // Crear 1 línea por cada pieza seleccionada con su variante y precio proporcional
                    pieces.forEach((piece, idx) => {
                        const pieceDesc = piece.product_name + ' — ' + (presLabels[pres]||pres)
                            + ' [Pieza ' + (idx+1) + '/' + totalPiezas + ']'
                            + ' — $' + precioTotal + ' total (' + totalPiezas + 'pz × $' + precioPieza + ')';
                        groupedItems.push({
                            ...piece,
                            quantity: 1,
                            price: precioPieza,  // precio unitario proporcional
                            description: pieceDesc,
                        });
                    });
                } else {
                    usedIndices.add(i);
                    groupedItems.push(item);
                }
            }

            function _presLabel(p) { return {combo:'Combo',docena:'Docena',bulto:'Bulto',detal:'Detal'}[p]||p; }

            for (const item of groupedItems) {
                if (!item.product_id || isNaN(item.product_id) || item.product_id <= 0) continue;
                try {
                    const lineData = {
                        order_id: parsedOrderId,
                        product_id: item.product_id,
                        product_uom_qty: parseFloat(item.quantity) || 1,
                        name: item.description || item.product_name || '',
                    };
                    if (item.price && item.price > 0) lineData.price_unit = parseFloat(item.price);

                    // Buscar el template del producto para PTAVs
                    let tmplId = null;
                    try {
                        const vd = await executeKw('product.product', 'read', [[item.product_id], ['product_tmpl_id']]);
                        tmplId = vd[0]?.product_tmpl_id?.[0];
                    } catch(e) {}

                    if (item.surtido && item.presentacion && item.presentacion !== 'detal') {
                        // SURTIDO: usar variante (Surtido, Surtido) + PTAV Tipo de Venta surtido
                        if (tmplId) {
                            try {
                                // Encontrar la variante con valores "Surtido" en todos sus atributos
                                const allVars = await executeKw('product.product', 'search_read', [
                                    [['product_tmpl_id', '=', tmplId], ['active', '=', true]]
                                ], { fields: ['id', 'product_template_attribute_value_ids'] });

                                const ptavList = await executeKw('product.template.attribute.value', 'search_read', [
                                    [['product_tmpl_id', '=', tmplId]]
                                ], { fields: ['id', 'name', 'attribute_id'] });
                                const ptavById = {};
                                ptavList.forEach(p => { ptavById[p.id] = p; });

                                // Encontrar variante donde TODOS los atributos always son "Surtido"
                                let surtidoVarId = null;
                                for (const v of allVars) {
                                    const varPtavs = v.product_template_attribute_value_ids
                                        .map(id => ptavById[id])
                                        .filter(p => p && p.attribute_id);
                                    // Excluir ptavs de atributos no_variant (Tipo de Venta)
                                    const variantPtavs = varPtavs.filter(p => p.name !== 'Unidad'
                                        && !['Combo (surtido)', 'Docena (surtido)', 'Bulto (surtido)'].includes(p.name));
                                    const allSurtido = variantPtavs.length > 0
                                        && variantPtavs.every(p => p.name.toLowerCase() === 'surtido');
                                    if (allSurtido) { surtidoVarId = v.id; break; }
                                }

                                if (surtidoVarId) {
                                    lineData.product_id = surtidoVarId; // usar variante surtido
                                    console.log('[CHECKOUT] ✓ Variante surtida ID:', surtidoVarId);
                                }

                                // PTAV Tipo de Venta surtido
                                const presValMap = { docena:'Docena (surtido)', bulto:'Bulto (surtido)', combo:'Combo (surtido)' };
                                const tvName = presValMap[item.presentacion];
                                if (tvName) {
                                    const ptav = ptavList.find(p => p.name === tvName);
                                    if (ptav) lineData.product_no_variant_attribute_value_ids = [[6, 0, [ptav.id]]];
                                }
                            } catch(e) { console.warn('[CHECKOUT] Surtido variant lookup:', e.message); }
                        }
                    } else {
                        // VARIADO / DETAL: agregar PTAV Tipo de Venta: Unidad
                        if (tmplId) {
                            try {
                                const ptavs = await executeKw('product.template.attribute.value', 'search_read', [[
                                    ['product_tmpl_id', '=', tmplId], ['name', '=', 'Unidad']
                                ]], { fields: ['id'], limit: 1 });
                                if (ptavs.length > 0) {
                                    lineData.product_no_variant_attribute_value_ids = [[6, 0, [ptavs[0].id]]];
                                }
                            } catch(e) {}
                        }
                    }

                    await executeKw('sale.order.line', 'create', [lineData]);
                } catch(lineErr) {
                    console.warn('[CHECKOUT] Line add failed:', lineErr.message);
                }
            }
        }

        // Actualizar orden con datos reales del cliente
        const realPartnerId = await executeKw('res.partner', 'create', [{
            name: `${customer_data.fname || ''} ${customer_data.lname || ''}`.trim(),
            vat: customer_data.cedula || '',
            email: customer_data.email || '',
            phone: customer_data.phone || '',
            comment: `Cédula: ${customer_data.cedula || ''}\nMétodo: ${customer_data.shipping_method}\nAgencia: ${customer_data.agency || ''}`
        }]);

        const presText = (cart_items || []).map(i =>
            `${i.product_name}: ${i.description || i.presentacion || ''}`
        ).join(' | ');

        await executeKw('sale.order', 'write', [[parsedOrderId], {
            partner_id: realPartnerId,
            client_order_ref: `ENVÍO: ${customer_data.shipping_method} | ${customer_data.agency || ''}`.substring(0, 100),
            note: `CLIENTE: ${customer_data.fname} ${customer_data.lname} | Cédula: ${customer_data.cedula} | Tel: ${customer_data.phone}\nENVÍO: ${customer_data.shipping_method}\nPEDIDO: ${presText}`.substring(0, 500),
        }]);

        // IMPORTANTE: NO confirmar la orden — debe quedar como COTIZACIÓN ENVIADA (state='sent')
        // action_confirm cambiaría state a 'sale' lo cual bloquea ediciones
        try {
            await executeKw('sale.order', 'write', [[parsedOrderId], { state: 'sent' }]);
        } catch(e) {
            // Si no se puede poner 'sent' directamente (algunos Odoo lo restringen), dejar como draft
            console.warn('[CHECKOUT] No se pudo poner state=sent:', e.message);
        }

        res.json({ success: true, message: "Cotización registrada en Odoo", order_id: parsedOrderId });
    } catch (error) {
        console.error('[CHECKOUT] Error:', error.message);
        // Responder con success=false pero incluir el error para que el frontend lo capture
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get('/products', async (req, res) => {
    try {
        const cacheBuster = `?t=${new Date().getTime()}`;
        const catalogUrl = 'https://listex.odoo.com/web/content/16027/api_catalogo_listex.json';
        const response = await fetch(catalogUrl + cacheBuster);
        if (!response.ok) throw new Error(`HTTP: ${response.status}`);
        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error("[CATALOG] Error:", error.message);
        res.status(500).json({ success: false, error: "No se pudo cargar el catálogo" });
    }
});

// v3: Catálogo con Presentación Universal — servido desde Render PG (PG-first)
// Si PG no tiene catálogo aún, hace fallback al proxy del JSON DATA WEB 3 de Odoo.
const { pool } = require('../db/init');
const V3_CATALOG_URL = 'https://listex.odoo.com/web/content/18758/api_catalogo_listex_v3.json';

// Caché en memoria del catálogo ensamblado (revalidación periódica)
let _v3Cache = null, _v3CacheTs = 0;
const V3_CACHE_TTL = 30000;  // 30s

async function assembleCatalogFromPG() {
    // Trae el catalog_json de todos los productos.
    // DEDUPLICACIÓN: si dos proveedores cargaron el mismo enlace JSON,
    // el mismo external_id puede existir N veces. Usamos DISTINCT ON (external_id)
    // para servir solo uno (el más reciente). Los productos del portal (sin external_id)
    // siempre se incluyen sin filtro.
    const r = await pool.query(
        `SELECT catalog_json FROM (
            SELECT DISTINCT ON (COALESCE(external_id, id))
                   catalog_json, updated_at
            FROM portal_products
            WHERE catalog_json IS NOT NULL
            ORDER BY COALESCE(external_id, id), updated_at DESC NULLS LAST
         ) dedup
         ORDER BY updated_at DESC NULLS LAST`
    );
    return r.rows.map(row => row.catalog_json);
}

router.get('/products/v3', async (req, res) => {
    // 1. Caché en memoria → instantáneo
    if (_v3Cache && (Date.now() - _v3CacheTs) < V3_CACHE_TTL) {
        return res.json(_v3Cache);
    }
    // 2. Intentar ensamblar desde PG (rápido). Si falla o está vacío → fallback.
    try {
        const pgCatalog = await assembleCatalogFromPG();
        if (pgCatalog && pgCatalog.length > 0) {
            _v3Cache = pgCatalog; _v3CacheTs = Date.now();
            return res.json(pgCatalog);
        }
    } catch (pgErr) {
        console.warn("[CATALOG V3] PG no disponible, usando fallback Odoo:", pgErr.message);
    }
    // 3. Fallback: proxy del JSON de Odoo (durante migración o si PG está vacío)
    try {
        const response = await fetch(V3_CATALOG_URL + `?t=${Date.now()}`);
        if (!response.ok) throw new Error(`HTTP: ${response.status}`);
        const data = await response.json();
        _v3Cache = data; _v3CacheTs = Date.now();
        res.json(data);
    } catch (error) {
        console.error("[CATALOG V3] Error:", error.message);
        if (_v3Cache) return res.json(_v3Cache);
        res.status(500).json({ success: false, error: "No se pudo cargar el catálogo v3" });
    }
});

// Invalidar caché del catálogo (llamado tras ingestas o cambios de productos)
function invalidateV3Cache() { _v3Cache = null; _v3CacheTs = 0; }
router.invalidateV3Cache = invalidateV3Cache;

router.post('/portal/login', async (req, res) => {
    const { cedula } = req.body;
    try {
        if (!cedula) return res.status(400).json({ error: "Cédula requerida" });
        const partners = await executeKw('res.partner', 'search_read', 
            [[['vat', 'ilike', cedula]]], 
            { fields: ['id', 'name', 'vat', 'email', 'phone', 'comment'], limit: 1 }
        );
        if (!partners || partners.length === 0) {
            return res.status(404).json({ success: false, error: "Cliente no encontrado." });
        }
        res.json({ success: true, partner: partners[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get('/portal/dashboard/:partner_id', async (req, res) => {
    const partnerId = parseInt(req.params.partner_id);
    try {
        const currentPartnerData = await executeKw('res.partner', 'read', [[partnerId], ['vat']]);
        const vat = currentPartnerData[0].vat;
        if (!vat) return res.status(400).json({ success: false, error: "No tiene cédula" });

        const allRelatedPartners = await executeKw('res.partner', 'search_read', 
            [[['vat', '=', vat]]], 
            { fields: ['id', 'commercial_partner_id'] }
        );
        const allPartnerIds = allRelatedPartners.map(p => p.id);
        const allCommercialIds = [...new Set(allRelatedPartners.map(p => p.commercial_partner_id ? p.commercial_partner_id[0] : p.id))];

        const orders = await executeKw('sale.order', 'search_read',
            [['|', ['partner_id', 'in', allPartnerIds], ['partner_id', 'child_of', allCommercialIds]]],
            { 
                fields: ['name', 'date_order', 'state', 'amount_total', 'x_studio_numero_de_guia', 'picking_ids', 'company_id'],
                order: 'date_order desc'
            }
        );
        
        const saleOrderIds = orders.map(o => o.id);
        let orderLines = [];
        if (saleOrderIds.length > 0) {
            orderLines = await executeKw('sale.order.line', 'search_read',
                [[['order_id', 'in', saleOrderIds]]],
                { fields: ['order_id', 'product_id', 'name', 'product_uom_qty', 'price_unit', 'price_subtotal', 'price_total', 'qty_delivered'] }
            );
        }
        const linesByOrder = {};
        orderLines.forEach(line => {
            const oId = line.order_id[0];
            if (!linesByOrder[oId]) linesByOrder[oId] = [];
            linesByOrder[oId].push(line);
        });
        orders.forEach(o => o.order_lines = linesByOrder[o.id] || []);
        
        let allPickings = [];
        if (saleOrderIds.length > 0) {
            allPickings = await executeKw('stock.picking', 'search_read',
                [[['sale_id', 'in', saleOrderIds]]],
                { fields: ['id', 'name', 'state', 'sale_id', 'date_done'] }
            );
        }
        const pickingsByOrder = {};
        allPickings.forEach(p => {
            const oId = p.sale_id[0];
            if (!pickingsByOrder[oId]) pickingsByOrder[oId] = [];
            pickingsByOrder[oId].push(p);
        });
        orders.forEach(o => o.stock_pickings = pickingsByOrder[o.id] || []);

        const stats = {
            total_orders: orders.length,
            total_spent: orders.reduce((sum, o) => sum + (o.state !== 'cancel' ? o.amount_total : 0), 0),
            orders_completed: orders.filter(o => o.state === 'sale' || o.state === 'done').length,
            orders_pending: orders.filter(o => o.state === 'draft' || o.state === 'sent').length,
        };

        res.json({ success: true, stats, orders });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Categories for supplier portal
// Tasas de cambio del día: Binance USDT/VES + BCV EUR/VES
let ratesCache = null;
let ratesCacheTs = 0;
const RATES_TTL = 60 * 60 * 1000; // 1 hora

router.get('/rates', async (req, res) => {
    try {
        const now = Date.now();
        if (ratesCache && (now - ratesCacheTs) < RATES_TTL) {
            return res.json({ success: true, ...ratesCache, cached: true });
        }

        let usdtVes = null, eurVes = null;

        // Binance P2P USDT/VES
        try {
            const bRes = await fetch('https://p2p.binance.com/bapi/c2c/v2/friendly/c2c/adv/search', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ asset: 'USDT', fiat: 'VES', tradeType: 'BUY', page: 1, rows: 5, payTypes: [] })
            });
            const bData = await bRes.json();
            const prices = (bData.data || []).map(d => parseFloat(d.adv?.price || 0)).filter(p => p > 0);
            if (prices.length > 0) usdtVes = prices.reduce((a, b) => a + b, 0) / prices.length;
        } catch(e) { console.warn('[RATES] Binance error:', e.message); }

        // EUR/VES — múltiples fuentes en cadena
        const eurSources = [
            // 1. ve.dolarapi.com
            async () => {
                const r = await fetch('https://ve.dolarapi.com/v1/dolares/euro', { signal: AbortSignal.timeout(5000) });
                const d = await r.json();
                return d.promedio ? parseFloat(d.promedio) : null;
            },
            // 2. yadio.io exrates (EUR entry)
            async () => {
                const r = await fetch('https://api.yadio.io/exrates/VES', { signal: AbortSignal.timeout(5000) });
                const d = await r.json();
                return d.EUR ? parseFloat(d.EUR) : null;
            },
            // 3. open.er-api.com (gratis, sin API key): calcula EUR/VES
            //    Si tiene VES oficial: VES_por_USD / EUR_por_USD = VES_por_EUR
            //    Si no tiene VES: usa Binance usdtVes / EUR_por_USD
            async () => {
                const r = await fetch('https://open.er-api.com/v6/latest/USD', { signal: AbortSignal.timeout(6000) });
                const d = await r.json();
                if (!d.rates || !d.rates.EUR) return null;
                if (d.rates.VES && parseFloat(d.rates.VES) > 1) {
                    return parseFloat(d.rates.VES) / parseFloat(d.rates.EUR);
                }
                if (usdtVes > 0) {
                    return usdtVes / parseFloat(d.rates.EUR);
                }
                return null;
            },
        ];
        for (const src of eurSources) {
            if (eurVes) break;
            try { eurVes = await src(); } catch(e) { /* siguiente */ }
        }

        if (!usdtVes) usdtVes = 0;
        if (!eurVes) eurVes = 0;

        ratesCache = { usdtVes, eurVes, fetchedAt: new Date().toISOString() };
        ratesCacheTs = now;

        res.json({ success: true, ...ratesCache, cached: false });
    } catch (error) {
        console.error('[RATES] Error:', error.message);
        res.status(500).json({ success: false, error: error.message, usdtVes: 0, eurVes: 0 });
    }
});

router.get('/categories', async (req, res) => {
    try {
        const categories = await executeKw('product.public.category', 'search_read', [
            []
        ], { fields: ['id', 'name', 'parent_id'], order: 'name asc' });
        
        const formatted = categories.map(c => ({
            id: c.id,
            name: c.parent_id ? `${c.parent_id[1]} / ${c.name}` : c.name
        }));
        
        res.json({ success: true, categories: formatted });
    } catch (error) {
        console.error("[CATEGORIES] Error:", error.message);
        res.status(500).json({ success: false, error: error.message });
    }
});

module.exports = router;
