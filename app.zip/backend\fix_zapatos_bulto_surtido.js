/**
 * Corrige los zapatos de Javier Serrano:
 * - Bulto = SURTIDO (cliente NO escoge variantes)
 * - Combo y Docena = VARIADO (cliente SÍ escoge variantes)
 *
 * Para cada producto:
 * 1. Actualiza x_web3_bulto_surtido = true
 * 2. Actualiza x_web3_combo_surtido = false
 * 3. Actualiza x_web3_docena_surtido = false
 * 4. Agrega valor "Surtido" al atributo Color
 * 5. Recalcula PL por variante (variante Surtido → precio completo bulto)
 * 6. Actualiza Tipo de Venta (no_variant) → Unidad + Bulto (surtido)
 * 7. Ejecuta DATA WEB 3
 */
const xmlrpc = require('xmlrpc');
const { ensureTipoVentaAttr, setVariantPricelists } = require('./services/odooSyncHelpers');

const models_client = xmlrpc.createSecureClient({ host:'listex.odoo.com', port:443, path:'/xmlrpc/2/object', timeout:120000 });
const DB='listex', PASS='Seguridad400%', UID=2;
function odoo(m,mt,a,k={}) { return new Promise((r,j)=>{ models_client.methodCall('execute_kw',[DB,UID,PASS,m,mt,a,k],(e,res)=>{ if(e) return j(e); r(res); }); }); }

const JAVIER_ID = 5167;

function ceilPrice(v) { return Math.ceil(v * 100) / 100; }
function calcPrecios(cost) {
    return {
        detal:   ceilPrice(cost * 1.55),
        combo:   Math.round(ceilPrice(cost * 1.45) * 3  * 100) / 100,
        docena:  Math.round(ceilPrice(cost * 1.35) * 12 * 100) / 100,
        bulto:   Math.round(ceilPrice(cost * 1.20) * 13 * 100) / 100,
    };
}

async function fixProduct(tmplId, tmplName, cost) {
    const precios = calcPrecios(cost);
    console.log(`  Fixing ${tmplName} (${tmplId}) costo:$${cost}`);

    // 1. Leer atributos y valores existentes
    const existingAttrMap = {}, existingValMap = {};
    const odooAttrs = await odoo('product.attribute','search_read',[[]], {fields:['id','name']});
    odooAttrs.forEach(a=>existingAttrMap[a.name]=a.id);
    const odooVals = await odoo('product.attribute.value','search_read',[[]], {fields:['id','name','attribute_id']});
    odooVals.forEach(v=>{ if(v.attribute_id) existingValMap[v.attribute_id[0]+'_'+v.name]=v.id; });

    const web3Item = {
        x_web3_detal_usd:         precios.detal,
        x_web3_cost_usd:          cost,
        x_web3_combo_habilitado:  true,
        x_web3_combo_usd:         precios.combo,
        x_web3_combo_piezas:      3,
        x_web3_combo_surtido:     false,  // cliente escoge
        x_web3_docena_habilitado: true,
        x_web3_docena_usd:        precios.docena,
        x_web3_docena_surtido:    false,  // cliente escoge
        x_web3_bulto_habilitado:  true,
        x_web3_bulto_usd:         precios.bulto,
        x_web3_bulto_piezas:      13,
        x_web3_bulto_surtido:     true,   // SURTIDO ← corrección principal
        x_web3_precio_ves:        0,
    };

    // 2. Actualizar campos x_web3 en template
    await odoo('product.template','write',[[tmplId], {
        x_web3_bulto_surtido:  true,
        x_web3_combo_surtido:  false,
        x_web3_docena_surtido: false,
        x_web3_bulto_usd:      precios.bulto,
        x_web3_combo_usd:      precios.combo,
        x_web3_docena_usd:     precios.docena,
    }]);

    // 3. Agregar "Surtido" al atributo Color (necesario para variante surtida universal)
    const colorAttrId = existingAttrMap['Color'];
    if (colorAttrId) {
        const attrLines = await odoo('product.template.attribute.line','search_read',[
            [['product_tmpl_id','=',tmplId],['attribute_id','=',colorAttrId]]
        ],{fields:['id','value_ids']});

        if (attrLines.length > 0) {
            const line = attrLines[0];
            const surtidoKey = `${colorAttrId}_Surtido`;
            if (!existingValMap[surtidoKey]) {
                existingValMap[surtidoKey] = await odoo('product.attribute.value','create',[{name:'Surtido',attribute_id:colorAttrId}]);
            }
            const surtidoValId = existingValMap[surtidoKey];
            if (!line.value_ids.includes(surtidoValId)) {
                const newValIds = [...new Set([...line.value_ids, surtidoValId])];
                await odoo('product.template.attribute.line','write',[[line.id],{value_ids:[[6,0,newValIds]]}]);
                console.log(`    ✓ Color "Surtido" agregado`);
            } else {
                console.log(`    ✓ Color "Surtido" ya existe`);
            }
        }
    }

    // 4. Actualizar Tipo de Venta (no_variant) para incluir "Bulto (surtido)"
    const { tvAttrId, allTvValIds } = await ensureTipoVentaAttr(web3Item, existingAttrMap, existingValMap, odoo);
    const tvLines = await odoo('product.template.attribute.line','search_read',[
        [['product_tmpl_id','=',tmplId],['attribute_id','=',tvAttrId]]
    ],{fields:['id','value_ids']});
    if (tvLines.length > 0) {
        await odoo('product.template.attribute.line','write',[[tvLines[0].id],{value_ids:[[6,0,allTvValIds]]}]);
    } else {
        await odoo('product.template','write',[[tmplId],{
            attribute_line_ids:[[0,0,{attribute_id:tvAttrId,value_ids:[[6,0,allTvValIds]]}]]
        }]);
    }
    console.log(`    ✓ Tipo de Venta actualizado: Unidad + Bulto (surtido)`);

    // 5. Recalcular PL por variante (esperar a que Odoo genere la variante Surtido)
    await new Promise(r=>setTimeout(r,2000));
    await setVariantPricelists(tmplId, web3Item, odoo);

    // 6. Verificar
    const variants = await odoo('product.product','search_read',[
        [['product_tmpl_id','=',tmplId],['active','=',true]]
    ],{fields:['id','display_name']});
    const surtidoVar = variants.find(v=>v.display_name.toLowerCase().includes('surtido'));
    console.log(`    ✓ Total variantes: ${variants.length} | Variante Surtida: ${surtidoVar?'✓ ID:'+surtidoVar.id:'✗ no encontrada'}`);
}

async function main() {
    console.log('=== CORRECCIÓN BULTO SURTIDO — ZAPATOS JAVIER SERRANO ===\n');
    console.log('Regla:');
    console.log('  Detal   → cliente escoge color ✓');
    console.log('  Combo   → cliente escoge color ✓');
    console.log('  Docena  → cliente escoge color ✓');
    console.log('  Bulto   → SURTIDO (proveedor elige) ✓\n');

    // Obtener todos los productos de Javier en Odoo
    const suppInfos = await odoo('product.supplierinfo','search_read',[
        [['partner_id','=',JAVIER_ID]]
    ],{fields:['product_tmpl_id']});

    const tmplIds = [...new Set(suppInfos.map(s=>s.product_tmpl_id[0]))];
    console.log(`Productos de Javier en Odoo: ${tmplIds.length}`);

    const tmpls = await odoo('product.template','read',[tmplIds],{
        fields:['id','name','x_web3_cost_usd','standard_price','x_web3_bulto_surtido','active']
    });
    // Solo los activos con campos web3 configurados
    const zapatosTmpls = tmpls.filter(t=>t.active && (t.x_web3_cost_usd > 0 || t.standard_price > 0));

    console.log(`Zapatos a corregir: ${zapatosTmpls.length}\n`);
    zapatosTmpls.forEach(t=>console.log(`  ${t.id}: ${t.name} | costo:$${t.x_web3_cost_usd||t.standard_price} | bulto_surtido:${t.x_web3_bulto_surtido}`));

    let fixed = 0;
    for (const tmpl of zapatosTmpls) {
        const cost = parseFloat(tmpl.x_web3_cost_usd || tmpl.standard_price) || 0;
        if (cost === 0) { console.log(`\nSkip ${tmpl.name}: sin costo`); continue; }
        try {
            await fixProduct(tmpl.id, tmpl.name, cost);
            fixed++;
        } catch(e) {
            console.error(`  ✗ Error en ${tmpl.name}:`, e.message?.substring(0,100));
        }
    }

    // DATA WEB 3
    console.log('\nActualizando catálogo...');
    await odoo('ir.actions.server','run',[[3047]]);
    console.log('✓ DATA WEB 3 ejecutado');

    console.log(`\n=== CORRECCIÓN COMPLETADA: ${fixed}/${zapatosTmpls.length} productos ===`);
}

main().catch(e=>{ console.error('FATAL:', e.message); if(e.faultString) console.error(e.faultString.substring(0,500)); });
