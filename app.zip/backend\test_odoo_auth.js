require('dotenv').config();
const xmlrpc = require('xmlrpc');

const url = new URL(process.env.ODOO_URL);
const host = url.hostname;
const port = url.port || (url.protocol === 'https:' ? 443 : 80);
const isSecure = url.protocol === 'https:';

const clientOptions = { host, port, path: '/xmlrpc/2/common' };
const client = isSecure ? xmlrpc.createSecureClient(clientOptions) : xmlrpc.createClient(clientOptions);

client.methodCall('authenticate', [
    process.env.ODOO_DB,
    process.env.ODOO_USERNAME,
    process.env.ODOO_API_KEY,
    {}
], (error, result) => {
    if (error) {
        console.error("RPC Error:", error);
    } else if (result === false) {
        console.error("Auth Failed: Credentials invalid.");
    } else {
        console.log("Auth Success! UID:", result);
    }
});
