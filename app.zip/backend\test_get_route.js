const http = require('http');

const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/api/supplier/products/1468',
    method: 'GET',
    headers: {
        'Authorization': 'Bearer test_token' // Wait, I need a valid token to bypass authenticateSupplier!
    }
};

// I will just execute the exact logic from the GET route in a script to see what throws.
const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        const tmplId = 1468;
        
        const products = await executeKw('product.template', 'search_read', [
            [['id', '=', tmplId]], 
            ['name', 'standard_price', 'list_price', 'public_categ_ids', 'is_storable', 'image_1920']
        ]);
        if (products.length === 0) return console.log("Not found");
        
        const p = products[0];
        
        const pricelists = await executeKw('product.pricelist.item', 'search_read', [
            [['product_tmpl_id', '=', tmplId], ['pricelist_id', 'in', [2, 3]]]
        ], { fields: ['pricelist_id', 'fixed_price'] });
        
        let priceDocena = "";
        let priceBulto = "";
        pricelists.forEach(pl => {
            if (pl.pricelist_id[0] === 3) priceDocena = pl.fixed_price; // 3 = Docena
            if (pl.pricelist_id[0] === 2) priceBulto = pl.fixed_price;  // 2 = Bulto
        });
        
        const variants = await executeKw('product.product', 'search_read', [
            [['product_tmpl_id', '=', tmplId]],
            ['id', 'product_template_attribute_value_ids', 'qty_available', 'image_variant_1920']
        ]);
        
        for (let v of variants) {
            if (v.product_template_attribute_value_ids.length > 0) {
                const ptavs = await executeKw('product.template.attribute.value', 'search_read', [
                    [['id', 'in', v.product_template_attribute_value_ids]],
                    ['name', 'attribute_id']
                ]);
                v.attribute_names = ptavs.map(pt => pt.name).join(' / ');
            } else {
                v.attribute_names = "Variante Base";
            }
        }
        
        console.log("Success! Variants:", variants.length);
    } catch (e) {
        console.error("GET Route Error:", e);
    }
});
