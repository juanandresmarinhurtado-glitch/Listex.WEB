const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const oldVariantsLogic = /const variants = await executeKw\('product\.product', 'search_read', \[\s*\[\['product_tmpl_id', '=', tmplId\]\],\s*\['id', 'product_template_attribute_value_ids', 'image_variant_1920'\]\s*\]\);\s*\/\/ For each variant, fetch the human-readable names of the attributes\s*for \(let v of variants\) \{\s*if \(v\.product_template_attribute_value_ids && v\.product_template_attribute_value_ids\.length > 0\) \{\s*const ptavs = await executeKw\('product\.template\.attribute\.value', 'search_read', \[\s*\[\['id', 'in', v\.product_template_attribute_value_ids\]\],\s*\['name', 'attribute_id'\]\s*\]\);\s*v\.attribute_names = ptavs\.map\(p => p\.name\)\.join\(' \/ '\);\s*\} else \{\s*v\.attribute_names = "Variante Base";\s*\}\s*\}/;

const newVariantsLogic = `const variants = await executeKw('product.product', 'search_read', [
            [['product_tmpl_id', '=', tmplId]],
            ['id', 'product_template_attribute_value_ids', 'image_variant_128', 'qty_available']
        ]);
        
        const allPtavIds = new Set();
        variants.forEach(v => {
            if (v.product_template_attribute_value_ids) {
                v.product_template_attribute_value_ids.forEach(id => allPtavIds.add(id));
            }
        });
        
        const uniquePtavIds = [...allPtavIds];
        let ptavMap = {};
        
        if (uniquePtavIds.length > 0) {
            const ptavs = await executeKw('product.template.attribute.value', 'search_read', [
                [['id', 'in', uniquePtavIds]],
                ['id', 'name']
            ]);
            ptavs.forEach(p => ptavMap[p.id] = p.name);
        }
        
        for (let v of variants) {
            if (v.product_template_attribute_value_ids && v.product_template_attribute_value_ids.length > 0) {
                v.attribute_names = v.product_template_attribute_value_ids.map(id => ptavMap[id] || '').filter(Boolean).join(' / ');
            } else {
                v.attribute_names = "Variante Base";
            }
            v.image_variant_1920 = v.image_variant_128;
            delete v.image_variant_128;
        }`;

serverJs = serverJs.replace(oldVariantsLogic, newVariantsLogic);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Variant GET optimization implemented.");
