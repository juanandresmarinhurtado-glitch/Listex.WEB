const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

// The new fast POST route and the Variant routes
const newRoutes = `
app.post('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const { name, cost, priceUnidad, priceDocena, priceBulto, categoryId, customAttributes, imageBase64 } = req.body;
        
        // Helper to find or create attribute
        async function getOrCreateAttribute(attrName) {
            const attrs = await executeKw('product.attribute', 'search_read', [[['name', '=', attrName]], ['id']]);
            if (attrs.length > 0) return attrs[0].id;
            return await executeKw('product.attribute', 'create', [{ name: attrName, create_variant: 'dynamic' }]); // 'dynamic' or 'always'
        }

        // Helper to find or create attribute value
        async function getOrCreateAttrValue(attrId, valName) {
            const vals = await executeKw('product.attribute.value', 'search_read', [[['attribute_id', '=', attrId], ['name', '=', valName]], ['id']]);
            if (vals.length > 0) return vals[0].id;
            return await executeKw('product.attribute.value', 'create', [{ attribute_id: attrId, name: valName }]);
        }

        // 1. Create Product Template (Without Taxes)
        const productData = {
            name: name,
            list_price: parseFloat(priceUnidad) || 0,
            standard_price: parseFloat(cost) || 0,
            sale_ok: true,
            purchase_ok: true,
            is_published: false,
            taxes_id: false,
            supplier_taxes_id: false
        };
        
        if (imageBase64) {
            productData.image_1920 = imageBase64.split(',')[1] || imageBase64;
        }
        
        if (categoryId) {
            productData.public_categ_ids = [[6, 0, [parseInt(categoryId)]]];
        }
        
        const tmplId = await executeKw('product.template', 'create', [productData]);
        
        // Execute parallel tasks for speed
        const parallelTasks = [];
        
        parallelTasks.push(executeKw('product.template', 'write', [[tmplId], { is_published: true }]));
        parallelTasks.push(executeKw('product.supplierinfo', 'create', [{ partner_id: req.user.id, product_tmpl_id: tmplId, delay: 1 }]));
        
        if (priceDocena) {
            parallelTasks.push(executeKw('product.pricelist.item', 'create', [{ pricelist_id: 3, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceDocena) }]));
        }
        if (priceBulto) {
            parallelTasks.push(executeKw('product.pricelist.item', 'create', [{ pricelist_id: 2, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceBulto) }]));
        }
        
        await Promise.all(parallelTasks);
        
        // Handle Attributes Sequentially because Odoo gets finicky with parallel attribute writes
        const presentacionId = await getOrCreateAttribute('Presentación');
        let presValIds = [];
        presValIds.push(await getOrCreateAttrValue(presentacionId, 'unidad variada'));
        if (priceDocena) presValIds.push(await getOrCreateAttrValue(presentacionId, 'docena cerrada'));
        if (priceBulto) presValIds.push(await getOrCreateAttrValue(presentacionId, 'bulto'));
        
        await executeKw('product.template.attribute.line', 'create', [{ product_tmpl_id: tmplId, attribute_id: presentacionId, value_ids: [[6, 0, presValIds]] }]);

        if (customAttributes && customAttributes.length > 0) {
            for (let attr of customAttributes) {
                if (!attr.name || !attr.values || attr.values.length === 0) continue;
                const attrId = await getOrCreateAttribute(attr.name);
                let valIds = [];
                for (let v of attr.values) {
                    if (!v.trim()) continue;
                    valIds.push(await getOrCreateAttrValue(attrId, v.trim()));
                }
                if (valIds.length > 0) {
                    await executeKw('product.template.attribute.line', 'create', [{ product_tmpl_id: tmplId, attribute_id: attrId, value_ids: [[6, 0, valIds]] }]);
                }
            }
        }
        
        res.json({ success: true, message: "Producto creado", id: tmplId });
    } catch (error) {
        console.error("Create Product Error:", error);
        res.status(500).json({ error: error.message });
    }
});

// GET Variants for a product
app.get('/api/supplier/products/:tmplId/variants', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const tmplId = parseInt(req.params.tmplId);
        
        // Security check: Make sure this product belongs to the supplier
        const supplierInfos = await executeKw('product.supplierinfo', 'search_count', [[['partner_id', '=', req.user.id], ['product_tmpl_id', '=', tmplId]]]);
        if (supplierInfos === 0) return res.status(403).json({ error: "Access denied" });
        
        // Odoo generates product.product records when attributes are added. We might need a small delay or they are created synchronously.
        const variants = await executeKw('product.product', 'search_read', [
            [['product_tmpl_id', '=', tmplId]],
            ['id', 'product_template_attribute_value_ids', 'image_variant_1920']
        ]);
        
        // For each variant, fetch the human-readable names of the attributes
        for (let v of variants) {
            if (v.product_template_attribute_value_ids.length > 0) {
                const ptavs = await executeKw('product.template.attribute.value', 'search_read', [
                    [['id', 'in', v.product_template_attribute_value_ids]],
                    ['name', 'attribute_id']
                ]);
                v.attribute_names = ptavs.map(p => p.name).join(' / ');
            } else {
                v.attribute_names = "Variante Base";
            }
        }
        
        res.json({ success: true, variants: variants });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST Variant Image
app.post('/api/supplier/variants/:variantId/image', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const variantId = parseInt(req.params.variantId);
        const { imageBase64 } = req.body;
        
        if (!imageBase64) return res.status(400).json({ error: "No image provided" });
        
        const b64 = imageBase64.split(',')[1] || imageBase64;
        
        await executeKw('product.product', 'write', [[variantId], { image_1920: b64 }]);
        
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
`;

// Extract existing file parts
const startMarker = "app.post('/api/supplier/products'";
const endMarker = "// Categories endpoint";

const startIndex = serverJs.indexOf(startMarker);
const endIndex = serverJs.indexOf(endMarker);

if (startIndex !== -1 && endIndex !== -1) {
    const newFileContent = serverJs.substring(0, startIndex) + newRoutes + "\n" + serverJs.substring(endIndex);
    fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', newFileContent, 'utf8');
    console.log("server.js updated with variants endpoints.");
} else {
    console.log("Could not find markers in server.js");
}
