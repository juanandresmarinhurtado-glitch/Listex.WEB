/* =============================================
   PRODUCT DETAIL MODAL - Listex Mayorista
   product-detail.js
   ============================================= */

(function () {
    'use strict';

    const CATALOG_URL = 'https://listex.odoo.com/web/content/17653/api_catalogo_jerarquia.json';
    const WHATSAPP_NUMBER = '584244329649';

    /* ------------------------------------------
       OPEN PRODUCT DETAIL
    ------------------------------------------ */
    window.openProductDetail = function (productName) {
        let variants = [];
        if (typeof productIndex !== 'undefined' && productIndex[productName]) {
            variants = productIndex[productName];
        } else if (typeof allProducts !== 'undefined') {
            variants = allProducts.filter(function (p) {
                return (p.nombre || '').toLowerCase() === (productName || '').toLowerCase();
            });
        }

        if (!variants || variants.length === 0) {
            if (typeof showToast === 'function') showToast('Producto no encontrado', 'error');
            return;
        }

        const baseProduct = variants[0];

        // Collect unique variant values
        const presentaciones = [];
        const colores = [];
        const tallas = [];
        const images = [];

        variants.forEach(function (v) {
            if (v.imagen_url && images.indexOf(v.imagen_url) === -1) {
                images.push(v.imagen_url);
            }
            if (v.variantes && Array.isArray(v.variantes)) {
                v.variantes.forEach(function (attr) {
                    const key = (attr.atributo || '').toLowerCase().trim();
                    const val = (attr.valor || '').trim();
                    if (!val) return;
                    if (key === 'presentación' || key === 'presentacion') {
                        if (presentaciones.indexOf(val) === -1) presentaciones.push(val);
                    } else if (key === 'color') {
                        if (colores.indexOf(val) === -1) colores.push(val);
                    } else if (key === 'talla') {
                        if (tallas.indexOf(val) === -1) tallas.push(val);
                    }
                });
            }
        });

        if (images.length === 0) images.push('');

        // Build modal HTML
        let modalHTML = '';
        modalHTML += '<div class="product-modal-overlay" id="productModalOverlay" onclick="closeProductModalOverlay(event)">';
        modalHTML += '<div class="product-modal" onclick="event.stopPropagation()">';

        // Close button
        modalHTML += '<button class="product-modal-close" onclick="closeProductModal()" aria-label="Cerrar">&times;</button>';

        modalHTML += '<div class="product-modal-body">';

        // LEFT: Image gallery
        modalHTML += '<div class="product-modal-gallery">';
        modalHTML += '<div class="product-modal-main-image" id="modalMainImage">';
        if (images[0]) {
            modalHTML += '<img src="' + escapeHTML(images[0]) + '" alt="' + escapeHTML(baseProduct.nombre) + '" onerror="this.parentElement.innerHTML=\'<div class=placeholder-img>📦</div>\'">';
        } else {
            modalHTML += '<div class="placeholder-img">📦</div>';
        }
        modalHTML += '</div>';
        if (images.length > 1) {
            modalHTML += '<div class="product-modal-thumbnails">';
            images.forEach(function (img, idx) {
                modalHTML += '<button class="thumbnail' + (idx === 0 ? ' active' : '') + '" onclick="switchModalImage(\'' + escapeHTML(img) + '\', this)">';
                modalHTML += '<img src="' + escapeHTML(img) + '" alt="Miniatura ' + (idx + 1) + '" onerror="this.src=\'\'; this.parentElement.style.display=\'none\'">';
                modalHTML += '</button>';
            });
            modalHTML += '</div>';
        }
        modalHTML += '</div>';

        // RIGHT: Product info
        modalHTML += '<div class="product-modal-info">';

        // Category
        modalHTML += '<div class="modal-product-category">' + escapeHTML(baseProduct.categoria_principal || '') + '</div>';

        // Name
        modalHTML += '<h2 class="modal-product-name">' + escapeHTML(baseProduct.nombre) + '</h2>';

        // Description
        if (baseProduct.descripcion) {
            modalHTML += '<p class="modal-product-description">' + escapeHTML(baseProduct.descripcion) + '</p>';
        }

        // Price
        const basePrice = parseFloat(baseProduct.precio_base) || 0;
        const currency = baseProduct.moneda || 'USD';
        modalHTML += '<div class="modal-product-price" id="modalProductPrice">';
        modalHTML += '<span class="price-value">' + formatPriceModal(basePrice, currency) + '</span>';
        modalHTML += '</div>';

        // Multiple tariffs info
        if (baseProduct.tarifas_multiples && baseProduct.tarifas_multiples.length > 0) {
            modalHTML += '<div class="modal-tariffs">';
            modalHTML += '<span class="tariffs-label">Precios mayoristas:</span>';
            baseProduct.tarifas_multiples.forEach(function (t) {
                modalHTML += '<span class="tariff-tag">' + escapeHTML(t.nombre_tarifa) + ': ' + formatPriceModal(t.precio_fijo, currency) + '</span>';
            });
            modalHTML += '</div>';
        }

        // Variant selectors
        modalHTML += '<div class="modal-variants">';

        // Presentación
        if (presentaciones.length > 0) {
            modalHTML += '<div class="variant-group">';
            modalHTML += '<label class="variant-label">Presentación</label>';
            modalHTML += '<select class="variant-select" id="modalPresentacion" onchange="applyVariantRules()">';
            presentaciones.forEach(function (p, i) {
                modalHTML += '<option value="' + escapeHTML(p) + '"' + (i === 0 ? ' selected' : '') + '>' + escapeHTML(p) + '</option>';
            });
            modalHTML += '</select>';
            modalHTML += '</div>';
        }

        // Color
        if (colores.length > 0) {
            modalHTML += '<div class="variant-group" id="modalColorGroup">';
            modalHTML += '<label class="variant-label">Color <span id="selectedColorName"></span></label>';
            modalHTML += '<div class="modal-color-swatches" id="modalColorSwatches">';
            colores.forEach(function (c, i) {
                const colorMap = getColorHex(c);
                modalHTML += '<button class="modal-color-swatch' + (i === 0 ? ' active' : '') + '" ';
                modalHTML += 'data-color="' + escapeHTML(c) + '" ';
                modalHTML += 'style="background-color: ' + colorMap + '" ';
                modalHTML += 'title="' + escapeHTML(c) + '" ';
                modalHTML += 'onclick="selectModalColor(this)">';
                modalHTML += '</button>';
            });
            modalHTML += '</div>';
            modalHTML += '</div>';
        }

        // Talla
        if (tallas.length > 0) {
            modalHTML += '<div class="variant-group" id="modalTallaGroup">';
            modalHTML += '<label class="variant-label">Talla</label>';
            modalHTML += '<div class="modal-talla-pills" id="modalTallaPills">';
            tallas.forEach(function (t, i) {
                modalHTML += '<button class="modal-talla-pill' + (i === 0 ? ' active' : '') + '" ';
                modalHTML += 'data-talla="' + escapeHTML(t) + '" ';
                modalHTML += 'onclick="selectModalTalla(this)">';
                modalHTML += escapeHTML(t);
                modalHTML += '</button>';
            });
            modalHTML += '</div>';
            modalHTML += '</div>';
        }

        modalHTML += '</div>'; // .modal-variants

        // Quantity selector
        modalHTML += '<div class="modal-quantity">';
        modalHTML += '<label class="variant-label">Cantidad</label>';
        modalHTML += '<div class="quantity-selector">';
        modalHTML += '<button class="qty-btn" onclick="changeModalQty(-1)">−</button>';
        modalHTML += '<input type="number" id="modalQtyInput" value="1" min="1" max="9999" onchange="validateModalQty()">';
        modalHTML += '<button class="qty-btn" onclick="changeModalQty(1)">+</button>';
        modalHTML += '</div>';
        modalHTML += '</div>';

        // Add to cart button
        modalHTML += '<button class="btn-add-to-cart-modal" id="btnAddToCartModal" onclick="addToCartFromModal()">';
        modalHTML += '🛒 Agregar al carrito';
        modalHTML += '</button>';

        // Stock info
        if (baseProduct.stock_disponible !== undefined && baseProduct.stock_disponible !== null) {
            const stockClass = baseProduct.stock_disponible > 10 ? 'in-stock' : (baseProduct.stock_disponible > 0 ? 'low-stock' : 'out-of-stock');
            const stockText = baseProduct.stock_disponible > 10 ? 'En stock' : (baseProduct.stock_disponible > 0 ? 'Pocas unidades' : 'Agotado');
            modalHTML += '<div class="modal-stock ' + stockClass + '">';
            modalHTML += '<span class="stock-dot"></span> ' + stockText;
            if (baseProduct.stock_disponible > 0) {
                modalHTML += ' (' + baseProduct.stock_disponible + ' disponibles)';
            }
            modalHTML += '</div>';
        }

        // Views counter
        modalHTML += '<div class="modal-views" id="modalViews">';
        modalHTML += '<span>👁 <span id="modalViewCount">0</span> visualizaciones</span>';
        modalHTML += '</div>';

        modalHTML += '</div>'; // .product-modal-info
        modalHTML += '</div>'; // .product-modal-body
        modalHTML += '</div>'; // .product-modal
        modalHTML += '</div>'; // .product-modal-overlay

        // Remove existing modal if any
        const existingModal = document.getElementById('productModalOverlay');
        if (existingModal) existingModal.remove();

        // Insert modal
        document.body.insertAdjacentHTML('beforeend', modalHTML);

        // Store data for cart
        window._currentModalProduct = {
            product: baseProduct,
            variants: variants,
            images: images,
            presentaciones: presentaciones,
            colores: colores,
            tallas: tallas
        };

        // Show with animation
        requestAnimationFrame(function () {
            const overlay = document.getElementById('productModalOverlay');
            if (overlay) overlay.classList.add('visible');
            document.body.style.overflow = 'hidden';
        });

        // Apply variant rules
        applyVariantRules();

        // Firebase analytics
        try {
            if (typeof incrementProductViews === 'function') {
                incrementProductViews(String(baseProduct.id_producto || baseProduct.nombre)).then(function () {
                    if (typeof getProductViews === 'function') {
                        getProductViews(String(baseProduct.id_producto || baseProduct.nombre)).then(function (count) {
                            const viewEl = document.getElementById('modalViewCount');
                            if (viewEl) viewEl.textContent = count || 0;
                        });
                    }
                });
            }
            if (typeof logViewItem === 'function') {
                logViewItem({
                    item_id: String(baseProduct.id_producto || ''),
                    item_name: baseProduct.nombre,
                    item_category: baseProduct.categoria_principal || '',
                    price: basePrice,
                    currency: currency
                });
            }
        } catch (e) {
            console.warn('Analytics error:', e);
        }
    };

    /* ------------------------------------------
       APPLY VARIANT RULES
    ------------------------------------------ */
    window.applyVariantRules = function () {
        const data = window._currentModalProduct;
        if (!data) return;

        const presSelect = document.getElementById('modalPresentacion');
        const colorGroup = document.getElementById('modalColorGroup');
        const tallaGroup = document.getElementById('modalTallaGroup');
        const priceEl = document.getElementById('modalProductPrice');

        let selectedPres = '';
        if (presSelect) {
            selectedPres = presSelect.value.toLowerCase().trim();
        }

        const isDocenaOrBulto = selectedPres.includes('docena') || selectedPres.includes('bulto') || selectedPres.includes('cerrada');
        const isUnidad = selectedPres.includes('unidad');

        // Color group
        if (colorGroup) {
            const swatches = colorGroup.querySelectorAll('.modal-color-swatch');
            if (isDocenaOrBulto) {
                colorGroup.style.opacity = '0.4';
                colorGroup.style.pointerEvents = 'none';
                swatches.forEach(function (s) { s.classList.remove('active'); });
                const nameEl = document.getElementById('selectedColorName');
                if (nameEl) nameEl.textContent = '(Surtido)';
            } else {
                colorGroup.style.opacity = '1';
                colorGroup.style.pointerEvents = 'auto';
                const nameEl = document.getElementById('selectedColorName');
                if (nameEl) {
                    const activeColor = colorGroup.querySelector('.modal-color-swatch.active');
                    nameEl.textContent = activeColor ? '- ' + activeColor.getAttribute('data-color') : '';
                }
            }
        }

        // Talla group
        if (tallaGroup) {
            const pills = tallaGroup.querySelectorAll('.modal-talla-pill');
            if (isDocenaOrBulto) {
                tallaGroup.style.opacity = '0.4';
                tallaGroup.style.pointerEvents = 'none';
                pills.forEach(function (p) { p.classList.remove('active'); });
            } else {
                tallaGroup.style.opacity = '1';
                tallaGroup.style.pointerEvents = 'auto';
            }
        }

        // Update price based on selected variant
        if (priceEl && data.variants.length > 0) {
            const matchedVariant = findMatchingVariant();
            if (matchedVariant) {
                const price = parseFloat(matchedVariant.precio_base) || 0;
                const currency = matchedVariant.moneda || 'USD';
                priceEl.querySelector('.price-value').textContent = formatPriceModal(price, currency);
            }
        }
    };

    /* ------------------------------------------
       FIND MATCHING VARIANT
    ------------------------------------------ */
    function findMatchingVariant() {
        const data = window._currentModalProduct;
        if (!data || !data.variants) return data ? data.product : null;

        const presSelect = document.getElementById('modalPresentacion');
        const activeColor = document.querySelector('#modalColorSwatches .modal-color-swatch.active');
        const activeTalla = document.querySelector('#modalTallaPills .modal-talla-pill.active');

        const selectedPres = presSelect ? presSelect.value.toLowerCase().trim() : '';
        const selectedColor = activeColor ? activeColor.getAttribute('data-color').toLowerCase().trim() : '';
        const selectedTalla = activeTalla ? activeTalla.getAttribute('data-talla').toLowerCase().trim() : '';

        let bestMatch = null;
        let bestScore = -1;

        data.variants.forEach(function (v) {
            let score = 0;
            if (v.variantes && Array.isArray(v.variantes)) {
                v.variantes.forEach(function (attr) {
                    const key = (attr.atributo || '').toLowerCase().trim();
                    const val = (attr.valor || '').toLowerCase().trim();
                    if ((key === 'presentación' || key === 'presentacion') && val === selectedPres) score += 3;
                    if (key === 'color' && val === selectedColor) score += 2;
                    if (key === 'talla' && val === selectedTalla) score += 1;
                });
            }
            if (score > bestScore) {
                bestScore = score;
                bestMatch = v;
            }
        });

        return bestMatch || data.product;
    }

    /* ------------------------------------------
       ADD TO CART FROM MODAL
    ------------------------------------------ */
    window.addToCartFromModal = function () {
        const data = window._currentModalProduct;
        if (!data) return;

        const presSelect = document.getElementById('modalPresentacion');
        const activeColor = document.querySelector('#modalColorSwatches .modal-color-swatch.active');
        const activeTalla = document.querySelector('#modalTallaPills .modal-talla-pill.active');
        const qtyInput = document.getElementById('modalQtyInput');

        const selectedPres = presSelect ? presSelect.value : '';
        const isDocenaOrBulto = selectedPres.toLowerCase().includes('docena') || selectedPres.toLowerCase().includes('bulto') || selectedPres.toLowerCase().includes('cerrada');
        const isUnidad = selectedPres.toLowerCase().includes('unidad');

        let selectedColor = activeColor ? activeColor.getAttribute('data-color') : '';
        let selectedTalla = activeTalla ? activeTalla.getAttribute('data-talla') : '';

        if (isDocenaOrBulto) {
            selectedColor = 'Surtido';
            selectedTalla = 'Surtido';
        } else if (isUnidad) {
            // Validate required fields for "Unidad"
            if (document.getElementById('modalColorGroup') && !selectedColor) {
                if (typeof showToast === 'function') showToast('Por favor selecciona un color para la compra por unidad', 'error');
                return;
            }
            if (document.getElementById('modalTallaGroup') && !selectedTalla) {
                if (typeof showToast === 'function') showToast('Por favor selecciona una talla para la compra por unidad', 'error');
                return;
            }
        }

        const quantity = parseInt(qtyInput ? qtyInput.value : 1) || 1;

        const matchedVariant = findMatchingVariant();
        const price = parseFloat(matchedVariant ? matchedVariant.precio_base : data.product.precio_base) || 0;
        const currency = matchedVariant ? (matchedVariant.moneda || 'USD') : (data.product.moneda || 'USD');

        // Build cart key
        const cartKey = data.product.nombre + '|' + selectedColor + '|' + selectedTalla + '|' + selectedPres;

        // Get current cart
        const cartData = getCartFromStorage();

        if (cartData[cartKey]) {
            cartData[cartKey].quantity += quantity;
        } else {
            cartData[cartKey] = {
                productName: data.product.nombre,
                productId: data.product.id_producto || '',
                color: selectedColor,
                talla: selectedTalla,
                presentacion: selectedPres,
                price: price,
                currency: currency,
                quantity: quantity,
                image: data.product.imagen_url || '',
                category: data.product.categoria_principal || ''
            };
        }

        // Save to localStorage
        saveCartToStorage(cartData);

        // Show toast
        if (typeof showToast === 'function') {
            showToast('Producto agregado al carrito', 'success');
        }

        // Update cart badge
        updateCartBadge();

        // Firebase
        try {
            if (typeof logAddToCart === 'function') {
                logAddToCart({
                    item_id: String(data.product.id_producto || ''),
                    item_name: data.product.nombre,
                    item_category: data.product.categoria_principal || '',
                    price: price,
                    currency: currency,
                    quantity: quantity
                });
            }
        } catch (e) {
            console.warn('Analytics error:', e);
        }

        // Sync with Odoo backend
        syncCartWithOdoo(data.product, matchedVariant, quantity, price);
    };

    /* ------------------------------------------
       SYNC WITH ODOO
    ------------------------------------------ */
    function syncCartWithOdoo(product, variant, quantity, price) {
        const backendUrl = (typeof BACKEND_URL !== 'undefined') ? BACKEND_URL : 'http://localhost:3000';
        let currentOrderId = null;
        try { currentOrderId = localStorage.getItem('listex_odoo_order_id'); } catch (e) { }

        if (!currentOrderId) {
            // Create order first
            fetch(backendUrl + '/api/cart/create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    product_id: product.id_producto,
                    product_name: product.nombre
                })
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data && data.order_id) {
                        try { localStorage.setItem('listex_odoo_order_id', data.order_id); } catch (e) { }
                        currentOrderId = data.order_id;
                        addLineToOdoo(backendUrl, currentOrderId, product, variant, quantity, price);
                    }
                })
                .catch(function (err) {
                    console.warn('Error creating Odoo order:', err);
                });
        } else {
            addLineToOdoo(backendUrl, currentOrderId, product, variant, quantity, price);
        }
    }

    function addLineToOdoo(backendUrl, orderId, product, variant, quantity, price) {
        const presSelect = document.getElementById('modalPresentacion');
        const selectedPres = presSelect ? presSelect.value : '';
        const activeColor = document.querySelector('#modalColorSwatches .modal-color-swatch.active');
        const activeTalla = document.querySelector('#modalTallaPills .modal-talla-pill.active');
        
        const isDocenaOrBulto = selectedPres.toLowerCase().includes('docena') || selectedPres.toLowerCase().includes('bulto') || selectedPres.toLowerCase().includes('cerrada');
        const color = isDocenaOrBulto ? 'Surtido' : (activeColor ? activeColor.getAttribute('data-color') : '');
        const talla = isDocenaOrBulto ? 'Surtido' : (activeTalla ? activeTalla.getAttribute('data-talla') : '');

        let variantInfo = [];
        if (selectedPres) variantInfo.push(selectedPres);
        if (color) variantInfo.push(`Color: ${color}`);
        if (talla) variantInfo.push(`Talla: ${talla}`);

        fetch(backendUrl + '/api/cart/add-line', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                order_id: parseInt(orderId, 10),
                product_id: parseInt(product.id_producto || variant.id_producto, 10),
                name: product.nombre,
                quantity: quantity,
                price_unit: price,
                variant_info: variantInfo.join(' | ')
            })
        })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (data && data.success) {
                    console.log('Line added to Odoo order successfully');
                } else {
                    console.warn('Odoo returned error when adding line:', data);
                }
            })
            .catch(function (err) {
                console.warn('Error adding line to Odoo:', err);
            });
    }

    /* ------------------------------------------
       CLOSE MODAL
    ------------------------------------------ */
    window.closeProductModal = function () {
        const overlay = document.getElementById('productModalOverlay');
        if (overlay) {
            overlay.classList.remove('visible');
            document.body.style.overflow = '';
            setTimeout(function () {
                overlay.remove();
            }, 300);
        }
        window._currentModalProduct = null;
    };

    window.closeProductModalOverlay = function (event) {
        if (event.target.id === 'productModalOverlay') {
            closeProductModal();
        }
    };

    /* ------------------------------------------
       IMAGE GALLERY
    ------------------------------------------ */
    window.switchModalImage = function (src, thumbBtn) {
        const mainImage = document.getElementById('modalMainImage');
        if (mainImage && src) {
            mainImage.innerHTML = '<img src="' + escapeHTML(src) + '" alt="Producto" onerror="this.parentElement.innerHTML=\'<div class=placeholder-img>📦</div>\'">';
        }
        // Update active thumbnail
        const thumbs = document.querySelectorAll('.product-modal-thumbnails .thumbnail');
        thumbs.forEach(function (t) { t.classList.remove('active'); });
        if (thumbBtn) thumbBtn.classList.add('active');
    };

    /* ------------------------------------------
       COLOR SELECTION
    ------------------------------------------ */
    window.selectModalColor = function (btn) {
        const swatches = document.querySelectorAll('#modalColorSwatches .modal-color-swatch');
        swatches.forEach(function (s) { s.classList.remove('active'); });
        btn.classList.add('active');

        const nameEl = document.getElementById('selectedColorName');
        if (nameEl) nameEl.textContent = '- ' + btn.getAttribute('data-color');

        // Update image if variant has specific image
        updateImageForVariant();
        applyVariantRules();
    };

    /* ------------------------------------------
       TALLA SELECTION
    ------------------------------------------ */
    window.selectModalTalla = function (btn) {
        const pills = document.querySelectorAll('#modalTallaPills .modal-talla-pill');
        pills.forEach(function (p) { p.classList.remove('active'); });
        btn.classList.add('active');

        updateImageForVariant();
        applyVariantRules();
    };

    /* ------------------------------------------
       UPDATE IMAGE FOR SELECTED VARIANT
    ------------------------------------------ */
    function updateImageForVariant() {
        const matched = findMatchingVariant();
        if (matched && matched.imagen_url) {
            const mainImage = document.getElementById('modalMainImage');
            if (mainImage) {
                mainImage.innerHTML = '<img src="' + escapeHTML(matched.imagen_url) + '" alt="Producto" onerror="this.parentElement.innerHTML=\'<div class=placeholder-img>📦</div>\'">';
            }
        }
    }

    /* ------------------------------------------
       QUANTITY
    ------------------------------------------ */
    window.changeModalQty = function (delta) {
        const input = document.getElementById('modalQtyInput');
        if (!input) return;
        let val = parseInt(input.value) || 1;
        val += delta;
        if (val < 1) val = 1;
        if (val > 9999) val = 9999;
        input.value = val;
    };

    window.validateModalQty = function () {
        const input = document.getElementById('modalQtyInput');
        if (!input) return;
        let val = parseInt(input.value) || 1;
        if (val < 1) val = 1;
        if (val > 9999) val = 9999;
        input.value = val;
    };

    /* ------------------------------------------
       HELPERS
    ------------------------------------------ */
    function escapeHTML(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function formatPriceModal(amount, currency) {
        if (typeof formatPrice === 'function') {
            return formatPrice(amount, currency);
        }
        const cur = currency || 'USD';
        return cur + ' ' + parseFloat(amount).toFixed(2);
    }

    function getColorHex(colorName) {
        const map = {
            'negro': '#1a1a1a', 'blanco': '#ffffff', 'rojo': '#ef4444', 'azul': '#3b82f6',
            'verde': '#22c55e', 'amarillo': '#eab308', 'rosa': '#ec4899', 'morado': '#a855f7',
            'naranja': '#f97316', 'gris': '#6b7280', 'beige': '#d4a574', 'marrón': '#8b4513',
            'marron': '#8b4513', 'celeste': '#67e8f9', 'fucsia': '#d946ef', 'turquesa': '#14b8a6',
            'coral': '#f87171', 'nude': '#e8c4a0', 'crema': '#fef3c7', 'vino': '#7f1d1d',
            'borgoña': '#800020', 'borgona': '#800020', 'lavanda': '#c4b5fd', 'salmon': '#fca5a5',
            'salmón': '#fca5a5', 'chocolate': '#7b3f00', 'lila': '#c084fc', 'aqua': '#06b6d4',
            'dorado': '#d4a017', 'plateado': '#c0c0c0', 'caqui': '#c3b091', 'menta': '#a7f3d0',
            'durazno': '#fbbf24', 'surtido': 'linear-gradient(135deg, #ef4444, #3b82f6, #22c55e, #eab308)',
            'multicolor': 'linear-gradient(135deg, #ef4444, #3b82f6, #22c55e, #eab308)'
        };
        const lower = (colorName || '').toLowerCase().trim();
        return map[lower] || '#9ca3af';
    }

    function getCartFromStorage() {
        try {
            const raw = localStorage.getItem('listex_cart');
            return raw ? JSON.parse(raw) : {};
        } catch (e) {
            return {};
        }
    }

    function saveCartToStorage(cartData) {
        try {
            localStorage.setItem('listex_cart', JSON.stringify(cartData));
        } catch (e) {
            console.warn('Error saving cart:', e);
        }
    }

    function updateCartBadge() {
        const cartData = getCartFromStorage();
        let totalItems = 0;
        Object.keys(cartData).forEach(function (key) {
            totalItems += cartData[key].quantity || 0;
        });
        const badges = document.querySelectorAll('.cart-badge, .cart-count, #cartBadge');
        badges.forEach(function (badge) {
            badge.textContent = totalItems;
            badge.style.display = totalItems > 0 ? 'flex' : 'none';
        });
    }

    // Keyboard close
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeProductModal();
        }
    });

    // Init cart badge on load
    document.addEventListener('DOMContentLoaded', function () {
        updateCartBadge();
    });

})();
