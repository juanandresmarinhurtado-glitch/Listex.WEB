const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

common.methodCall('authenticate', [db, username, password, {}], function (error, uid) {
    if (error) return console.error(error);

    // Create custom form view
    const viewData = {
        name: 'proveedores.pendientes.form',
        type: 'form',
        model: 'res.partner',
        arch_base: `
            <form string="Proveedor">
                <sheet>
                    <div class="oe_title">
                        <h1><field name="name" placeholder="Nombre del Proveedor"/></h1>
                    </div>
                    <group>
                        <group>
                            <field name="email"/>
                            <field name="phone"/>
                            <field name="x_studio_supplier_rif"/>
                        </group>
                        <group>
                            <field name="x_studio_supplier_status" widget="radio"/>
                            <field name="x_studio_portal_password" password="True"/>
                            <field name="x_studio_is_portal_supplier" invisible="1"/>
                        </group>
                    </group>
                </sheet>
            </form>
        `
    };

    models.methodCall('execute_kw', [db, uid, password, 'ir.ui.view', 'create', [viewData]], function (err, viewId) {
        if (err) return console.error("Form View Error:", err);
        console.log("Created Form View ID:", viewId);

        // Find existing tree view for the action (we created it earlier, id 13611)
        // Wait, act_window.view_id only holds ONE view. To link multiple views (tree and form), 
        // we use ir.actions.act_window.view binding.
        
        // 1. Unset the hardcoded view_id from the action so it uses view_ids bindings
        models.methodCall('execute_kw', [db, uid, password, 'ir.actions.act_window', 'write', [[3046], { view_id: false }]], function (err) {
            
            // 2. Link Tree View
            models.methodCall('execute_kw', [db, uid, password, 'ir.actions.act_window.view', 'create', [{
                sequence: 1,
                view_mode: 'list',
                view_id: 13611,
                act_window_id: 3046
            }]], function(err) {
                if(err) console.error("Link Tree Error", err);

                // 3. Link Form View
                models.methodCall('execute_kw', [db, uid, password, 'ir.actions.act_window.view', 'create', [{
                    sequence: 2,
                    view_mode: 'form',
                    view_id: viewId,
                    act_window_id: 3046
                }]], function(err) {
                    if(err) console.error("Link Form Error", err);
                    console.log("Form view linked successfully to action 3046!");
                });
            });
        });
    });
});
