const fs = require('fs');
const path = require('path');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

// 1. Cache Categories
const getCategoriesRegex = /app\.get\('\/api\/categories', async \(req, res\) => \{[\s\S]*?\}\);/;

const newCategoriesCode = `
let globalCategories = null;
app.get('/api/categories', async (req, res) => {
    if (globalCategories) return res.json({ success: true, categories: globalCategories });
    try {
        await authenticate();
        globalCategories = await executeKw('product.public.category', 'search_read', [[]], { fields: ['id', 'name'] });
        res.json({ success: true, categories: globalCategories });
    } catch (error) {
        if (globalCategories) return res.json({ success: true, categories: globalCategories });
        res.status(500).json({ error: error.message });
    }
});`;

serverJs = serverJs.replace(getCategoriesRegex, newCategoriesCode);

// 2. Persistent Dashboard Cache
const getDashboardRegex = /const supplierProductsCache = \{\};\s+app\.get\('\/api\/supplier\/products', authenticateSupplier, async \(req, res\) => \{[\s\S]*?(?=\napp\.post\('\/api\/supplier\/products',)/;

const newDashboardCode = `
const dashCacheFile = path.join(__dirname, 'dashboard_cache.json');
function readDashCache() { try { return JSON.parse(fs.readFileSync(dashCacheFile, 'utf8')); } catch(e) { return {}; } }
function writeDashCache(data) { fs.writeFileSync(dashCacheFile, JSON.stringify(data, null, 2)); }

app.get('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        const partnerId = req.user.id;
        const cache = readDashCache();
        
        let cachedProducts = [];
        if (cache[partnerId]) {
            cachedProducts = cache[partnerId].products;
        }
        
        const mergedProducts = [...cachedProducts];
        try {
            const queue = readJson(queueFile);
            for (const [tempId, item] of Object.entries(queue)) {
                if (item.partner_id === partnerId && (item.status === 'pending' || item.status === 'processing' || item.status === 'error')) {
                    if (!mergedProducts.find(p => p.id === tempId)) {
                        mergedProducts.unshift({
                            id: tempId,
                            name: item.data.name + (item.status==='error' ? ' (Error)' : ' (Procesando...)'),
                            list_price: item.data.priceUnidad,
                            standard_price: item.data.cost,
                            qty_available: 0,
                            is_published: false,
                            isPending: true
                        });
                    }
                }
            }
        } catch(e) {}
        
        if (mergedProducts.length > 0) {
            res.json({ success: true, products: mergedProducts });
        }
        
        authenticate().then(async () => {
            const supplierInfos = await executeKw('product.supplierinfo', 'search_read', [
                [['partner_id', '=', partnerId]]
            ], { fields: ['product_tmpl_id'] });
            
            let freshProducts = [];
            if (supplierInfos.length > 0) {
                const templateIds = supplierInfos.map(s => s.product_tmpl_id[0]);
                freshProducts = await executeKw('product.template', 'search_read', [
                    [['id', 'in', templateIds]],
                    ['id', 'name', 'list_price', 'standard_price', 'qty_available', 'is_published', 'image_128']
                ]);
            }
            const c = readDashCache();
            c[partnerId] = { timestamp: Date.now(), products: freshProducts };
            writeDashCache(c);
        }).catch(err => console.error("Background Cache Refresh Error:", err));
        
        if (mergedProducts.length === 0) {
            setTimeout(() => {
                if (!res.headersSent) {
                    const c2 = readDashCache();
                    if (c2[partnerId]) res.json({ success: true, products: c2[partnerId].products });
                    else res.json({ success: true, products: [] });
                }
            }, 1500);
        }
        
    } catch (error) {
        if (!res.headersSent) res.status(500).json({ error: error.message });
    }
});`;

serverJs = serverJs.replace(getDashboardRegex, newDashboardCode);

// 3. Fix the "temp_var" ReferenceError bug once and for all in HTML
// The user said "no muestra las variantes". I suspect the HTML `onclick="updateVariantStock(temp_var_123)"` is breaking the browser's DOM parser or something, or I missed a quote replacement!
// Wait! `v.id` is not standard ID compliant if it has dots or brackets, but it doesn't.
// Let's ensure the JS literal generation is absolutely foolproof.
let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// Look for updateVariantStock(\${v.id}) and replace with updateVariantStock('\${v.id}')
// Actually I already replaced it correctly. But just to be sure, I will inject a wrapper function in `proveedores.html` that finds buttons.
// Wait, no, the simplest way is to pass `v.id` as a string.

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Patched server.js with extreme caching");
