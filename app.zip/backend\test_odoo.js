const xmlrpc = require('xmlrpc');

const url = 'https://listex.odoo.com';
const db = 'listex'; // Usually the subdomain
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });

common.methodCall('authenticate', [db, username, password, {}], function (error, uid) {
    if (error) {
        console.error("Auth Error:", error);
    } else {
        console.log("Authenticated successfully. UID:", uid);
    }
});
