const fs = require('fs');
const jsdom = require('jsdom');
const { JSDOM } = jsdom;

const html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

const dom = new JSDOM(html, { runScripts: "outside-only", url: "http://localhost/" });
const window = dom.window;
const document = window.document;

// Mock globals
window.API_BASE = '/api/supplier';
window.getAuthHeaders = () => ({});
window.switchTab = () => {};
window.showToast = (msg) => { console.log("TOAST:", msg); };
window.base64Image = null;

// Mock fetch
window.fetch = async (url) => {
    return {
        json: async () => ({
            success: true,
            product: {
                id: 1468,
                name: "Test Product",
                cost: 10,
                priceUnidad: 20,
                categoryId: "",
                isStorable: true,
                priceDocena: 18,
                priceBulto: 15,
                imageBase64: false,
                variants: [
                    { id: 5707, attribute_names: "Talla S", qty_available: 0, image_variant_1920: false }
                ]
            }
        })
    };
};

// Extract and run JS
const scriptCode = html.substring(html.indexOf('<script>') + 8, html.lastIndexOf('</script>'));

try {
    window.eval(scriptCode);
    console.log("Script evaluated.");
    
    // Test openEditModal
    window.openEditModal(1468).then(() => {
        console.log("openEditModal finished.");
        console.log("Prod Name:", document.getElementById('prod-name').value);
        console.log("Variants HTML:", document.getElementById('inline-variants-list').innerHTML.substring(0, 50));
    }).catch(e => {
        console.error("Promise rejected:", e);
    });
} catch (e) {
    console.error("Eval error:", e);
}
