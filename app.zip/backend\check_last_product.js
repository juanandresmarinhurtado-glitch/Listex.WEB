const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        const lastProduct = await executeKw('product.template', 'search_read', [
            []
        ], { limit: 1, order: 'id desc', fields: ['id', 'name', 'attribute_line_ids', 'product_variant_ids', 'active', 'sale_ok'] });
        
        console.log("Last product:", JSON.stringify(lastProduct, null, 2));
        
        if (lastProduct[0].attribute_line_ids.length > 0) {
            const lines = await executeKw('product.template.attribute.line', 'read', [
                lastProduct[0].attribute_line_ids
            ]);
            console.log("Attribute lines:", JSON.stringify(lines, null, 2));
        }
        
    } catch (e) {
        console.error("Error:", e);
    }
});
