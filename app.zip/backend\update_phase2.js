const fs = require('fs');

// --- 1. PATCH SERVER.JS ---
let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const newPostRoute = `
app.post('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const { name, cost, priceUnidad, priceDocena, priceBulto, categoryId, customAttributes, imageBase64 } = req.body;
        
        // Helper to find or create attribute
        async function getOrCreateAttribute(attrName) {
            const attrs = await executeKw('product.attribute', 'search_read', [[['name', '=', attrName]], ['id']]);
            if (attrs.length > 0) return attrs[0].id;
            return await executeKw('product.attribute', 'create', [{ name: attrName, create_variant: 'dynamic' }]);
        }

        // Helper to find or create attribute value
        async function getOrCreateAttrValue(attrId, valName) {
            const vals = await executeKw('product.attribute.value', 'search_read', [[['attribute_id', '=', attrId], ['name', '=', valName]], ['id']]);
            if (vals.length > 0) return vals[0].id;
            return await executeKw('product.attribute.value', 'create', [{ attribute_id: attrId, name: valName }]);
        }

        // 1. Create Product Template (Without Taxes)
        const productData = {
            name: name,
            list_price: parseFloat(priceUnidad) || 0,
            standard_price: parseFloat(cost) || 0,
            sale_ok: true,
            purchase_ok: true,
            is_published: false,
            taxes_id: false, // NO IMPUESTOS
            supplier_taxes_id: false // NO IMPUESTOS
        };
        
        if (imageBase64) {
            productData.image_1920 = imageBase64.split(',')[1] || imageBase64;
        }
        
        if (categoryId) {
            productData.public_categ_ids = [[6, 0, [parseInt(categoryId)]]];
        }
        
        const tmplId = await executeKw('product.template', 'create', [productData]);
        
        await executeKw('product.template', 'write', [[tmplId], { is_published: true }]);
        
        // 2. Link Supplier
        await executeKw('product.supplierinfo', 'create', [{
            partner_id: req.user.id,
            product_tmpl_id: tmplId,
            delay: 1
        }]);
        
        // 3. Handle "Presentación"
        const presentacionId = await getOrCreateAttribute('Presentación');
        let presValIds = [];
        
        const unidadId = await getOrCreateAttrValue(presentacionId, 'unidad variada');
        presValIds.push(unidadId);
        
        if (priceDocena) {
            const docenaId = await getOrCreateAttrValue(presentacionId, 'docena cerrada');
            presValIds.push(docenaId);
        }
        if (priceBulto) {
            const bultoId = await getOrCreateAttrValue(presentacionId, 'bulto');
            presValIds.push(bultoId);
        }
        
        await executeKw('product.template.attribute.line', 'create', [{
            product_tmpl_id: tmplId,
            attribute_id: presentacionId,
            value_ids: [[6, 0, presValIds]]
        }]);

        // 4. Handle Custom Attributes (Tallas, Colores, etc)
        if (customAttributes && customAttributes.length > 0) {
            for (let attr of customAttributes) {
                if (!attr.name || !attr.values || attr.values.length === 0) continue;
                const attrId = await getOrCreateAttribute(attr.name);
                let valIds = [];
                for (let v of attr.values) {
                    if (!v.trim()) continue;
                    valIds.push(await getOrCreateAttrValue(attrId, v.trim()));
                }
                if (valIds.length > 0) {
                    await executeKw('product.template.attribute.line', 'create', [{
                        product_tmpl_id: tmplId,
                        attribute_id: attrId,
                        value_ids: [[6, 0, valIds]]
                    }]);
                }
            }
        }
        
        // 5. Set Pricelists
        if (priceDocena) {
            await executeKw('product.pricelist.item', 'create', [{
                pricelist_id: 3,
                applied_on: '1_product',
                product_tmpl_id: tmplId,
                compute_price: 'fixed',
                fixed_price: parseFloat(priceDocena)
            }]);
        }
        
        if (priceBulto) {
            await executeKw('product.pricelist.item', 'create', [{
                pricelist_id: 2,
                applied_on: '1_product',
                product_tmpl_id: tmplId,
                compute_price: 'fixed',
                fixed_price: parseFloat(priceBulto)
            }]);
        }
        
        res.json({ success: true, message: "Producto creado exitosamente", id: tmplId });
    } catch (error) {
        console.error("Create Product Error:", error);
        res.status(500).json({ error: error.message });
    }
});
`;

// Extract existing file parts
const startMarker = "app.post('/api/supplier/products'";
const endMarker = "// Categories endpoint";

const startIndex = serverJs.indexOf(startMarker);
const endIndex = serverJs.indexOf(endMarker);

if (startIndex !== -1 && endIndex !== -1) {
    const newFileContent = serverJs.substring(0, startIndex) + newPostRoute + "\n" + serverJs.substring(endIndex);
    fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', newFileContent, 'utf8');
    console.log("server.js updated successfully.");
} else {
    console.log("Could not find markers in server.js");
}


// --- 2. PATCH HTML ---
let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

const additionalAttrHTML = `
                                <div style="background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; padding: 12px; border-radius: 8px; font-size: 0.85rem; margin-top: 10px;">
                                    <strong>Nota importante:</strong> Llenar los precios de Docena o Bulto habilitará automáticamente esas opciones de compra masiva en la tienda.
                                </div>

                                <div class="form-section" style="margin-top: 20px; padding: 20px;">
                                    <h3 style="font-size: 1rem; margin-bottom: 10px;"><ion-icon name="options-outline"></ion-icon> Atributos Adicionales (Opcional)</h3>
                                    <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 15px;">Ejemplo: Talla (S, M, L) o Color (Rojo, Azul).</p>
                                    <div id="custom-attributes-container"></div>
                                    <button type="button" class="btn btn-secondary w-100" onclick="addAttributeRow()" style="padding: 10px; font-size: 0.9rem;">+ Agregar Atributo</button>
                                </div>
`;

if (!html.includes('Atributos Adicionales (Opcional)')) {
    html = html.replace(
        `<div style="background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; padding: 12px; border-radius: 8px; font-size: 0.85rem; margin-top: 10px;">
                                    <strong>Nota importante:</strong> Llenar los precios de Docena o Bulto habilitará automáticamente esas opciones de compra masiva en la tienda.
                                </div>`,
        additionalAttrHTML
    );
}

// Add JS for dynamic attributes
const dynamicJS = `
        function addAttributeRow() {
            const container = document.getElementById('custom-attributes-container');
            const row = document.createElement('div');
            row.style.cssText = "display:flex; gap:10px; margin-bottom:10px; align-items:center;";
            row.innerHTML = \`
                <input type="text" class="attr-name" placeholder="Nombre (Ej: Talla)" style="flex:1; padding:8px; border:1px solid var(--border-color); border-radius:6px; font-size:0.85rem;">
                <input type="text" class="attr-values" placeholder="Valores separados por coma (Ej: S, M, L)" style="flex:2; padding:8px; border:1px solid var(--border-color); border-radius:6px; font-size:0.85rem;">
                <button type="button" onclick="this.parentElement.remove()" style="background:none; border:none; color:red; cursor:pointer; font-size:1.2rem;"><ion-icon name="trash-outline"></ion-icon></button>
            \`;
            container.appendChild(row);
        }
`;

if (!html.includes('function addAttributeRow()')) {
    html = html.replace('// CREATE PRODUCT', dynamicJS + '\n        // CREATE PRODUCT');
}

// Modify POST body
const extractCustomAttrs = `
                    priceBulto: document.getElementById('prod-price-bulto').value,
                    imageBase64: base64Image,
                    customAttributes: Array.from(document.getElementById('custom-attributes-container').children).map(row => ({
                        name: row.querySelector('.attr-name').value,
                        values: row.querySelector('.attr-values').value.split(',').map(v => v.trim()).filter(v => v)
                    }))
`;

html = html.replace(/priceBulto: document.getElementById\('prod-price-bulto'\).value,\s*imageBase64: base64Image/, extractCustomAttrs);

// Reset container
html = html.replace("document.getElementById('create-product-form').reset();", "document.getElementById('create-product-form').reset(); document.getElementById('custom-attributes-container').innerHTML = '';");

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("HTML updated successfully.");
