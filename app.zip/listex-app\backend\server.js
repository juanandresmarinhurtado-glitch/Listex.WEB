// Servidor Express para la plataforma mayorista Listex
// Conexión a Odoo mediante XML-RPC para gestión de pedidos y clientes

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const xmlrpc = require('xmlrpc');

const app = express();

// Configuración de middlewares
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Variables de entorno
const ODOO_URL = process.env.ODOO_URL;
const ODOO_DB = process.env.ODOO_DB;
const ODOO_USERNAME = process.env.ODOO_USERNAME;
const ODOO_API_KEY = process.env.ODOO_API_KEY;
const PORT = process.env.PORT || 3000;
const DEFAULT_PARTNER_ID = parseInt(process.env.DEFAULT_PARTNER_ID, 10) || 7;

// Extraer host y ruta base de la URL de Odoo
const odooUrlParsed = new URL(ODOO_URL);
const clientOptions = {
  host: odooUrlParsed.hostname,
  port: 443,
  path: '/xmlrpc/2/common'
};
const objectOptions = {
  host: odooUrlParsed.hostname,
  port: 443,
  path: '/xmlrpc/2/object'
};

// Caché del UID autenticado para evitar re-autenticaciones innecesarias
let cachedUid = null;

/**
 * Autenticación contra Odoo vía XML-RPC.
 * Retorna el UID del usuario autenticado y lo cachea para futuras llamadas.
 */
function odooAuthenticate() {
  return new Promise((resolve, reject) => {
    if (cachedUid) {
      return resolve(cachedUid);
    }

    const client = xmlrpc.createSecureClient(clientOptions);
    client.methodCall('authenticate', [ODOO_DB, ODOO_USERNAME, ODOO_API_KEY, {}], (error, uid) => {
      if (error) {
        console.error('Error de autenticación con Odoo:', error);
        return reject(new Error('No se pudo autenticar con Odoo'));
      }
      if (!uid || uid === false) {
        return reject(new Error('Credenciales de Odoo inválidas'));
      }
      cachedUid = uid;
      console.log('Autenticación exitosa con Odoo. UID:', uid);
      resolve(uid);
    });
  });
}

/**
 * Ejecuta un método en un modelo de Odoo vía XML-RPC.
 * @param {number} uid - ID del usuario autenticado
 * @param {string} model - Nombre del modelo de Odoo (ej: 'sale.order')
 * @param {string} method - Método a ejecutar (ej: 'create', 'write', 'search', 'read')
 * @param {Array} args - Argumentos posicionales
 * @param {Object} kwargs - Argumentos con nombre
 */
function executeKw(uid, model, method, args, kwargs = {}) {
  return new Promise((resolve, reject) => {
    const client = xmlrpc.createSecureClient(objectOptions);
    client.methodCall(
      'execute_kw',
      [ODOO_DB, uid, ODOO_API_KEY, model, method, args, kwargs],
      (error, result) => {
        if (error) {
          console.error(`Error ejecutando ${model}.${method}:`, error);
          return reject(error);
        }
        resolve(result);
      }
    );
  });
}

// ============================================================================
// RUTAS DEL CARRITO DE COMPRAS
// ============================================================================

/**
 * POST /api/cart/create
 * Crea un nuevo pedido de venta (sale.order) en estado borrador.
 */
app.post('/api/cart/create', async (req, res) => {
  try {
    const uid = await odooAuthenticate();
    const partnerId = req.body.partner_id || DEFAULT_PARTNER_ID;

    const orderId = await executeKw(uid, 'sale.order', 'create', [{
      partner_id: partnerId,
      state: 'draft'
    }]);

    console.log(`Pedido creado exitosamente. ID: ${orderId}, Cliente: ${partnerId}`);
    res.json({ success: true, order_id: orderId });
  } catch (error) {
    console.error('Error al crear pedido:', error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * POST /api/cart/add-line
 * Agrega una línea de producto a un pedido existente.
 */
app.post('/api/cart/add-line', async (req, res) => {
  try {
    const uid = await odooAuthenticate();
    const { order_id, product_id, quantity, price_unit, name, variant_info } = req.body;

    if (!order_id || !product_id || !quantity || !price_unit || !name) {
      return res.status(400).json({
        success: false,
        error: 'Faltan campos obligatorios: order_id, product_id, quantity, price_unit, name'
      });
    }

    // Si hay información de variante, se agrega a la descripción
    let description = name;
    if (variant_info) {
      description = `${name} - ${variant_info}`;
    }

    const lineId = await executeKw(uid, 'sale.order.line', 'create', [{
      order_id: order_id,
      product_id: product_id,
      product_uom_qty: quantity,
      price_unit: price_unit,
      name: description
    }]);

    console.log(`Línea agregada al pedido ${order_id}. Línea ID: ${lineId}, Producto: ${product_id}`);
    res.json({ success: true, line_id: lineId });
  } catch (error) {
    console.error('Error al agregar línea al pedido:', error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * PUT /api/cart/update-line
 * Actualiza la cantidad de una línea de pedido existente.
 */
app.put('/api/cart/update-line', async (req, res) => {
  try {
    const uid = await odooAuthenticate();
    const { line_id, quantity } = req.body;

    if (!line_id || !quantity) {
      return res.status(400).json({
        success: false,
        error: 'Faltan campos obligatorios: line_id, quantity'
      });
    }

    await executeKw(uid, 'sale.order.line', 'write', [[line_id], {
      product_uom_qty: quantity
    }]);

    console.log(`Línea ${line_id} actualizada. Nueva cantidad: ${quantity}`);
    res.json({ success: true });
  } catch (error) {
    console.error('Error al actualizar línea:', error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * DELETE /api/cart/remove-line
 * Elimina una línea de un pedido.
 */
app.delete('/api/cart/remove-line', async (req, res) => {
  try {
    const uid = await odooAuthenticate();
    const { line_id } = req.body;

    if (!line_id) {
      return res.status(400).json({
        success: false,
        error: 'Falta el campo obligatorio: line_id'
      });
    }

    await executeKw(uid, 'sale.order.line', 'unlink', [[line_id]]);

    console.log(`Línea ${line_id} eliminada del pedido`);
    res.json({ success: true });
  } catch (error) {
    console.error('Error al eliminar línea:', error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// RUTA DE CHECKOUT (FINALIZAR PEDIDO)
// ============================================================================

/**
 * POST /api/checkout
 * Finaliza un pedido asignando los datos del cliente y método de entrega.
 * Si el cliente no existe, lo crea automáticamente en Odoo.
 */
app.post('/api/checkout', async (req, res) => {
  try {
    const uid = await odooAuthenticate();
    const {
      order_id,
      name,
      vat,
      phone,
      email,
      street,
      city,
      state,
      delivery_method,
      notes
    } = req.body;

    if (!order_id || !name || !vat) {
      return res.status(400).json({
        success: false,
        error: 'Faltan campos obligatorios: order_id, name, vat'
      });
    }

    // Paso 1: Buscar si el cliente ya existe por su cédula/NIT
    let partnerId = null;
    const existingPartners = await executeKw(uid, 'res.partner', 'search', [
      [['vat', 'ilike', vat]]
    ]);

    if (existingPartners && existingPartners.length > 0) {
      // Cliente encontrado, usar el primero
      partnerId = existingPartners[0];
      console.log(`Cliente existente encontrado. ID: ${partnerId}, Cédula: ${vat}`);
    } else {
      // Paso 2: Crear nuevo cliente con todos los datos del formulario
      partnerId = await executeKw(uid, 'res.partner', 'create', [{
        name: name,
        vat: vat,
        phone: phone || '',
        email: email || '',
        street: street || '',
        city: city || '',
        comment: notes || ''
      }]);
      console.log(`Nuevo cliente creado. ID: ${partnerId}, Nombre: ${name}`);
    }

    // Paso 3: Actualizar el pedido con el cliente real y notas de entrega
    const noteText = `Método de entrega: ${delivery_method || 'No especificado'}. ${notes || ''}`.trim();
    await executeKw(uid, 'sale.order', 'write', [[order_id], {
      partner_id: partnerId,
      note: noteText
    }]);

    // Obtener el nombre/número del pedido para confirmación
    const orderData = await executeKw(uid, 'sale.order', 'read', [[order_id]], {
      fields: ['name']
    });

    const orderName = orderData && orderData.length > 0 ? orderData[0].name : `Pedido #${order_id}`;

    console.log(`Checkout completado. Pedido: ${orderName}, Cliente: ${partnerId}`);
    res.json({
      success: true,
      partner_id: partnerId,
      order_name: orderName
    });
  } catch (error) {
    console.error('Error en el checkout:', error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// RUTAS DEL PORTAL DE CLIENTES
// ============================================================================

/**
 * POST /api/portal/login
 * Inicio de sesión del cliente usando su número de cédula/NIT.
 */
app.post('/api/portal/login', async (req, res) => {
  try {
    const uid = await odooAuthenticate();
    const { vat } = req.body;

    if (!vat) {
      return res.status(400).json({
        success: false,
        error: 'Falta el campo obligatorio: vat (cédula)'
      });
    }

    // Buscar cliente por cédula
    const partnerIds = await executeKw(uid, 'res.partner', 'search', [
      [['vat', 'ilike', vat]]
    ]);

    if (!partnerIds || partnerIds.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Cliente no encontrado'
      });
    }

    // Leer datos del cliente encontrado
    const partnerData = await executeKw(uid, 'res.partner', 'read', [[partnerIds[0]]], {
      fields: ['id', 'name']
    });

    if (!partnerData || partnerData.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Cliente no encontrado'
      });
    }

    console.log(`Inicio de sesión exitoso. Cliente: ${partnerData[0].name}, ID: ${partnerData[0].id}`);
    res.json({
      success: true,
      user: {
        id: partnerData[0].id,
        name: partnerData[0].name
      }
    });
  } catch (error) {
    console.error('Error en inicio de sesión del portal:', error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/portal/dashboard/:partner_id
 * Panel de control del cliente con resumen de pedidos, productos favoritos y seguimiento.
 */
app.get('/api/portal/dashboard/:partner_id', async (req, res) => {
  try {
    const uid = await odooAuthenticate();
    const partnerId = parseInt(req.params.partner_id, 10);

    if (!partnerId || isNaN(partnerId)) {
      return res.status(400).json({
        success: false,
        error: 'ID de cliente inválido'
      });
    }

    // Buscar todos los pedidos del cliente
    const orderIds = await executeKw(uid, 'sale.order', 'search', [
      [
        ['partner_id', '=', partnerId],
        ['state', 'in', ['draft', 'sent', 'sale', 'done', 'cancel']]
      ]
    ]);

    // Si no hay pedidos, retornar datos vacíos
    if (!orderIds || orderIds.length === 0) {
      return res.json({
        summary: {
          total_orders: 0,
          total_spent: 0
        },
        top_products: [],
        orders: []
      });
    }

    // Leer datos de todos los pedidos
    const ordersData = await executeKw(uid, 'sale.order', 'read', [orderIds], {
      fields: ['id', 'name', 'date_order', 'amount_total', 'state', 'order_line']
    });

    // Calcular resumen general
    const totalOrders = ordersData.length;
    const totalSpent = ordersData
      .filter(order => ['sale', 'done'].includes(order.state))
      .reduce((sum, order) => sum + (order.amount_total || 0), 0);

    // Recopilar todos los IDs de líneas de pedido para análisis de productos
    const allLineIds = [];
    ordersData.forEach(order => {
      if (order.order_line && order.order_line.length > 0) {
        allLineIds.push(...order.order_line);
      }
    });

    // Leer líneas de pedido para calcular productos más comprados
    let topProducts = [];
    if (allLineIds.length > 0) {
      const linesData = await executeKw(uid, 'sale.order.line', 'read', [allLineIds], {
        fields: ['product_id', 'product_uom_qty']
      });

      // Agrupar por producto y sumar cantidades
      const productMap = {};
      linesData.forEach(line => {
        if (line.product_id && line.product_id.length >= 2) {
          const productId = line.product_id[0];
          const productName = line.product_id[1];
          if (!productMap[productId]) {
            productMap[productId] = {
              product_id: productId,
              product_name: productName,
              total_quantity: 0
            };
          }
          productMap[productId].total_quantity += line.product_uom_qty || 0;
        }
      });

      // Ordenar por cantidad y tomar los 5 principales
      topProducts = Object.values(productMap)
        .sort((a, b) => b.total_quantity - a.total_quantity)
        .slice(0, 5)
        .map(product => ({
          product_id: product.product_id,
          product_name: product.product_name,
          total_quantity: product.total_quantity,
          image_url: `${ODOO_URL}/web/image/product.product/${product.product_id}/image_256`
        }));
    }

    // Procesar cada pedido con información de seguimiento y estado inteligente
    const ordersWithTracking = await Promise.all(ordersData.map(async (order) => {
      let trackingInfo = [];

      try {
        // Buscar entregas (stock.picking) vinculadas al pedido
        const pickingIds = await executeKw(uid, 'stock.picking', 'search', [
          [['origin', '=', order.name]]
        ]);

        if (pickingIds && pickingIds.length > 0) {
          trackingInfo = await executeKw(uid, 'stock.picking', 'read', [pickingIds], {
            fields: ['x_studio_numero_de_guia', 'state']
          });
        }
      } catch (pickingError) {
        // Si falla la búsqueda de entregas, continuar sin datos de seguimiento
        console.error(`Error al obtener entregas del pedido ${order.name}:`, pickingError.message);
      }

      // Determinar estado inteligente basado en prioridades
      let smartStatus = '';
      let trackingNumber = null;

      // Prioridad 1: Verificar si hay número de guía en las entregas
      const pickingWithGuide = trackingInfo.find(
        p => p.x_studio_numero_de_guia && p.x_studio_numero_de_guia !== false
      );
      if (pickingWithGuide) {
        smartStatus = 'Pedido entregado en agencia';
        trackingNumber = pickingWithGuide.x_studio_numero_de_guia;
      }
      // Prioridad 2: Verificar si la entrega está completada (empacado)
      else if (trackingInfo.some(p => p.state === 'done')) {
        smartStatus = 'Pedido empacado';
      }
      // Prioridad 3: Pedido confirmado (pago verificado)
      else if (order.state === 'sale') {
        smartStatus = 'Pago confirmado';
      }
      // Prioridad 4: Pedido en borrador (esperando validación)
      else if (order.state === 'draft') {
        smartStatus = 'Esperando validación del pago';
      }
      // Prioridad 5: Pedido cancelado
      else if (order.state === 'cancel') {
        smartStatus = 'Pedido cancelado';
      }
      // Estado por defecto para estados no contemplados (ej: 'sent', 'done')
      else if (order.state === 'done') {
        smartStatus = 'Pedido finalizado';
      } else if (order.state === 'sent') {
        smartStatus = 'Presupuesto enviado';
      } else {
        smartStatus = order.state;
      }

      return {
        id: order.id,
        name: order.name,
        date_order: order.date_order,
        amount_total: order.amount_total,
        state: order.state,
        smart_status: smartStatus,
        tracking_number: trackingNumber,
        pickings: trackingInfo
      };
    }));

    console.log(`Dashboard cargado para cliente ${partnerId}. Pedidos: ${totalOrders}, Total gastado: ${totalSpent}`);
    res.json({
      summary: {
        total_orders: totalOrders,
        total_spent: totalSpent
      },
      top_products: topProducts,
      orders: ordersWithTracking
    });
  } catch (error) {
    console.error('Error al cargar dashboard del portal:', error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/portal/order/:order_id
 * Detalle completo de un pedido específico con líneas de producto y seguimiento.
 */
app.get('/api/portal/order/:order_id', async (req, res) => {
  try {
    const uid = await odooAuthenticate();
    const orderId = parseInt(req.params.order_id, 10);

    if (!orderId || isNaN(orderId)) {
      return res.status(400).json({
        success: false,
        error: 'ID de pedido inválido'
      });
    }

    // Leer datos completos del pedido
    const orderData = await executeKw(uid, 'sale.order', 'read', [[orderId]], {
      fields: [
        'id', 'name', 'date_order', 'amount_total', 'amount_untaxed',
        'amount_tax', 'state', 'partner_id', 'note', 'order_line',
        'currency_id', 'payment_term_id'
      ]
    });

    if (!orderData || orderData.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Pedido no encontrado'
      });
    }

    const order = orderData[0];

    // Leer las líneas del pedido con detalles del producto
    let orderLines = [];
    if (order.order_line && order.order_line.length > 0) {
      orderLines = await executeKw(uid, 'sale.order.line', 'read', [order.order_line], {
        fields: [
          'id', 'product_id', 'name', 'product_uom_qty',
          'price_unit', 'price_subtotal', 'price_total', 'discount'
        ]
      });

      // Agregar URL de imagen a cada línea
      orderLines = orderLines.map(line => ({
        ...line,
        product_image_url: line.product_id
          ? `${ODOO_URL}/web/image/product.product/${line.product_id[0]}/image_256`
          : null
      }));
    }

    // Buscar información de seguimiento (stock.picking)
    let trackingInfo = [];
    try {
      const pickingIds = await executeKw(uid, 'stock.picking', 'search', [
        [['origin', '=', order.name]]
      ]);

      if (pickingIds && pickingIds.length > 0) {
        trackingInfo = await executeKw(uid, 'stock.picking', 'read', [pickingIds], {
          fields: ['id', 'name', 'state', 'x_studio_numero_de_guia', 'scheduled_date', 'date_done']
        });
      }
    } catch (pickingError) {
      console.error(`Error al obtener entregas del pedido ${order.name}:`, pickingError.message);
    }

    // Calcular estado inteligente del pedido
    let smartStatus = '';
    let trackingNumber = null;

    const pickingWithGuide = trackingInfo.find(
      p => p.x_studio_numero_de_guia && p.x_studio_numero_de_guia !== false
    );
    if (pickingWithGuide) {
      smartStatus = 'Pedido entregado en agencia';
      trackingNumber = pickingWithGuide.x_studio_numero_de_guia;
    } else if (trackingInfo.some(p => p.state === 'done')) {
      smartStatus = 'Pedido empacado';
    } else if (order.state === 'sale') {
      smartStatus = 'Pago confirmado';
    } else if (order.state === 'draft') {
      smartStatus = 'Esperando validación del pago';
    } else if (order.state === 'cancel') {
      smartStatus = 'Pedido cancelado';
    } else if (order.state === 'done') {
      smartStatus = 'Pedido finalizado';
    } else if (order.state === 'sent') {
      smartStatus = 'Presupuesto enviado';
    } else {
      smartStatus = order.state;
    }

    console.log(`Detalle del pedido ${order.name} consultado exitosamente`);
    res.json({
      success: true,
      order: {
        id: order.id,
        name: order.name,
        date_order: order.date_order,
        amount_total: order.amount_total,
        amount_untaxed: order.amount_untaxed,
        amount_tax: order.amount_tax,
        state: order.state,
        smart_status: smartStatus,
        tracking_number: trackingNumber,
        partner: order.partner_id ? { id: order.partner_id[0], name: order.partner_id[1] } : null,
        note: order.note,
        currency: order.currency_id ? order.currency_id[1] : null,
        payment_term: order.payment_term_id ? order.payment_term_id[1] : null
      },
      lines: orderLines,
      tracking: trackingInfo
    });
  } catch (error) {
    console.error('Error al obtener detalle del pedido:', error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// INICIO DEL SERVIDOR
// ============================================================================

app.listen(PORT, () => {
  console.log(`Servidor Listex iniciado en el puerto ${PORT}`);
  console.log(`Conectando a Odoo: ${ODOO_URL}`);
  console.log(`Base de datos: ${ODOO_DB}`);
  console.log(`Entorno: desarrollo`);
});
