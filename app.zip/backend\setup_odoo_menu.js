const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

common.methodCall('authenticate', [db, username, password, {}], function (error, uid) {
    if (error) return console.error(error);

    // 1. Create Action
    const actionData = {
        name: 'Solicitudes de Proveedores',
        res_model: 'res.partner',
        view_mode: 'tree,form',
        domain: "[('x_studio_supplier_status', '=', 'pending')]",
        context: "{'default_x_studio_is_portal_supplier': True, 'default_x_studio_supplier_status': 'pending', 'default_supplier_rank': 1}"
    };

    models.methodCall('execute_kw', [db, uid, password, 'ir.actions.act_window', 'create', [actionData]], function (err, actionId) {
        if (err) return console.error("Action Error:", err);
        console.log("Created Action ID:", actionId);

        // 2. Find Contacts Root Menu to attach to, or create a new Root Menu. Let's attach to Contacts.
        // Or better, let's create a root menu "Portal Proveedores"
        const menuData = {
            name: 'Portal Proveedores',
            action: `ir.actions.act_window,${actionId}`,
            sequence: 10
        };

        models.methodCall('execute_kw', [db, uid, password, 'ir.ui.menu', 'create', [menuData]], function (err, menuId) {
            if (err) return console.error("Menu Error:", err);
            console.log("Created Root Menu ID:", menuId);
        });
    });
});
