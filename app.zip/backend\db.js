const { Pool } = require('pg');

const isInternal = process.env.DATABASE_URL && !process.env.DATABASE_URL.includes('.render.com');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: isInternal ? false : { rejectUnauthorized: false }
});

async function initDB() {
    try {
        const client = await pool.connect();
        try {
            await client.query(`
                CREATE TABLE IF NOT EXISTS queue_products (
                    id VARCHAR PRIMARY KEY,
                    partner_id INT,
                    status VARCHAR,
                    data JSONB,
                    timestamp BIGINT
                );
            `);
            
            await client.query(`
                CREATE TABLE IF NOT EXISTS queue_variants (
                    product_id VARCHAR PRIMARY KEY,
                    variants JSONB
                );
            `);
            
            await client.query(`
                CREATE TABLE IF NOT EXISTS dashboard_cache (
                    partner_id INT PRIMARY KEY,
                    products JSONB,
                    timestamp BIGINT
                );
            `);
            console.log("PostgreSQL tables initialized successfully.");
        } finally {
            client.release();
        }
    } catch (err) {
        console.error("Error connecting to or initializing PostgreSQL:", err.message);
    }
}

module.exports = {
    pool,
    initDB
};
