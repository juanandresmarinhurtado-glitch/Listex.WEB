const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

common.methodCall('authenticate', [db, username, password, {}], function (error, uid) {
    if (error) return console.error(error);

    // Update action 3046
    models.methodCall('execute_kw', [db, uid, password, 'ir.actions.act_window', 'write', [[3046], { view_mode: 'list,form' }]], function (err, result) {
        if (err) return console.error("Action Error:", err);
        console.log("Updated Action 3046 successfully:", result);
    });
});
