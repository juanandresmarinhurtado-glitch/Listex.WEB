const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    models.methodCall('execute_kw', [db, uid, password, 'res.partner', 'search_read', [
        [['x_studio_is_portal_supplier', '=', true]],
        ['id', 'name', 'email', 'x_studio_supplier_status', 'x_studio_portal_password']
    ]], (err, res) => {
        if (err) console.error("Error:", err);
        else console.log("Partners:", res);
    });
});
