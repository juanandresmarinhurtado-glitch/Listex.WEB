require('dotenv').config();
const xmlrpc = require('xmlrpc');

const url = new URL(process.env.ODOO_URL);
const host = url.hostname;
const port = url.port || (url.protocol === 'https:' ? 443 : 80);
const isSecure = url.protocol === 'https:';

console.log("Connecting to:", host, "port:", port, "secure:", isSecure);

const commonClientOptions = { host, port, path: '/xmlrpc/2/common' };
const commonClient = isSecure ? xmlrpc.createSecureClient(commonClientOptions) : xmlrpc.createClient(commonClientOptions);

// 1. Get version
commonClient.methodCall('version', [], (err, version) => {
    if (err) {
        console.error("Version call failed:", err);
    } else {
        console.log("Odoo Version:", version);

        // 2. Try auth
        console.log("Attempting auth with DB:", process.env.ODOO_DB, "User:", process.env.ODOO_USERNAME);
        commonClient.methodCall('authenticate', [
            process.env.ODOO_DB,
            process.env.ODOO_USERNAME,
            process.env.ODOO_API_KEY,
            {}
        ], (authErr, uid) => {
            if (authErr) {
                console.error("Auth RPC Error:", authErr);
            } else if (uid === false) {
                console.error("Auth Failed: Credentials invalid.");
            } else {
                console.log("Auth SUCCESS! UID:", uid);
            }
        });
    }
});
