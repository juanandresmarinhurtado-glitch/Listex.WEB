const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    // Check product.template fields
    models.methodCall('execute_kw', [db, uid, password, 'product.template', 'fields_get', [
        [], { attributes: ['type', 'string', 'selection'] }
    ]], (err, res) => {
        if (err) console.error("Error:", err);
        else {
            console.log("type:", res.type ? res.type.selection : "Not found");
            console.log("detailed_type:", res.detailed_type ? res.detailed_type.selection : "Not found");
        }
    });
});
