async function test() {
    try {
        const cacheBuster = `?t=${new Date().getTime()}`;
        const catalogUrl = 'https://listex.odoo.com/web/content/16027/api_catalogo_listex.json';

        // Use global fetch
        const response = await fetch(catalogUrl + cacheBuster);
        console.log("Status:", response.status);
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }
        const data = await response.json();
        console.log("Data length:", data.length);
        if (data.length > 0) {
            console.log("Sample product:", JSON.stringify(data[0], null, 2));
            const withVariants = data.find(p => p.variantes && p.variantes.length > 0);
            if (withVariants) {
                console.log("Product with variants:", JSON.stringify(withVariants, null, 2));
            }
        }
    } catch (error) {
        console.error("Test failed:", error);
    }
}
test();
