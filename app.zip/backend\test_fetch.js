async function test() {
    try {
        const cacheBuster = `?t=${new Date().getTime()}`;
        const catalogUrl = 'https://listex.odoo.com/web/content/16027/api_catalogo_listex.json';

        // Use global fetch
        const response = await fetch(catalogUrl + cacheBuster);
        console.log("Status:", response.status);
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }
        const data = await response.json();
        console.log("Data length:", data.length);
    } catch (error) {
        console.error("Test failed:", error);
    }
}
test();
