const fs = require('fs');

let fileContent = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const header = `require('dotenv').config();
const express = require('express');
const cors = require('cors');
const xmlrpc = require('xmlrpc');
const path = require('path');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Servir la página web (archivos estáticos) alojada un nivel arriba (spatial-aurora)
app.use(express.static(path.join(__dirname, '..')));

const ODOO_URL = process.env.ODOO_URL;
`;

// Replace lines up to ODOO_DB
const indexOdooDb = fileContent.indexOf('const ODOO_DB =');
fileContent = header + fileContent.substring(indexOdooDb);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', fileContent, 'utf8');
console.log("Fixed server.js header");
