const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

// We will replace the entire POST /api/supplier/products block.
const postProductRegex = /app\.post\('\/api\/supplier\/products', authenticateSupplier, async \(req, res\) => \{[\s\S]*?(?=\napp\.get\('\/api\/supplier\/products\/:tmplId\/variants)/;

const newPostProductCode = `
const path = require('path');
const queueFile = path.join(__dirname, 'queue.json');
const variantsFile = path.join(__dirname, 'queue_variants.json');

function readJson(file) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch(e) { return {}; } }
function writeJson(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }

app.post('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        const productData = req.body;
        const tempId = 'temp_' + Date.now() + '_' + Math.floor(Math.random()*1000);
        
        // Save to queue
        const queue = readJson(queueFile);
        queue[tempId] = { partner_id: req.user.id, data: productData, status: 'pending', timestamp: Date.now() };
        writeJson(queueFile, queue);
        
        // Generate Cartesian Product of variants locally
        const fakeVariants = [];
        const requiredAttrNames = ['Presentación'];
        const attrsToCross = [{ name: 'Presentación', values: [] }];
        
        if (productData.priceDocena) attrsToCross[0].values.push('docena cerrada');
        if (productData.priceBulto) attrsToCross[0].values.push('bulto');
        attrsToCross[0].values.unshift('unidad variada'); // Default
        
        if (productData.customAttributes) {
            productData.customAttributes.forEach(attr => {
                if (attr.name && attr.name.trim() && attr.values && attr.values.length > 0) {
                    attrsToCross.push({ name: attr.name.trim(), values: attr.values.map(v => v.trim()).filter(Boolean) });
                }
            });
        }
        
        function cartesian(arrays) {
            return arrays.reduce((a, b) => a.flatMap(d => b.map(e => [d, e].flat())));
        }
        
        const valueArrays = attrsToCross.map(a => a.values);
        let combos = [[]];
        if (valueArrays.length > 0) {
             combos = valueArrays.reduce((a, b) => a.flatMap(x => b.map(y => [...x, y])), [[]]);
        }
        
        combos.forEach((combo, idx) => {
            const fakeVarId = 'temp_var_' + tempId + '_' + idx;
            fakeVariants.push({
                id: fakeVarId,
                attribute_names: combo.join(' / '),
                qty_available: 0,
                image_variant_1920: productData.imageBase64 ? productData.imageBase64.split(',')[1] || productData.imageBase64 : null
            });
        });
        
        const variantsQueue = readJson(variantsFile);
        variantsQueue[tempId] = fakeVariants;
        writeJson(variantsFile, variantsQueue);
        
        res.json({ success: true, message: "Producto en cola para sincronización", productId: tempId });
    } catch (error) {
        console.error("Queue Product Error:", error);
        res.status(500).json({ error: error.message });
    }
});
`;

serverJs = serverJs.replace(postProductRegex, newPostProductCode);

// Next: Rewrite GET /api/supplier/products/:id to intercept temp IDs
const getProductRegex = /app\.get\('\/api\/supplier\/products\/:id', authenticateSupplier, async \(req, res\) => \{[\s\S]*?(?=app\.put\('\/api\/supplier\/products\/:id)/;

const newGetProductCode = `app.get('/api/supplier/products/:id', authenticateSupplier, async (req, res) => {
    try {
        const reqId = req.params.id;
        
        // INTERCEPT TEMP IDs
        if (reqId.startsWith('temp_')) {
            const queue = readJson(queueFile);
            const qData = queue[reqId];
            if (!qData || qData.partner_id !== req.user.id) return res.status(404).json({ error: "No encontrado en cola" });
            
            const variantsQueue = readJson(variantsFile);
            const fakeVariants = variantsQueue[reqId] || [];
            
            const p = qData.data;
            return res.json({ success: true, product: {
                id: reqId,
                name: p.name,
                standard_price: parseFloat(p.cost) || 0,
                list_price: parseFloat(p.priceUnidad) || 0,
                priceUnidad: parseFloat(p.priceUnidad) || 0,
                priceDocena: parseFloat(p.priceDocena) || "",
                priceBulto: parseFloat(p.priceBulto) || "",
                categoryId: p.categoryId,
                isStorable: p.isStorable,
                imageBase64: p.imageBase64 ? p.imageBase64.split(',')[1] : null,
                variants: fakeVariants,
                isPending: true
            }});
        }
        
        // REAL ODOO LOGIC
        await authenticate();
        const tmplId = parseInt(reqId);
        if (isNaN(tmplId)) return res.status(400).json({ error: "Invalid ID" });
        
        const supplierInfos = await executeKw('product.supplierinfo', 'search_count', [[['partner_id', '=', req.user.id], ['product_tmpl_id', '=', tmplId]]]);
        if (supplierInfos === 0) return res.status(403).json({ error: "Access denied" });
        
        const products = await executeKw('product.template', 'search_read', [
            [['id', '=', tmplId]], 
            ['name', 'standard_price', 'list_price', 'public_categ_ids', 'is_storable', 'image_1920']
        ]);
        if (products.length === 0) return res.status(404).json({ error: "Not found" });
        
        const p = products[0];
        
        const pricelists = await executeKw('product.pricelist.item', 'search_read', [
            [['product_tmpl_id', '=', tmplId], ['pricelist_id', 'in', [2, 3]]]
        ], { fields: ['pricelist_id', 'fixed_price'] });
        
        let priceDocena = "";
        let priceBulto = "";
        pricelists.forEach(pl => {
            if (pl.pricelist_id[0] === 3) priceDocena = pl.fixed_price;
            if (pl.pricelist_id[0] === 2) priceBulto = pl.fixed_price; 
        });
        
        const variants = await executeKw('product.product', 'search_read', [
            [['product_tmpl_id', '=', tmplId]],
            ['id', 'product_template_attribute_value_ids', 'qty_available', 'image_variant_128']
        ]);
        
        const allPtavIds = new Set();
        variants.forEach(v => {
            if (v.product_template_attribute_value_ids) {
                v.product_template_attribute_value_ids.forEach(id => allPtavIds.add(id));
            }
        });
        const uniquePtavIds = [...allPtavIds];
        let ptavMap = {};
        if (uniquePtavIds.length > 0) {
            const ptavs = await executeKw('product.template.attribute.value', 'search_read', [[['id', 'in', uniquePtavIds]], ['id', 'name']]);
            ptavs.forEach(pt => ptavMap[pt.id] = pt.name);
        }
        
        for (let v of variants) {
            if (v.product_template_attribute_value_ids && v.product_template_attribute_value_ids.length > 0) {
                v.attribute_names = v.product_template_attribute_value_ids.map(id => ptavMap[id] || '').filter(Boolean).join(' / ');
            } else {
                v.attribute_names = "Variante Base";
            }
            v.image_variant_1920 = v.image_variant_128;
            delete v.image_variant_128;
        }
        
        res.json({ success: true, product: {
            id: p.id,
            name: p.name,
            standard_price: p.standard_price,
            list_price: p.list_price,
            priceUnidad: p.list_price,
            priceDocena: priceDocena,
            priceBulto: priceBulto,
            categoryId: p.public_categ_ids.length > 0 ? p.public_categ_ids[0] : "",
            isStorable: p.is_storable,
            imageBase64: p.image_1920,
            variants: variants,
            isPending: false
        }});
    } catch (error) {
        console.error("Get Product Error:", error);
        res.status(500).json({ error: error.message });
    }
});
`;

serverJs = serverJs.replace(getProductRegex, newGetProductCode);

// Next: Rewrite POST /variants/:variantId/stock to intercept temp variants
const stockRegex = /app\.post\('\/api\/supplier\/variants\/:variantId\/stock', authenticateSupplier, async \(req, res\) => \{[\s\S]*?(?=app\.post\('\/api\/supplier\/products\/:id\/publish)/;

const newStockCode = `app.post('/api/supplier/variants/:variantId/stock', authenticateSupplier, async (req, res) => {
    try {
        const reqVarId = req.params.variantId;
        const qty = parseFloat(req.body.qty);
        
        if (reqVarId.startsWith('temp_var_')) {
            const tempIdMatch = reqVarId.match(/temp_var_(temp_\\d+_\\d+)_(.*)/);
            if (!tempIdMatch) return res.status(400).json({ error: "Invalid temp var ID" });
            const tempId = tempIdMatch[1];
            
            const variantsQueue = readJson(variantsFile);
            if (variantsQueue[tempId]) {
                const fakeVar = variantsQueue[tempId].find(v => v.id === reqVarId);
                if (fakeVar) {
                    fakeVar.qty_available = qty;
                    fakeVar.stock_updated = true; // flag for background worker
                    writeJson(variantsFile, variantsQueue);
                    return res.json({ success: true, message: "Stock en cola" });
                }
            }
            return res.status(404).json({ error: "Temp variant not found" });
        }
        
        await authenticate();
        const variantId = parseInt(reqVarId);
        if (isNaN(variantId)) return res.status(400).json({ error: "Invalid ID" });
        
        let stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'WH/']]], { fields: ['id'], limit: 1 });
        if (stockLocations.length === 0) stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'PT/']]], { fields: ['id'], limit: 1 });
        if (stockLocations.length === 0) stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal']]], { fields: ['id'], limit: 1 });
        
        if (stockLocations.length > 0) {
            const locId = stockLocations[0].id;
            const quantId = await executeKw('stock.quant', 'create', [{ product_id: variantId, location_id: locId, inventory_quantity: qty }]);
            try {
                await executeKw('stock.quant', 'action_apply_inventory', [[quantId]]);
            } catch(applyErr) {}
            res.json({ success: true, message: "Stock actualizado" });
        } else {
            res.status(400).json({ error: "No internal stock location found in Odoo" });
        }
    } catch (error) {
        console.error("Update Stock Error:", error);
        res.status(500).json({ error: error.message });
    }
});

// GET Variants Route update
app.get('/api/supplier/products/:tmplId/variants', authenticateSupplier, async (req, res) => {
    try {
        const reqTmplId = req.params.tmplId;
        if (reqTmplId.startsWith('temp_')) {
            const variantsQueue = readJson(variantsFile);
            const fakeVariants = variantsQueue[reqTmplId] || [];
            return res.json({ success: true, variants: fakeVariants });
        }
        
        await authenticate();
        const tmplId = parseInt(reqTmplId);
        if (isNaN(tmplId)) return res.status(400).json({ error: "Invalid ID" });
        
        const supplierInfos = await executeKw('product.supplierinfo', 'search_count', [[['partner_id', '=', req.user.id], ['product_tmpl_id', '=', tmplId]]]);
        if (supplierInfos === 0) return res.status(403).json({ error: "Access denied" });
        
        const variants = await executeKw('product.product', 'search_read', [
            [['product_tmpl_id', '=', tmplId]],
            ['id', 'product_template_attribute_value_ids', 'image_variant_128', 'qty_available']
        ]);
        
        const allPtavIds = new Set();
        variants.forEach(v => {
            if (v.product_template_attribute_value_ids) {
                v.product_template_attribute_value_ids.forEach(id => allPtavIds.add(id));
            }
        });
        const uniquePtavIds = [...allPtavIds];
        let ptavMap = {};
        if (uniquePtavIds.length > 0) {
            const ptavs = await executeKw('product.template.attribute.value', 'search_read', [[['id', 'in', uniquePtavIds]], ['id', 'name']]);
            ptavs.forEach(pt => ptavMap[pt.id] = pt.name);
        }
        for (let v of variants) {
            if (v.product_template_attribute_value_ids && v.product_template_attribute_value_ids.length > 0) {
                v.attribute_names = v.product_template_attribute_value_ids.map(id => ptavMap[id] || '').filter(Boolean).join(' / ');
            } else {
                v.attribute_names = "Variante Base";
            }
            v.image_variant_1920 = v.image_variant_128;
            delete v.image_variant_128;
        }
        res.json({ success: true, variants: variants });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update Image Route
app.post('/api/supplier/variants/:variantId/image', authenticateSupplier, async (req, res) => {
    try {
        const reqVarId = req.params.variantId;
        const { imageBase64 } = req.body;
        const rawB64 = imageBase64.split(',')[1] || imageBase64;
        
        if (reqVarId.startsWith('temp_var_')) {
            const tempIdMatch = reqVarId.match(/temp_var_(temp_\\d+_\\d+)_(.*)/);
            if (!tempIdMatch) return res.status(400).json({ error: "Invalid temp var ID" });
            const tempId = tempIdMatch[1];
            
            const variantsQueue = readJson(variantsFile);
            if (variantsQueue[tempId]) {
                const fakeVar = variantsQueue[tempId].find(v => v.id === reqVarId);
                if (fakeVar) {
                    fakeVar.image_variant_1920 = rawB64;
                    fakeVar.image_updated = true; // flag
                    writeJson(variantsFile, variantsQueue);
                    return res.json({ success: true, message: "Imagen en cola" });
                }
            }
            return res.status(404).json({ error: "Temp variant not found" });
        }
        
        await authenticate();
        const variantId = parseInt(reqVarId);
        if (isNaN(variantId)) return res.status(400).json({ error: "Invalid ID" });
        await executeKw('product.product', 'write', [[variantId], { image_1920: rawB64 }]);
        res.json({ success: true, message: "Imagen subida" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

`;

// First remove existing GET variants and POST image routes so we don't duplicate them
const cleanupRegex = /\/\/ GET Variants for a product[\s\S]*?(?=app\.post\('\/api\/supplier\/products\/:id\/publish)/;
serverJs = serverJs.replace(cleanupRegex, '');

serverJs = serverJs.replace(stockRegex, newStockCode);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Patched server.js with Optimistic UI routes.");
