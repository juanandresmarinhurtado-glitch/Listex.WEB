const fs = require('fs');

let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// The file currently has:
// }
//
// } else {
//     throw new Error(data.error || "Error desconocido");
// }

// Let's fix this exact chunk of text:
html = html.replace(/}\s*}\s*else\s*{/, '} else {');

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("Syntax fixed.");
