const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        // Find all dynamic attributes
        const dynamicAttrs = await executeKw('product.attribute', 'search_read', [
            [['create_variant', '=', 'dynamic']],
            ['id', 'name']
        ]);
        
        console.log("Found dynamic attrs:", dynamicAttrs.length);
        
        if (dynamicAttrs.length > 0) {
            const idsToUpdate = dynamicAttrs.map(a => a.id);
            // Update them to always
            await executeKw('product.attribute', 'write', [
                idsToUpdate,
                { create_variant: 'always' }
            ]);
            console.log("Updated", idsToUpdate.length, "attributes to 'always' variant creation.");
        }
        
    } catch (e) {
        console.error("Error fixing attributes:", e);
    }
});
