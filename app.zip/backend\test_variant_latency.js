const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            const start = Date.now();
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                console.log(`[${model}.${method}] took ${(Date.now() - start)/1000}s`);
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        console.log("Preparing 80 variant test...");
        
        // Find Talla and Color and Presentacion attributes
        const attrs = await executeKw('product.attribute', 'search_read', [[], ['id', 'name']]);
        const tallaAttr = attrs.find(a => a.name === 'Talla');
        const colorAttr = attrs.find(a => a.name === 'Color');
        
        const tallaVals = await executeKw('product.attribute.value', 'search_read', [[['attribute_id', '=', tallaAttr.id]], ['id', 'name']], {limit: 4});
        const colorVals = await executeKw('product.attribute.value', 'search_read', [[['attribute_id', '=', colorAttr.id]], ['id', 'name']], {limit: 5});
        
        console.log("Talla vals:", tallaVals.map(v => v.id));
        console.log("Color vals:", colorVals.map(v => v.id));
        
        const productData = {
            name: "Test 80 Variant Product Latency",
            list_price: 10,
            attribute_line_ids: [
                [0, 0, { attribute_id: tallaAttr.id, value_ids: [[6, 0, tallaVals.map(v => v.id)]] }],
                [0, 0, { attribute_id: colorAttr.id, value_ids: [[6, 0, colorVals.map(v => v.id)]] }]
            ]
        };
        
        console.log("Creating template with 20 variants (4x5)...");
        const tmplId = await executeKw('product.template', 'create', [productData]);
        console.log("Template ID:", tmplId);
        
    } catch (e) {
        console.error("Error:", e);
    }
});
