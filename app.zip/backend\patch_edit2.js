const fs = require('fs');

// --- 1. PATCH SERVER.JS ---
let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const editRoute = `
// Edit Product
app.post('/api/supplier/products/:id/edit', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const tmplId = parseInt(req.params.id);
        const { name, cost, priceUnidad } = req.body;
        
        const supplierInfos = await executeKw('product.supplierinfo', 'search_count', [[['partner_id', '=', req.user.id], ['product_tmpl_id', '=', tmplId]]]);
        if (supplierInfos === 0) return res.status(403).json({ error: "Access denied" });
        
        await executeKw('product.template', 'write', [[tmplId], {
            name: name,
            standard_price: parseFloat(cost) || 0,
            list_price: parseFloat(priceUnidad) || 0
        }]);
        
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
`;

if (!serverJs.includes('/edit')) {
    serverJs = serverJs.replace("// Categories endpoint", editRoute + "\n// Categories endpoint");
    fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
}


// --- 2. PATCH HTML ---
let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// Add edit button to table
html = html.replace(
    '<button onclick="openVariantsModal(${p.id})"', 
    '<button onclick="openEditModal(${p.id}, \'${p.name.replace(/\'/g, \\\'\\\\\'\\\')}\', ${p.standard_price}, ${p.list_price})" class="btn" style="background:#e0f2fe; color:#0284c7; padding:6px 12px; font-size:0.8rem;" title="Editar"><ion-icon name="create-outline"></ion-icon></button>\n                                    <button onclick="openVariantsModal(${p.id})"'
);

// Add Edit Modal
const editModal = `
    <!-- Edit Modal -->
    <div id="edit-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:9999; align-items:center; justify-content:center;">
        <div style="background:var(--card-bg); width:90%; max-width:400px; border-radius:12px; padding:30px; position:relative;">
            <button onclick="document.getElementById('edit-modal').style.display='none'" style="position:absolute; top:15px; right:15px; background:none; border:none; font-size:1.5rem; cursor:pointer; color:var(--text-muted);"><ion-icon name="close-circle-outline"></ion-icon></button>
            <h2 style="margin-bottom:20px; color:var(--text-main); font-size:1.2rem;"><ion-icon name="create-outline"></ion-icon> Editar Producto</h2>
            
            <form id="edit-product-form">
                <input type="hidden" id="edit-prod-id">
                <div class="form-group">
                    <label>Nombre del Producto</label>
                    <input type="text" id="edit-prod-name" required>
                </div>
                <div class="form-group">
                    <label>Costo USD</label>
                    <input type="number" step="0.01" id="edit-prod-cost" required>
                </div>
                <div class="form-group">
                    <label>Precio Detal USD</label>
                    <input type="number" step="0.01" id="edit-prod-price" required>
                </div>
                <button type="submit" class="btn btn-primary w-100" id="edit-save-btn">Guardar Cambios</button>
            </form>
        </div>
    </div>
`;

if (!html.includes('id="edit-modal"')) {
    html = html.replace('<!-- Variants Modal -->', editModal + '\n    <!-- Variants Modal -->');
}

// Add Edit JS
const editJs = `
        function openEditModal(id, name, cost, price) {
            document.getElementById('edit-prod-id').value = id;
            document.getElementById('edit-prod-name').value = name;
            document.getElementById('edit-prod-cost').value = cost;
            document.getElementById('edit-prod-price').value = price;
            document.getElementById('edit-modal').style.display = 'flex';
        }

        document.getElementById('edit-product-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('edit-save-btn');
            btn.disabled = true;
            btn.textContent = 'Guardando...';
            
            const id = document.getElementById('edit-prod-id').value;
            const body = {
                name: document.getElementById('edit-prod-name').value,
                cost: document.getElementById('edit-prod-cost').value,
                priceUnidad: document.getElementById('edit-prod-price').value
            };
            
            try {
                const res = await fetch(API_BASE + '/products/' + id + '/edit', {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify(body)
                });
                if ((await res.json()).success) {
                    showToast('Producto actualizado');
                    document.getElementById('edit-modal').style.display = 'none';
                    loadProducts();
                } else {
                    showToast('Error al actualizar');
                }
            } catch (err) {
                showToast('Error de red');
            }
            btn.disabled = false;
            btn.textContent = 'Guardar Cambios';
        });
`;

if (!html.includes('function openEditModal')) {
    html = html.replace('// INIT', editJs + '\n        // INIT');
}

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("Edit logic added successfully.");
