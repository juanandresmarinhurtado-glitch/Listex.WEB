const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');
serverJs = serverJs.replace(/create_variant:\s*'dynamic'/g, "create_variant: 'always'");
fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');

let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// The string we are looking for is exactly:
// document.getElementById('image-preview').innerHTML = '<div class="placeholder"><ion-icon name="image-outline" style="font-size:3rem; margin-bottom:10px;"></ion-icon><br>Haz clic aquí para seleccionar una foto<br><span style="font-size:0.8rem; font-weight:normal;">Formatos admitidos: JPG, PNG, WEBP</span></div><input type="file" id="prod-image" accept="image/png, image/jpeg, image/webp" required>';

html = html.replace(/document\.getElementById\('image-preview'\)\.innerHTML = '<div class="placeholder">.*?<\/div><input type="file" id="prod-image".*?>';/, 
`
                    const preview = document.getElementById('image-preview');
                    const img = preview.querySelector('img');
                    if (img) img.remove();
                    const placeholder = preview.querySelector('.placeholder');
                    if (placeholder) placeholder.style.display = 'block';
                    const input = document.getElementById('prod-image');
                    if (input) {
                        input.value = '';
                        input.setAttribute('required', 'true');
                    }
`);

// For openEditModal:
// document.getElementById('image-preview').innerHTML = `<img src="${base64Image}" /> <input type="file" id="prod-image" accept="image/png, image/jpeg, image/webp" style="display:none;">`;
html = html.replace(/document\.getElementById\('image-preview'\)\.innerHTML = `<img src="\\\$\\{base64Image\\}" \/> <input type="file" id="prod-image"[^>]*>`;/, 
`
                        const preview = document.getElementById('image-preview');
                        const placeholder = preview.querySelector('.placeholder');
                        if (placeholder) placeholder.style.display = 'none';
                        let img = preview.querySelector('img');
                        if (!img) {
                            img = document.createElement('img');
                            preview.insertBefore(img, preview.firstChild);
                        }
                        img.src = base64Image;
                        document.getElementById('prod-image').removeAttribute('required');
`);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("Done");
