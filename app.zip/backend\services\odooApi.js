const xmlrpc = require('xmlrpc');
require('dotenv').config();

const ODOO_URL = process.env.ODOO_URL || 'https://listex.odoo.com';
const DB = process.env.ODOO_DB || 'listex';
const USERNAME = process.env.ODOO_USERNAME || 'juanandresmarinhurtado@gmail.com';
const PASSWORD = process.env.ODOO_API_KEY || 'Seguridad400%';

let uid = null;

const commonClient = xmlrpc.createSecureClient({ host: new URL(ODOO_URL).hostname, port: 443, path: '/xmlrpc/2/common', timeout: 15000 });
const modelsClient = xmlrpc.createSecureClient({ host: new URL(ODOO_URL).hostname, port: 443, path: '/xmlrpc/2/object', timeout: 20000 });

async function authenticate() {
    if (uid) return uid;
    return new Promise((resolve, reject) => {
        commonClient.methodCall('authenticate', [DB, USERNAME, PASSWORD, {}], (err, result) => {
            if (err || !result) {
                console.error("[ODOO] Auth Error:", err);
                return reject(err || new Error("Auth failed"));
            }
            uid = result;
            console.log(`[ODOO] Authenticated successfully with UID: ${uid}`);
            resolve(uid);
        });
    });
}

async function executeKw(model, method, args, kwargs = {}) {
    await authenticate();
    return new Promise((resolve, reject) => {
        modelsClient.methodCall('execute_kw', [DB, uid, PASSWORD, model, method, args, kwargs], (err, result) => {
            if (err) return reject(err);
            resolve(result);
        });
    });
}

module.exports = {
    authenticate,
    executeKw
};
