const fs = require('fs');
const path = require('path');

const ZAPATOS_DIR = 'C:\\Users\\juan\\Documents\\catalogo web\\zapatos';
const SUBFOLDERS = ['', 'zapato brillante', 'zapatos niños'];

const MODEL_PREFIXES = [
    'Adidas Samba','Adidas',
    'Asics',
    'Bota Casual','Bota Caterpillar','Bota Timberland',
    'Caterpillar',
    'Deportivo Dior','Deportivo QC','Deportivo',
    'New Balance',
    'Nike Air Force','Nike Airmax','Nike Shox','Nike Zoomx','Nike Zoom','Nike',
    'Puma','Reebok','Sandalias Nike Mind','Timberland','Tommy Hilfiger','Vans',
    'Zapato Brillante','Zapato Negro Ancho Estilo Skate',
    'Zapatos Anchos','Zapatos DC','Zapatos Infantiles',
    'Zapatos Minnie Mouse','Zapatos Paw Patrol','Zapatos Spiderman','Zapatos Skate',
    'Zapatos', 'Zapato',
];

function ceilPrice(v) { return Math.ceil(v * 100) / 100; }
function calcPrecios(cost) {
    const detal     = ceilPrice(cost * 1.55);
    const comboPpu  = ceilPrice(cost * 1.45);
    const docenaPpu = ceilPrice(cost * 1.35);
    const bultoPpu  = ceilPrice(cost * 1.20);
    return {
        detal,
        combo:  Math.round(comboPpu  * 3  * 100) / 100,
        docena: Math.round(docenaPpu * 12 * 100) / 100,
        bulto:  Math.round(bultoPpu  * 13 * 100) / 100,
    };
}

function parseFilename(filename) {
    // "Adidas Blanco Rayas Negras 1 - Costo $12.57.webp"
    const base = filename.replace(/\.webp$/i, '');
    const match = base.match(/^(.+?)\s*-\s*Costo\s*\$(\d+\.?\d*)/i);
    if (!match) return null;
    // Quitar " 1", " 2", " 3" al final del nombre base
    const cleanName = match[1].trim().replace(/\s+\d+$/, '').trim();
    return { fullName: cleanName, cost: parseFloat(match[2]) };
}

function extractModelColor(fullName) {
    for (const prefix of MODEL_PREFIXES) {
        if (fullName.toLowerCase().startsWith(prefix.toLowerCase())) {
            const color = fullName.slice(prefix.length).trim();
            return { model: prefix, color: color || 'Único' };
        }
    }
    return { model: fullName, color: 'Único' };
}

// Leer y agrupar
const groups = {};
let totalImages = 0;
for (const sub of SUBFOLDERS) {
    const dir = sub ? path.join(ZAPATOS_DIR, sub) : ZAPATOS_DIR;
    if (!fs.existsSync(dir)) continue;
    const files = fs.readdirSync(dir).filter(f => f.endsWith('.webp') && fs.statSync(path.join(dir,f)).isFile());
    for (const file of files) {
        totalImages++;
        const parsed = parseFilename(file);
        if (!parsed) { console.log('NO PARSEADO:', file); continue; }
        const { model, color } = extractModelColor(parsed.fullName);
        if (!groups[model]) groups[model] = { model, cost: parsed.cost, colors: {}, subfolder: sub||'main' };
        if (!groups[model].colors[color]) {
            groups[model].colors[color] = path.join(dir, file);
        }
    }
}

const sorted = Object.keys(groups).sort();
console.log('=== AGRUPACIÓN DE ZAPATOS ===');
console.log('Total imágenes:', totalImages);
console.log('Total modelos:', sorted.length);
console.log('');

let totalVariantes = 0;
sorted.forEach(g => {
    const gr = groups[g];
    const colors = Object.keys(gr.colors);
    const p = calcPrecios(gr.cost);
    totalVariantes += colors.length;
    console.log(`[${g}] (${colors.length} colores | costo $${gr.cost})`);
    console.log(`  Detal:$${p.detal} | Combo3pares:$${p.combo} | Docena12:$${p.docena} | Bulto13:$${p.bulto}`);
    console.log(`  Colores: ${colors.join(', ')}`);
    console.log('');
});

console.log('Total variantes (colores):', totalVariantes);
