

async function test() {
    console.log("Logging in...");
    const loginRes = await fetch('http://localhost:3000/api/supplier/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'juanandresmarinhurtado@gmail.com', password: 'Seguridad400%' })
    });
    const loginData = await loginRes.json();
    console.log("Login:", loginData);
    if (!loginData.token) return;
    
    const token = loginData.token;
    
    console.log("Creating product...");
    const t0 = Date.now();
    const createRes = await fetch('http://localhost:3000/api/supplier/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify({
            name: "Test Optimistic",
            cost: 10,
            priceUnidad: 20,
            isStorable: true,
            customAttributes: [{ name: "Talla", values: ["S", "M"] }]
        })
    });
    const createData = await createRes.json();
    console.log("Create Product:", createData, "(" + (Date.now() - t0) + "ms)");
    
    if (createData.productId) {
        console.log("Fetching temp product:", createData.productId);
        const t1 = Date.now();
        const getRes = await fetch('http://localhost:3000/api/supplier/products/' + createData.productId, {
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const getData = await getRes.json();
        console.log("Get Product:", JSON.stringify(getData, null, 2), "(" + (Date.now() - t1) + "ms)");
    }
}
test();
