const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

common.methodCall('authenticate', [db, username, password, {}], function (error, uid) {
    if (error) {
        console.error("Auth Error:", error);
        return;
    }
    
    // 1. Get Model ID for res.partner
    models.methodCall('execute_kw', [db, uid, password, 'ir.model', 'search', [[['model', '=', 'res.partner']]]], function (err, modelIds) {
        if (err || !modelIds.length) {
            console.error("Model Error:", err);
            return;
        }
        const partnerModelId = modelIds[0];
        console.log("res.partner model ID:", partnerModelId);

        const fieldsToCreate = [
            {
                name: 'x_studio_is_portal_supplier',
                field_description: 'Is Portal Supplier',
                model_id: partnerModelId,
                ttype: 'boolean',
                state: 'manual'
            },
            {
                name: 'x_studio_supplier_status',
                field_description: 'Supplier Portal Status',
                model_id: partnerModelId,
                ttype: 'selection',
                selection: "[('pending', 'Pendiente'), ('approved', 'Aprobado'), ('rejected', 'Rechazado')]",
                state: 'manual'
            },
            {
                name: 'x_studio_portal_password',
                field_description: 'Portal Password',
                model_id: partnerModelId,
                ttype: 'char',
                state: 'manual'
            },
            {
                name: 'x_studio_supplier_rif',
                field_description: 'Supplier RIF/Cedula',
                model_id: partnerModelId,
                ttype: 'char',
                state: 'manual'
            }
        ];

        // Check which fields exist
        models.methodCall('execute_kw', [db, uid, password, 'ir.model.fields', 'search_read', [[['model_id', '=', partnerModelId], ['name', 'in', fieldsToCreate.map(f => f.name)]], ['name']]], function (err, existingFields) {
            if (err) {
                console.error("Field Search Error:", err);
                return;
            }
            const existingFieldNames = existingFields.map(f => f.name);
            const fieldsToAdd = fieldsToCreate.filter(f => !existingFieldNames.includes(f.name));

            if (fieldsToAdd.length === 0) {
                console.log("All fields already exist.");
            } else {
                console.log("Adding fields:", fieldsToAdd.map(f => f.name));
                fieldsToAdd.forEach(field => {
                    models.methodCall('execute_kw', [db, uid, password, 'ir.model.fields', 'create', [field]], function (err, fieldId) {
                        if (err) console.error("Error creating field", field.name, err);
                        else console.log("Created field", field.name, "with ID", fieldId);
                    });
                });
            }
        });
    });
});
