const fs = require('fs');

let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// Add change listener to prod-inventario
const newListener = `
        document.getElementById('prod-inventario').addEventListener('change', function() {
            if (editModeId) {
                // If they are in edit mode, checking this box should immediately re-render variants
                openEditModal(editModeId);
                showToast(this.checked ? "Inventario Activado. Guarde los cambios." : "Inventario Desactivado.");
            }
        });
`;

if (!html.includes('prod-inventario\').addEventListener(\'change\'')) {
    html = html.replace('// INIT', newListener + '\n        // INIT');
}

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("Toggle listener added.");
