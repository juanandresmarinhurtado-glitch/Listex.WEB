const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const regex = /app\.post\('\/api\/supplier\/products', authenticateSupplier, async \(req, res\) => \{[\s\S]*?res\.json\(\{ success: true, message: "Producto creado", productId: tmplId \}\);\s*\} catch \(error\) \{[\s\S]*?\}\s*\}\);/;

const newRoute = `app.post('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const { name, cost, priceUnidad, priceDocena, priceBulto, categoryId, customAttributes, imageBase64, isStorable } = req.body;
        
        // 1. Batch collect required attributes
        const requiredAttrNames = ['Presentación'];
        if (customAttributes) {
            for (let attr of customAttributes) {
                if (attr.name && attr.name.trim()) requiredAttrNames.push(attr.name.trim());
            }
        }
        
        // Unique names
        const uniqueAttrNames = [...new Set(requiredAttrNames)];
        
        const existingAttrs = await executeKw('product.attribute', 'search_read', [
            [['name', 'in', uniqueAttrNames]],
            ['id', 'name']
        ]);
        
        const existingAttrMap = {};
        existingAttrs.forEach(a => existingAttrMap[a.name] = a.id);
        
        const attrsToCreate = uniqueAttrNames.filter(name => !existingAttrMap[name]);
        if (attrsToCreate.length > 0) {
            const createPayload = attrsToCreate.map(name => ({ name: name, create_variant: 'always' }));
            const newIds = await executeKw('product.attribute', 'create', [createPayload]);
            if (!Array.isArray(newIds)) {
                // Sometimes single create returns an int, but passing array of dicts should return array of ints
                attrsToCreate.forEach((name, idx) => existingAttrMap[name] = newIds);
            } else {
                attrsToCreate.forEach((name, idx) => existingAttrMap[name] = newIds[idx]);
            }
        }
        
        // 2. Batch collect required attribute values
        const requiredValues = [];
        requiredValues.push({ attrId: existingAttrMap['Presentación'], valName: 'unidad variada' });
        if (priceDocena) requiredValues.push({ attrId: existingAttrMap['Presentación'], valName: 'docena cerrada' });
        if (priceBulto) requiredValues.push({ attrId: existingAttrMap['Presentación'], valName: 'bulto' });
        
        if (customAttributes) {
            for (let attr of customAttributes) {
                if (!attr.name || !attr.name.trim() || !attr.values) continue;
                const attrId = existingAttrMap[attr.name.trim()];
                for (let v of attr.values) {
                    if (v.trim()) requiredValues.push({ attrId: attrId, valName: v.trim() });
                }
            }
        }
        
        const attrIds = [...new Set(requiredValues.map(r => r.attrId))];
        const valNames = [...new Set(requiredValues.map(r => r.valName))];
        
        const existingVals = await executeKw('product.attribute.value', 'search_read', [
            [['attribute_id', 'in', attrIds], ['name', 'in', valNames]],
            ['id', 'attribute_id', 'name']
        ]);
        
        const existingValMap = {};
        existingVals.forEach(v => {
            const aid = Array.isArray(v.attribute_id) ? v.attribute_id[0] : v.attribute_id;
            existingValMap[\`\${aid}_\${v.name}\`] = v.id;
        });
        
        const valsToCreate = requiredValues.filter(r => !existingValMap[\`\${r.attrId}_\${r.valName}\`]);
        
        // Dedup valsToCreate to avoid creating the same value twice in the same batch
        const uniqueValsToCreate = [];
        const seenVals = new Set();
        for (let v of valsToCreate) {
            const key = \`\${v.attrId}_\${v.valName}\`;
            if (!seenVals.has(key)) {
                seenVals.add(key);
                uniqueValsToCreate.push(v);
            }
        }
        
        if (uniqueValsToCreate.length > 0) {
            const createPayload = uniqueValsToCreate.map(r => ({ attribute_id: r.attrId, name: r.valName }));
            const newValIds = await executeKw('product.attribute.value', 'create', [createPayload]);
            
            if (Array.isArray(newValIds)) {
                uniqueValsToCreate.forEach((r, idx) => {
                    existingValMap[\`\${r.attrId}_\${r.valName}\`] = newValIds[idx];
                });
            } else {
                // If only one was created and Odoo returned just the integer ID
                uniqueValsToCreate.forEach((r, idx) => {
                    existingValMap[\`\${r.attrId}_\${r.valName}\`] = newValIds;
                });
            }
        }
        
        // 3. Create Product Template
        const productData = {
            name: name,
            list_price: parseFloat(priceUnidad) || 0,
            standard_price: parseFloat(cost) || 0,
            sale_ok: true,
            purchase_ok: true,
            is_published: true,
            is_storable: isStorable ? true : false,
            taxes_id: false,
            supplier_taxes_id: false,
            seller_ids: [[0, 0, { partner_id: req.user.id, delay: 1 }]]
        };
        
        if (imageBase64) productData.image_1920 = imageBase64.split(',')[1] || imageBase64;
        if (categoryId) productData.public_categ_ids = [[6, 0, [parseInt(categoryId)]]];
        
        const tmplId = await executeKw('product.template', 'create', [productData]);
        
        // 4. Batch Create Pricelists
        const pricelistPayload = [];
        if (priceDocena) pricelistPayload.push({ pricelist_id: 3, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceDocena) });
        if (priceBulto) pricelistPayload.push({ pricelist_id: 2, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceBulto) });
        if (pricelistPayload.length > 0) {
            await executeKw('product.pricelist.item', 'create', [pricelistPayload]);
        }
        
        // 5. Batch Create Attribute Lines
        const ptalPayload = [];
        
        let presValIds = [existingValMap[\`\${existingAttrMap['Presentación']}_unidad variada\`]];
        if (priceDocena) presValIds.push(existingValMap[\`\${existingAttrMap['Presentación']}_docena cerrada\`]);
        if (priceBulto) presValIds.push(existingValMap[\`\${existingAttrMap['Presentación']}_bulto\`]);
        
        ptalPayload.push({ product_tmpl_id: tmplId, attribute_id: existingAttrMap['Presentación'], value_ids: [[6, 0, presValIds]] });
        
        if (customAttributes) {
            for (let attr of customAttributes) {
                if (!attr.name || !attr.name.trim() || !attr.values || attr.values.length === 0) continue;
                const attrId = existingAttrMap[attr.name.trim()];
                let valIds = [];
                for (let v of attr.values) {
                    if (v.trim()) {
                        const vId = existingValMap[\`\${attrId}_\${v.trim()}\`];
                        if (vId) valIds.push(vId);
                    }
                }
                if (valIds.length > 0) {
                    ptalPayload.push({ product_tmpl_id: tmplId, attribute_id: attrId, value_ids: [[6, 0, valIds]] });
                }
            }
        }
        
        if (ptalPayload.length > 0) {
            await executeKw('product.template.attribute.line', 'create', [ptalPayload]);
        }
        
        res.json({ success: true, message: "Producto creado", productId: tmplId });
    } catch (error) {
        console.error("Create Product Error:", error);
        res.status(500).json({ error: error.message || error.faultString || "Unknown Error" });
    }
});`;

serverJs = serverJs.replace(regex, newRoute);
fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Batching implemented successfully.");
