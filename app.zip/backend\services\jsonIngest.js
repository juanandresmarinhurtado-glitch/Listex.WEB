/**
 * Servicio de ingesta de catálogos vía enlace JSON.
 * Lee un JSON con la estructura DATA WEB 3 (Odoo) y lo almacena en Render PG.
 * Esto permite que cualquier proveedor pegue un enlace JSON con sus datos
 * y la web los sirva desde PG sin tocar la API de Odoo.
 *
 * Estructura esperada por producto (DATA WEB 3):
 *   { id_template, nombre_base, categoria_principal, categorias_web[],
 *     descripcion, imagen_url, cost_usd, permitir_venta_sin_stock,
 *     presentaciones[], variantes[] }
 */
const { pool } = require('../db/init');

// ── Fetch + parse del enlace JSON ─────────────────────────────────────────────
async function fetchCatalogJson(url) {
    const cacheBuster = (url.includes('?') ? '&' : '?') + 't=' + Date.now();
    const res = await fetch(url + cacheBuster, { signal: AbortSignal.timeout(30000) });
    if (!res.ok) throw new Error(`HTTP ${res.status} al leer el enlace`);
    const data = await res.json();
    if (!Array.isArray(data)) throw new Error('El JSON debe ser un array de productos');
    return data;
}

// ── Validar que un producto tenga la estructura mínima ────────────────────────
function isValidProduct(p) {
    return p && (p.id_template !== undefined || p.id_producto !== undefined)
        && (p.nombre_base || p.nombre);
}

// ── Normaliza un producto del JSON a la estructura interna v3 ──────────────────
// Soporta tanto DATA WEB 3 (id_template/nombre_base) como variantes legacy
function normalizeProduct(p) {
    const externalId = String(p.id_template ?? p.id_producto);
    const nombre = p.nombre_base ?? p.nombre ?? 'Producto';
    const categoria = p.categoria_principal
        ?? (Array.isArray(p.categorias_web) && p.categorias_web[0])
        ?? 'General';
    return {
        externalId,
        nombre,
        categoria,
        imagen_url: p.imagen_url || '',
        cost: parseFloat(p.cost_usd) || 0,
        // El objeto completo se guarda tal cual para servir el catálogo
        catalog_json: p,
    };
}

// ── Ingesta principal: vuelca el JSON del proveedor en PG ──────────────────────
async function ingestSupplierJson(supplierId, jsonUrl) {
    const started = Date.now();
    let products;
    try {
        products = await fetchCatalogJson(jsonUrl);
    } catch (err) {
        await updateSourceStatus(supplierId, jsonUrl, 'error', err.message, 0);
        throw err;
    }

    const valid = products.filter(isValidProduct).map(normalizeProduct);
    const seenExternalIds = new Set();

    const client = await pool.connect();
    try {
        await client.query('BEGIN');

        for (const np of valid) {
            seenExternalIds.add(np.externalId);
            const id = `json_${supplierId}_${np.externalId}`;
            await client.query(
                `INSERT INTO portal_products
                   (id, supplier_id, external_id, name, categoria, imagen_url, cost,
                    catalog_json, source, sync_status, created_at, updated_at)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'json_link','synced',$9,$9)
                 ON CONFLICT (id) DO UPDATE SET
                    name=EXCLUDED.name, categoria=EXCLUDED.categoria,
                    imagen_url=EXCLUDED.imagen_url, cost=EXCLUDED.cost,
                    catalog_json=EXCLUDED.catalog_json, sync_status='synced',
                    updated_at=EXCLUDED.updated_at`,
                [id, supplierId, np.externalId, np.nombre, np.categoria,
                 np.imagen_url, np.cost, JSON.stringify(np.catalog_json), started]
            );
        }

        // Eliminar productos de este proveedor (vía JSON) que ya no están en el enlace
        if (seenExternalIds.size > 0) {
            await client.query(
                `DELETE FROM portal_products
                 WHERE supplier_id=$1 AND source='json_link'
                 AND external_id <> ALL($2::text[])`,
                [supplierId, [...seenExternalIds]]
            );
        } else {
            // JSON vacío → limpiar todo lo de este proveedor por JSON
            await client.query(
                `DELETE FROM portal_products WHERE supplier_id=$1 AND source='json_link'`,
                [supplierId]
            );
        }

        await client.query('COMMIT');
    } catch (err) {
        await client.query('ROLLBACK');
        await updateSourceStatus(supplierId, jsonUrl, 'error', err.message, 0);
        throw err;
    } finally {
        client.release();
    }

    await updateSourceStatus(supplierId, jsonUrl, 'ok', null, valid.length);
    console.log(`[INGEST] Proveedor ${supplierId}: ${valid.length} productos ingestados desde JSON en ${Date.now()-started}ms`);
    return { count: valid.length, ms: Date.now() - started };
}

// ── Actualiza/crea el registro de fuente del proveedor ────────────────────────
async function updateSourceStatus(supplierId, jsonUrl, status, error, count) {
    try {
        await pool.query(
            `INSERT INTO supplier_sources
               (supplier_id, source_type, json_url, last_ingested, last_status, last_error, product_count)
             VALUES ($1,'json_link',$2,$3,$4,$5,$6)
             ON CONFLICT (supplier_id) DO UPDATE SET
                source_type='json_link', json_url=EXCLUDED.json_url,
                last_ingested=EXCLUDED.last_ingested, last_status=EXCLUDED.last_status,
                last_error=EXCLUDED.last_error, product_count=EXCLUDED.product_count`,
            [supplierId, jsonUrl, Date.now(), status, error, count]
        );
    } catch(e) { console.warn('[INGEST] No se pudo actualizar supplier_sources:', e.message); }
}

// ── Refresco automático de todas las fuentes JSON con intervalo configurado ────
async function refreshDueSources() {
    try {
        const now = Date.now();
        const due = await pool.query(
            `SELECT supplier_id, json_url, auto_refresh_min, last_ingested
             FROM supplier_sources
             WHERE source_type='json_link' AND json_url IS NOT NULL AND auto_refresh_min > 0`
        );
        for (const row of due.rows) {
            const elapsedMin = (now - (row.last_ingested || 0)) / 60000;
            if (elapsedMin >= row.auto_refresh_min) {
                ingestSupplierJson(row.supplier_id, row.json_url).catch(e =>
                    console.warn(`[INGEST] Refresco auto falló proveedor ${row.supplier_id}:`, e.message));
            }
        }
    } catch(e) { /* silencioso */ }
}

module.exports = { ingestSupplierJson, refreshDueSources, fetchCatalogJson };
