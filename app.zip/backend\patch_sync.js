const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const newRoutes = `
app.post('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const { name, cost, priceUnidad, priceDocena, priceBulto, categoryId, customAttributes, imageBase64 } = req.body;
        
        // Helper to find or create attribute
        async function getOrCreateAttribute(attrName) {
            const attrs = await executeKw('product.attribute', 'search_read', [[['name', '=', attrName]], ['id']]);
            if (attrs.length > 0) return attrs[0].id;
            return await executeKw('product.attribute', 'create', [{ name: attrName, create_variant: 'dynamic' }]);
        }

        // Helper to find or create attribute value
        async function getOrCreateAttrValue(attrId, valName) {
            const vals = await executeKw('product.attribute.value', 'search_read', [[['attribute_id', '=', attrId], ['name', '=', valName]], ['id']]);
            if (vals.length > 0) return vals[0].id;
            return await executeKw('product.attribute.value', 'create', [{ attribute_id: attrId, name: valName }]);
        }

        // 1. Create Product Template (Without Taxes)
        const productData = {
            name: name,
            list_price: parseFloat(priceUnidad) || 0,
            standard_price: parseFloat(cost) || 0,
            sale_ok: true,
            purchase_ok: true,
            is_published: true,
            taxes_id: false,
            supplier_taxes_id: false,
            seller_ids: [[0, 0, { partner_id: req.user.id, delay: 1 }]] // Create supplier info directly
        };
        
        if (imageBase64) {
            productData.image_1920 = imageBase64.split(',')[1] || imageBase64;
        }
        
        if (categoryId) {
            productData.public_categ_ids = [[6, 0, [parseInt(categoryId)]]];
        }
        
        const tmplId = await executeKw('product.template', 'create', [productData]);
        
        // Handle Pricelists Sequentially
        if (priceDocena) {
            await executeKw('product.pricelist.item', 'create', [{ pricelist_id: 3, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceDocena) }]);
        }
        if (priceBulto) {
            await executeKw('product.pricelist.item', 'create', [{ pricelist_id: 2, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceBulto) }]);
        }
        
        // Handle Attributes Sequentially
        const presentacionId = await getOrCreateAttribute('Presentación');
        let presValIds = [];
        presValIds.push(await getOrCreateAttrValue(presentacionId, 'unidad variada'));
        if (priceDocena) presValIds.push(await getOrCreateAttrValue(presentacionId, 'docena cerrada'));
        if (priceBulto) presValIds.push(await getOrCreateAttrValue(presentacionId, 'bulto'));
        
        await executeKw('product.template.attribute.line', 'create', [{ product_tmpl_id: tmplId, attribute_id: presentacionId, value_ids: [[6, 0, presValIds]] }]);

        if (customAttributes && customAttributes.length > 0) {
            for (let attr of customAttributes) {
                if (!attr.name || !attr.values || attr.values.length === 0) continue;
                const attrId = await getOrCreateAttribute(attr.name);
                let valIds = [];
                for (let v of attr.values) {
                    if (!v.trim()) continue;
                    valIds.push(await getOrCreateAttrValue(attrId, v.trim()));
                }
                if (valIds.length > 0) {
                    await executeKw('product.template.attribute.line', 'create', [{ product_tmpl_id: tmplId, attribute_id: attrId, value_ids: [[6, 0, valIds]] }]);
                }
            }
        }
        
        res.json({ success: true, message: "Producto creado", id: tmplId });
    } catch (error) {
        console.error("Create Product Error:", error);
        res.status(500).json({ error: error.message || error.faultString || "Unknown Error" });
    }
});
`;

// Replace the whole route
const startMarker = "app.post('/api/supplier/products', authenticateSupplier, async (req, res) => {";
const endMarker = "// GET Variants for a product";

const startIndex = serverJs.indexOf(startMarker);
const endIndex = serverJs.indexOf(endMarker);

if (startIndex !== -1 && endIndex !== -1) {
    const newFileContent = serverJs.substring(0, startIndex) + newRoutes + "\n" + serverJs.substring(endIndex);
    fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', newFileContent, 'utf8');
    console.log("server.js updated sequentially.");
} else {
    console.log("Could not find markers in server.js");
}
