const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

common.methodCall('authenticate', [db, username, password, {}], function (error, uid) {
    if (error) return console.error(error);
    
    models.methodCall('execute_kw', [db, uid, password, 'ir.model', 'search', [[['model', '=', 'res.partner']]]], function (err, modelIds) {
        if (err || !modelIds.length) return console.error(err);
        const partnerModelId = modelIds[0];

        const field = {
            name: 'x_studio_supplier_rif',
            field_description: 'Supplier RIF/Cedula',
            model_id: partnerModelId,
            ttype: 'char',
            state: 'manual'
        };

        models.methodCall('execute_kw', [db, uid, password, 'ir.model.fields', 'search', [[['model_id', '=', partnerModelId], ['name', '=', field.name]]]], function (err, existing) {
            if (existing && existing.length > 0) {
                console.log("Field already exists:", existing);
            } else {
                models.methodCall('execute_kw', [db, uid, password, 'ir.model.fields', 'create', [field]], function (err, fieldId) {
                    if (err) console.error("Error:", err);
                    else console.log("Created field ID", fieldId);
                });
            }
        });
    });
});
