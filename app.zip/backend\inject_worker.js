const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const syncWorkerCode = `
// ==========================================
// BACKGROUND ODOO SYNC WORKER
// ==========================================

async function processQueue() {
    try {
        const queue = readJson(queueFile);
        const variantsQueue = readJson(variantsFile);
        let hasChanges = false;
        
        for (const [tempId, item] of Object.entries(queue)) {
            if (item.status === 'pending') {
                console.log(\`[SYNC] Procesando producto \${tempId}...\`);
                item.status = 'processing';
                writeJson(queueFile, queue);
                
                try {
                    await authenticate();
                    const req = { user: { id: item.partner_id } };
                    const { name, cost, priceUnidad, priceDocena, priceBulto, categoryId, customAttributes, imageBase64, isStorable } = item.data;
                    
                    // 1. Attributes
                    const requiredAttrNames = ['Presentación'];
                    if (customAttributes) {
                        for (let attr of customAttributes) {
                            if (attr.name && attr.name.trim()) requiredAttrNames.push(attr.name.trim());
                        }
                    }
                    const uniqueAttrNames = [...new Set(requiredAttrNames)];
                    const existingAttrs = await executeKw('product.attribute', 'search_read', [[['name', 'in', uniqueAttrNames]], ['id', 'name']]);
                    const existingAttrMap = {};
                    existingAttrs.forEach(a => existingAttrMap[a.name] = a.id);
                    const attrsToCreate = uniqueAttrNames.filter(name => !existingAttrMap[name]);
                    if (attrsToCreate.length > 0) {
                        const createPayload = attrsToCreate.map(name => ({ name: name, create_variant: 'always' }));
                        const newAttrIds = await executeKw('product.attribute', 'create', [createPayload]);
                        if (Array.isArray(newAttrIds)) {
                            attrsToCreate.forEach((name, idx) => existingAttrMap[name] = newAttrIds[idx]);
                        } else {
                            attrsToCreate.forEach((name, idx) => existingAttrMap[name] = newAttrIds);
                        }
                    }
                    
                    // 2. Attribute Values
                    const requiredValues = [];
                    requiredValues.push({ attrId: existingAttrMap['Presentación'], valName: 'unidad variada' });
                    if (priceDocena) requiredValues.push({ attrId: existingAttrMap['Presentación'], valName: 'docena cerrada' });
                    if (priceBulto) requiredValues.push({ attrId: existingAttrMap['Presentación'], valName: 'bulto' });
                    
                    if (customAttributes) {
                        for (let attr of customAttributes) {
                            if (!attr.name || !attr.name.trim() || !attr.values) continue;
                            const attrId = existingAttrMap[attr.name.trim()];
                            for (let v of attr.values) {
                                if (v.trim()) requiredValues.push({ attrId: attrId, valName: v.trim() });
                            }
                        }
                    }
                    
                    const attrIds = [...new Set(requiredValues.map(r => r.attrId))];
                    const valNames = [...new Set(requiredValues.map(r => r.valName))];
                    const existingVals = await executeKw('product.attribute.value', 'search_read', [[['attribute_id', 'in', attrIds], ['name', 'in', valNames]], ['id', 'attribute_id', 'name']]);
                    const existingValMap = {};
                    existingVals.forEach(v => {
                        const aid = Array.isArray(v.attribute_id) ? v.attribute_id[0] : v.attribute_id;
                        existingValMap[\`\${aid}_\${v.name}\`] = v.id;
                    });
                    const valsToCreate = requiredValues.filter(r => !existingValMap[\`\${r.attrId}_\${r.valName}\`]);
                    const uniqueValsToCreate = [];
                    const seenVals = new Set();
                    for (let v of valsToCreate) {
                        const key = \`\${v.attrId}_\${v.valName}\`;
                        if (!seenVals.has(key)) { seenVals.add(key); uniqueValsToCreate.push(v); }
                    }
                    if (uniqueValsToCreate.length > 0) {
                        const createPayload = uniqueValsToCreate.map(r => ({ attribute_id: r.attrId, name: r.valName }));
                        const newValIds = await executeKw('product.attribute.value', 'create', [createPayload]);
                        if (Array.isArray(newValIds)) {
                            uniqueValsToCreate.forEach((r, idx) => existingValMap[\`\${r.attrId}_\${r.valName}\`] = newValIds[idx]);
                        } else {
                            uniqueValsToCreate.forEach((r, idx) => existingValMap[\`\${r.attrId}_\${r.valName}\`] = newValIds);
                        }
                    }
                    
                    // 3. Prepare Inline Lines
                    const ptalPayload = [];
                    let presValIds = [existingValMap[\`\${existingAttrMap['Presentación']}_unidad variada\`]];
                    if (priceDocena) presValIds.push(existingValMap[\`\${existingAttrMap['Presentación']}_docena cerrada\`]);
                    if (priceBulto) presValIds.push(existingValMap[\`\${existingAttrMap['Presentación']}_bulto\`]);
                    ptalPayload.push([0, 0, { attribute_id: existingAttrMap['Presentación'], value_ids: [[6, 0, presValIds]] }]);
                    
                    if (customAttributes) {
                        for (let attr of customAttributes) {
                            if (!attr.name || !attr.name.trim() || !attr.values || attr.values.length === 0) continue;
                            const attrId = existingAttrMap[attr.name.trim()];
                            let valIds = [];
                            for (let v of attr.values) {
                                if (v.trim()) {
                                    const vId = existingValMap[\`\${attrId}_\${v.trim()}\`];
                                    if (vId) valIds.push(vId);
                                }
                            }
                            if (valIds.length > 0) ptalPayload.push([0, 0, { attribute_id: attrId, value_ids: [[6, 0, valIds]] }]);
                        }
                    }
                    
                    // 4. Create Product Template
                    const productDataPayload = {
                        name: name,
                        list_price: parseFloat(priceUnidad) || 0,
                        standard_price: parseFloat(cost) || 0,
                        sale_ok: true, purchase_ok: true, is_published: true,
                        is_storable: isStorable ? true : false,
                        seller_ids: [[0, 0, { partner_id: req.user.id, delay: 1 }]],
                        attribute_line_ids: ptalPayload
                    };
                    if (categoryId) productDataPayload.public_categ_ids = [[6, 0, [parseInt(categoryId)]]];
                    
                    const tmplId = await executeKw('product.template', 'create', [productDataPayload]);
                    console.log(\`[SYNC] Creado template Odoo ID \${tmplId} para \${tempId}\`);
                    
                    // Upload Base Image
                    if (imageBase64) {
                        const rawB64 = imageBase64.split(',')[1] || imageBase64;
                        await executeKw('product.template', 'write', [[tmplId], { image_1920: rawB64 }]);
                    }
                    
                    // 5. Pricelists
                    const pricelistPayload = [];
                    if (priceDocena) pricelistPayload.push({ pricelist_id: 3, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceDocena) });
                    if (priceBulto) pricelistPayload.push({ pricelist_id: 2, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceBulto) });
                    for (let pl of pricelistPayload) {
                        await executeKw('product.pricelist.item', 'create', [pl]);
                    }
                    
                    // 6. Map and Update Variants from Queue
                    const fakeVariants = variantsQueue[tempId] || [];
                    if (fakeVariants.length > 0) {
                        const odooVariants = await executeKw('product.product', 'search_read', [[['product_tmpl_id', '=', tmplId]], ['id', 'product_template_attribute_value_ids']]);
                        
                        const allPtavIds = new Set();
                        odooVariants.forEach(v => {
                            if (v.product_template_attribute_value_ids) v.product_template_attribute_value_ids.forEach(id => allPtavIds.add(id));
                        });
                        const ptavMap = {};
                        if (allPtavIds.size > 0) {
                            const ptavs = await executeKw('product.template.attribute.value', 'search_read', [[['id', 'in', [...allPtavIds]]], ['id', 'name']]);
                            ptavs.forEach(pt => ptavMap[pt.id] = pt.name);
                        }
                        
                        // Get locations
                        let stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'WH/']]], { fields: ['id'], limit: 1 });
                        if (stockLocations.length === 0) stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'PT/']]], { fields: ['id'], limit: 1 });
                        if (stockLocations.length === 0) stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal']]], { fields: ['id'], limit: 1 });
                        const locId = stockLocations.length > 0 ? stockLocations[0].id : null;

                        for (let ov of odooVariants) {
                            let ovName = "Variante Base";
                            if (ov.product_template_attribute_value_ids && ov.product_template_attribute_value_ids.length > 0) {
                                ovName = ov.product_template_attribute_value_ids.map(id => ptavMap[id] || '').filter(Boolean).join(' / ');
                            }
                            
                            // Find matching fake variant by name
                            const matchFake = fakeVariants.find(fv => {
                                // Match exactly or roughly
                                return fv.attribute_names === ovName || ovName.includes(fv.attribute_names) || fv.attribute_names.includes(ovName);
                            });
                            
                            if (matchFake) {
                                // Apply stock
                                if (matchFake.stock_updated && matchFake.qty_available > 0 && locId) {
                                    const quantId = await executeKw('stock.quant', 'create', [{ product_id: ov.id, location_id: locId, inventory_quantity: matchFake.qty_available }]);
                                    try { await executeKw('stock.quant', 'action_apply_inventory', [[quantId]]); } catch(e){}
                                }
                                // Apply image
                                if (matchFake.image_updated && matchFake.image_variant_1920) {
                                    await executeKw('product.product', 'write', [[ov.id], { image_1920: matchFake.image_variant_1920 }]);
                                }
                            }
                        }
                    }
                    
                    item.status = 'done';
                    item.odooId = tmplId;
                    hasChanges = true;
                    console.log(\`[SYNC] Producto \${tempId} sincronizado exitosamente.\`);
                } catch (syncErr) {
                    console.error(\`[SYNC] Error con \${tempId}:\`, syncErr);
                    item.status = 'error';
                    item.error = syncErr.message;
                    hasChanges = true;
                }
            }
        }
        
        if (hasChanges) writeJson(queueFile, queue);
    } catch (err) {
        console.error("Queue loop error:", err);
    }
}

setInterval(processQueue, 15000); // Check every 15 seconds

`;

serverJs += '\n' + syncWorkerCode;
fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Injected Background Worker");
