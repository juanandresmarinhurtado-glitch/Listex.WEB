const { Pool } = require('pg');

// Render internal URLs use hostname pattern "dpg-*" without ".render.com"
// External URLs use "*.oregon-postgres.render.com" or similar
const isRenderInternal = process.env.DATABASE_URL &&
    !process.env.DATABASE_URL.includes('.render.com') &&
    process.env.DATABASE_URL.includes('dpg-');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: isRenderInternal ? false : { rejectUnauthorized: false },
    connectionTimeoutMillis: 10000, // 10s: accounts for free-tier cold starts (3-8s)
    idleTimeoutMillis: 30000,
    max: 5
});

async function initDB() {
    try {
        const client = await pool.connect();
        try {
            // Suppliers Cache
            await client.query(`
                CREATE TABLE IF NOT EXISTS suppliers (
                    id INT PRIMARY KEY,
                    name VARCHAR,
                    email VARCHAR,
                    last_sync BIGINT
                );
            `);
            
            // Products
            await client.query(`
                CREATE TABLE IF NOT EXISTS portal_products (
                    id VARCHAR PRIMARY KEY,
                    supplier_id INT,
                    odoo_tmpl_id INT,
                    name VARCHAR,
                    category_id INT,
                    price_unidad NUMERIC,
                    price_docena NUMERIC,
                    price_bulto NUMERIC,
                    cost NUMERIC,
                    image_base64 TEXT,
                    custom_attributes TEXT,
                    sync_status VARCHAR DEFAULT 'pending',
                    sync_error TEXT,
                    created_at BIGINT
                );
            `);
            // Migrate existing tables that may lack new columns
            // PG-first: los proveedores viven en Odoo, no en PG. Quitamos la FK a suppliers
            // para permitir ingestar productos por enlace JSON sin un registro previo del proveedor.
            await client.query(`ALTER TABLE portal_products DROP CONSTRAINT IF EXISTS portal_products_supplier_id_fkey`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS custom_attributes TEXT`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS is_storable BOOLEAN DEFAULT false`);
            // Presentación Universal (web3) fields
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_detal_usd NUMERIC`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_combo_habilitado BOOLEAN DEFAULT false`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_combo_usd NUMERIC`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_combo_piezas INTEGER DEFAULT 3`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_combo_surtido BOOLEAN DEFAULT false`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_docena_habilitado BOOLEAN DEFAULT false`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_docena_usd NUMERIC`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_docena_surtido BOOLEAN DEFAULT false`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_bulto_habilitado BOOLEAN DEFAULT false`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_bulto_usd NUMERIC`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_bulto_piezas INTEGER DEFAULT 24`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_bulto_surtido BOOLEAN DEFAULT false`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS x_web3_precio_ves NUMERIC`);
            
            // Variants
            await client.query(`
                CREATE TABLE IF NOT EXISTS portal_variants (
                    id VARCHAR PRIMARY KEY,
                    product_id VARCHAR REFERENCES portal_products(id) ON DELETE CASCADE,
                    odoo_prod_id INT,
                    attributes TEXT,
                    qty INT DEFAULT 0,
                    image_base64 TEXT
                );
            `);

            // ── ARQUITECTURA PG-FIRST: catálogo servido desde Render ───────────
            // catalog_json: estructura v3 completa por producto (DATA WEB 3)
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS catalog_json JSONB`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS source VARCHAR DEFAULT 'portal'`);   // 'portal' | 'json_link'
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS external_id VARCHAR`);              // id_template del JSON externo
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS categoria VARCHAR`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS imagen_url TEXT`);
            await client.query(`ALTER TABLE portal_products ADD COLUMN IF NOT EXISTS updated_at BIGINT`);
            // Índices para ensamblar el catálogo rápido
            await client.query(`CREATE INDEX IF NOT EXISTS idx_portal_products_supplier ON portal_products(supplier_id)`);
            await client.query(`CREATE INDEX IF NOT EXISTS idx_portal_products_catalog ON portal_products((catalog_json IS NOT NULL))`);
            await client.query(`CREATE UNIQUE INDEX IF NOT EXISTS idx_portal_products_ext ON portal_products(supplier_id, external_id) WHERE external_id IS NOT NULL`);

            // Configuración de fuente de datos por proveedor
            await client.query(`
                CREATE TABLE IF NOT EXISTS supplier_sources (
                    supplier_id INT PRIMARY KEY,
                    source_type VARCHAR DEFAULT 'manual',
                    json_url TEXT,
                    auto_refresh_min INT DEFAULT 0,
                    last_ingested BIGINT,
                    last_status VARCHAR,
                    last_error TEXT,
                    product_count INT DEFAULT 0
                );
            `);

            console.log("[DB] PostgreSQL tables initialized successfully.");
        } finally {
            client.release();
        }
    } catch (err) {
        console.error("[DB] Error connecting to PostgreSQL:", err.message);
    }
}

module.exports = {
    pool,
    initDB
};
