const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const getDashboardRegex = /app\.get\('\/api\/supplier\/products', authenticateSupplier, async \(req, res\) => \{[\s\S]*?(?=\napp\.post\('\/api\/supplier\/products',)/;

const newDashboardCode = `
const supplierProductsCache = {};

app.get('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        const partnerId = req.user.id;
        
        let cachedProducts = [];
        if (supplierProductsCache[partnerId]) {
            cachedProducts = supplierProductsCache[partnerId].products;
        }
        
        // Merge pending products from local queue
        const mergedProducts = [...cachedProducts];
        try {
            const queue = readJson(queueFile);
            for (const [tempId, item] of Object.entries(queue)) {
                if (item.partner_id === partnerId && (item.status === 'pending' || item.status === 'processing' || item.status === 'error')) {
                    if (!mergedProducts.find(p => p.id === tempId)) {
                        mergedProducts.unshift({
                            id: tempId,
                            name: item.data.name + (item.status==='error' ? ' (Error)' : ' (Procesando...)'),
                            list_price: item.data.priceUnidad,
                            standard_price: item.data.cost,
                            qty_available: 0,
                            is_published: false,
                            isPending: true
                        });
                    }
                }
            }
        } catch(e) {}
        
        if (mergedProducts.length > 0) {
            res.json({ success: true, products: mergedProducts });
        }
        
        // Background Refresh
        authenticate().then(async () => {
            const supplierInfos = await executeKw('product.supplierinfo', 'search_read', [
                [['partner_id', '=', partnerId]]
            ], { fields: ['product_tmpl_id'] });
            
            if (supplierInfos.length > 0) {
                const templateIds = supplierInfos.map(s => s.product_tmpl_id[0]);
                const freshProducts = await executeKw('product.template', 'search_read', [
                    [['id', 'in', templateIds]],
                    ['id', 'name', 'list_price', 'standard_price', 'qty_available', 'is_published', 'image_128']
                ]);
                supplierProductsCache[partnerId] = { timestamp: Date.now(), products: freshProducts };
            } else {
                supplierProductsCache[partnerId] = { timestamp: Date.now(), products: [] };
            }
        }).catch(err => console.error("Background Cache Refresh Error:", err));
        
        // If cache was empty, wait a tiny bit to see if background refresh finishes quickly, else return empty
        if (mergedProducts.length === 0) {
            setTimeout(() => {
                if (!res.headersSent) {
                    if (supplierProductsCache[partnerId]) {
                        res.json({ success: true, products: supplierProductsCache[partnerId].products });
                    } else {
                        res.json({ success: true, products: [] });
                    }
                }
            }, 1500);
        }
        
    } catch (error) {
        if (!res.headersSent) res.status(500).json({ error: error.message });
    }
});`;

serverJs = serverJs.replace(getDashboardRegex, newDashboardCode);
fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');

// Patching proveedores.html
let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');
html = html.replace('onclick="updateVariantStock(${v.id})"', "onclick=\\\"updateVariantStock('\${v.id}')\\\"");
html = html.replace('onchange="uploadVariantImage(this, ${v.id})"', "onchange=\\\"uploadVariantImage(this, '\${v.id}')\\\"");
fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');

console.log("Patched dashboard caching and HTML quotes.");
