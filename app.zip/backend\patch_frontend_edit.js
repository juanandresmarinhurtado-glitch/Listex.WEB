const fs = require('fs');
let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// 1. Add Inventory Toggle to the main form
const inventarioHTML = `
    <div class="form-group" style="margin-top:20px; background:#eff6ff; padding:15px; border-radius:8px; border:1px solid #bfdbfe;">
        <label style="display:flex; align-items:center; gap:10px; cursor:pointer; color:var(--primary); margin:0;">
            <input type="checkbox" id="prod-inventario" style="width:20px; height:20px;">
            <span><ion-icon name="layers-outline"></ion-icon> Controlar Inventario (Vender con Stock exacto)</span>
        </label>
        <p style="font-size:0.8rem; color:var(--text-muted); margin-top:5px; margin-left:30px;">Si activas esta opción, podrás asignar unidades exactas a cada variante.</p>
    </div>
`;

if (!html.includes('id="prod-inventario"')) {
    html = html.replace('<div class="form-group" style="background: var(--bg-color); padding: 15px; border-radius: 8px; border: 1px solid var(--border-color);">', inventarioHTML + '\n                                <div class="form-group" style="background: var(--bg-color); padding: 15px; border-radius: 8px; border: 1px solid var(--border-color);">');
}

// 2. Add Variants Section at the bottom of the Create/Edit Form
const variantManagerHTML = `
    <!-- Variants Manager (Visible only in Edit Mode) -->
    <div id="variants-manager-section" class="form-section hidden" style="margin-top:30px; grid-column:1 / -1;">
        <h3><ion-icon name="images-outline"></ion-icon> Variantes y Stock</h3>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 15px;">Sube fotos exclusivas para cada variante y actualiza tu inventario disponible en tiempo real.</p>
        <div id="inline-variants-list" style="display:flex; flex-direction:column; gap:15px;"></div>
    </div>
`;

if (!html.includes('id="variants-manager-section"')) {
    // Insert before the Save button
    html = html.replace('<button type="submit" class="btn btn-primary w-100"', variantManagerHTML + '\n                            <button type="submit" class="btn btn-primary w-100"');
}

// 3. Delete Modals that are no longer needed
// We can just keep them hidden or replace their triggers. The Edit Modal is definitely obsolete.

// 4. Update the openEditModal function
const newOpenEditModal = `
        let editModeId = null;

        async function openEditModal(id) {
            editModeId = id;
            document.getElementById('btn-create-product').innerHTML = '<ion-icon name="sync-outline" class="spin"></ion-icon> Cargando Datos...';
            document.getElementById('btn-create-product').disabled = true;
            
            // Switch to form tab
            switchTab('tab-crear', document.querySelectorAll('.dash-tab')[1]);
            document.querySelectorAll('.dash-tab')[1].innerHTML = '<ion-icon name="create-outline"></ion-icon> Editando Producto';
            
            // Hide custom attributes section
            document.getElementById('custom-attributes-container').parentElement.style.display = 'none';
            
            try {
                const res = await fetch(API_BASE + '/products/' + id, { headers: getAuthHeaders() });
                const data = await res.json();
                
                if (data.success) {
                    const p = data.product;
                    document.getElementById('prod-name').value = p.name;
                    document.getElementById('prod-category').value = p.categoryId;
                    document.getElementById('prod-cost').value = p.cost;
                    document.getElementById('prod-price-unidad').value = p.priceUnidad;
                    document.getElementById('prod-price-docena').value = p.priceDocena || '';
                    document.getElementById('prod-price-bulto').value = p.priceBulto || '';
                    document.getElementById('prod-inventario').checked = p.isStorable;
                    
                    if (p.imageBase64) {
                        base64Image = 'data:image/webp;base64,' + p.imageBase64;
                        document.getElementById('image-preview').innerHTML = \`<img src="\${base64Image}" /> <input type="file" id="prod-image-hidden" style="display:none;">\`;
                        document.getElementById('prod-image').removeAttribute('required'); // No longer required if editing
                    }
                    
                    // Show Variants section
                    const vSection = document.getElementById('variants-manager-section');
                    vSection.classList.remove('hidden');
                    const vList = document.getElementById('inline-variants-list');
                    vList.innerHTML = '';
                    
                    if (p.variants && p.variants.length > 0) {
                        p.variants.forEach(v => {
                            const imgHtml = v.image_variant_1920 
                                ? \`<img id="img-var-\${v.id}" src="data:image/webp;base64,\${v.image_variant_1920}" style="width:100%; height:100%; object-fit:cover;">\`
                                : \`<ion-icon name="camera-outline" style="font-size:1.5rem; color:var(--text-muted);" id="icon-var-\${v.id}"></ion-icon>
                                   <img id="img-var-\${v.id}" style="width:100%; height:100%; object-fit:cover; display:none;">\`;
                                   
                            const stockHtml = p.isStorable 
                                ? \`<div style="display:flex; align-items:center; gap:8px;">
                                       <span style="font-size:0.8rem; color:var(--text-muted);">Stock:</span>
                                       <input type="number" id="stock-var-\${v.id}" value="\${v.qty_available || 0}" style="width:70px; padding:6px; border-radius:4px; border:1px solid var(--border-color); text-align:center;">
                                       <button type="button" class="btn btn-secondary" onclick="updateVariantStock(\${v.id})" style="padding:6px 10px; font-size:0.8rem;">Guardar</button>
                                       <span id="stock-status-\${v.id}" style="font-size:0.8rem; margin-left:5px;"></span>
                                   </div>\`
                                : \`<p style="font-size:0.8rem; color:var(--text-muted); margin-top:5px;">Inventario no controlado</p>\`;
                                
                            vList.innerHTML += \`
                                <div style="display:flex; align-items:center; gap:15px; padding:15px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-color);">
                                    <div style="flex:1;">
                                        <strong style="color:var(--text-main);">\${v.attribute_names}</strong>
                                        \${stockHtml}
                                    </div>
                                    <div style="display:flex; flex-direction:column; align-items:center; gap:5px;">
                                        <div style="width:60px; height:60px; border-radius:8px; overflow:hidden; background:#e2e8f0; display:flex; align-items:center; justify-content:center; position:relative; cursor:pointer;" onclick="document.getElementById('file-var-\${v.id}').click()">
                                            \${imgHtml}
                                        </div>
                                        <span id="status-var-\${v.id}" style="font-size:0.7rem; color:var(--text-muted);">Cambiar</span>
                                    </div>
                                    <input type="file" id="file-var-\${v.id}" style="display:none;" accept="image/*" onchange="uploadVariantImage(this, \${v.id})">
                                </div>
                            \`;
                        });
                    } else {
                        vList.innerHTML = '<p style="color:var(--text-muted); font-size:0.9rem;">No hay variantes creadas.</p>';
                    }
                }
            } catch (err) {
                showToast('Error cargando producto para edición');
            }
            
            document.getElementById('btn-create-product').disabled = false;
            document.getElementById('btn-create-product').innerHTML = '<ion-icon name="save-outline"></ion-icon> Guardar Cambios';
        }

        async function updateVariantStock(variantId) {
            const qty = document.getElementById('stock-var-' + variantId).value;
            const statusEl = document.getElementById('stock-status-' + variantId);
            statusEl.textContent = "Guardando...";
            statusEl.style.color = "var(--primary)";
            
            try {
                const res = await fetch(API_BASE + '/variants/' + variantId + '/stock', {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify({ qty: qty })
                });
                if ((await res.json()).success) {
                    statusEl.textContent = "¡Stock actualizado!";
                    statusEl.style.color = "green";
                    setTimeout(() => statusEl.textContent = '', 3000);
                } else {
                    statusEl.textContent = "Error";
                    statusEl.style.color = "red";
                }
            } catch (e) {
                statusEl.textContent = "Error de red";
                statusEl.style.color = "red";
            }
        }

        // We need to override switchTab so if they click "Nuevo Producto", we reset the form
        const originalSwitchTab = switchTab;
        switchTab = function(tabId, btn) {
            originalSwitchTab(tabId, btn);
            if (tabId === 'tab-crear') {
                if (!editModeId) {
                    // It's a real new product
                    document.getElementById('create-product-form').reset();
                    document.getElementById('custom-attributes-container').innerHTML = '';
                    document.getElementById('custom-attributes-container').parentElement.style.display = 'block';
                    document.getElementById('variants-manager-section').classList.add('hidden');
                    document.getElementById('btn-create-product').innerHTML = '<ion-icon name="checkmark-circle-outline"></ion-icon> Guardar y Publicar en Tienda';
                    document.querySelectorAll('.dash-tab')[1].innerHTML = '<ion-icon name="add-circle-outline"></ion-icon> Nuevo Producto';
                    document.getElementById('prod-image').setAttribute('required', 'true');
                    document.getElementById('image-preview').innerHTML = '<div class="placeholder"><ion-icon name="image-outline" style="font-size:3rem; margin-bottom:10px;"></ion-icon><br>Haz clic aquí para seleccionar una foto<br><span style="font-size:0.8rem; font-weight:normal;">Formatos admitidos: JPG, PNG, WEBP</span></div><input type="file" id="prod-image" accept="image/png, image/jpeg, image/webp" required>';
                    base64Image = null;
                }
            } else {
                editModeId = null; // Clear edit mode when switching away
                document.querySelectorAll('.dash-tab')[1].innerHTML = '<ion-icon name="add-circle-outline"></ion-icon> Nuevo Producto';
            }
        }
`;

// Inject the new JS block. We will replace the old `openEditModal`
const replaceRegex = /function openEditModal[\s\S]*?(?=\n        document\.getElementById\('edit-product-form'\))/;

if (html.match(replaceRegex)) {
    html = html.replace(replaceRegex, newOpenEditModal + "\n");
} else {
    // If we can't find it precisely, let's inject it before window.onload
    html = html.replace('// INIT', newOpenEditModal + '\n        // INIT');
}

// Update the Form Submit logic to handle both Create and Edit
const oldSubmitRegex = /document\.getElementById\('create-product-form'\)\.addEventListener\('submit', async \(e\) => {[\s\S]*?(?=btn\.disabled = false;)/;

const newSubmitLogic = `
        document.getElementById('create-product-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('btn-create-product');
            btn.disabled = true;
            btn.innerHTML = '<ion-icon name="sync-outline" class="spin"></ion-icon> ' + (editModeId ? 'Guardando Cambios...' : 'Sincronizando con Web Listex...');
            
            try {
                const body = {
                    name: document.getElementById('prod-name').value,
                    categoryId: document.getElementById('prod-category').value,
                    cost: document.getElementById('prod-cost').value,
                    priceUnidad: document.getElementById('prod-price-unidad').value,
                    priceDocena: document.getElementById('prod-price-docena').value,
                    priceBulto: document.getElementById('prod-price-bulto').value,
                    imageBase64: base64Image,
                    isStorable: document.getElementById('prod-inventario').checked,
                    customAttributes: Array.from(document.getElementById('custom-attributes-container').children).map(row => ({
                        name: row.querySelector('.attr-name').value,
                        values: row.querySelector('.attr-values').value.split(',').map(v => v.trim()).filter(v => v)
                    }))
                };

                const url = editModeId ? (API_BASE + '/products/' + editModeId + '/edit') : (API_BASE + '/products');
                
                const res = await fetch(url, {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify(body)
                });
                
                const data = await res.json();
                if(data.success) {
                    showToast(editModeId ? '¡Cambios guardados con éxito!' : '¡Producto creado con éxito!');
                    if (!editModeId) {
                        // Switch to edit mode automatically to allow photo/stock management
                        openEditModal(data.id);
                    }
                } else {
                    showToast(data.error || 'Error al procesar en Web Listex');
                }
            } catch (err) {
                showToast('Error de conexión con el servidor central');
            }
            
            // Note: If we switched to edit mode, the button was handled there.
            if (!editModeId) {
                btn.disabled = false;
                btn.innerHTML = '<ion-icon name="checkmark-circle-outline"></ion-icon> Guardar y Publicar en Tienda';
            }
`;

html = html.replace(oldSubmitRegex, newSubmitLogic);

// Modify the old button injection inside loadProducts to pass only ID
html = html.replace(/openEditModal\(\$\{p\.id\}, '.*?'\)/g, "openEditModal(${p.id})");
html = html.replace(/openEditModal\(\$\{p\.id\},[^)]*\)/g, "openEditModal(${p.id})");

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("UI updated for full edit.");
