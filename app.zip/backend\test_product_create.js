// Prueba completa de creación de producto con nueva lógica
const xmlrpc = require('xmlrpc');
const https  = require('https');
const models = xmlrpc.createSecureClient({ host:'listex.odoo.com', port:443, path:'/xmlrpc/2/object', timeout:90000 });
const DB='listex', PASS='Seguridad400%', UID=2;

function odoo(m,mt,a,k={}) {
    return new Promise((r,j)=>{
        models.methodCall('execute_kw',[DB,UID,PASS,m,mt,a,k],(e,res)=>{ if(e) return j(e); r(res); });
    });
}
function fetchJson(url) {
    return new Promise((res,rej)=>{
        https.get(url,r=>{ let d=''; r.on('data',c=>d+=c); r.on('end',()=>{ try{res(JSON.parse(d));}catch(e){rej(e);} }); }).on('error',rej);
    });
}

async function run() {
    console.log('=== PRUEBA END-TO-END: NUEVO PRODUCTO PROVEEDOR ===\n');

    // PASO 1: Atributos
    console.log('PASO 1: Atributos Color y Talla...');
    const allAttrs = await odoo('product.attribute','search_read',[[['name','in',['Color','Talla']]]],{fields:['id','name']});
    const colorAttrId = allAttrs.find(a=>a.name==='Color').id;
    const tallaAttrId = allAttrs.find(a=>a.name==='Talla').id;

    const colorVals = await odoo('product.attribute.value','search_read',[[['attribute_id','=',colorAttrId],['name','in',['Blanco','Negro','Rosa']]]],{fields:['id','name']});
    const colorIds = colorVals.map(v=>v.id);
    for (const c of ['Blanco','Negro','Rosa']) {
        if (!colorVals.find(v=>v.name===c)) colorIds.push(await odoo('product.attribute.value','create',[{name:c,attribute_id:colorAttrId}]));
    }
    const tallaVals = await odoo('product.attribute.value','search_read',[[['attribute_id','=',tallaAttrId],['name','in',['36','37','38','39']]]],{fields:['id','name']});
    const tallaIds = tallaVals.map(v=>v.id);
    for (const t of ['36','37','38','39']) {
        if (!tallaVals.find(v=>v.name===t)) tallaIds.push(await odoo('product.attribute.value','create',[{name:t,attribute_id:tallaAttrId}]));
    }
    console.log('  Color IDs:', colorIds, '| Talla IDs:', tallaIds);

    // PASO 2: Tipo de Venta para docena surtida
    console.log('\nPASO 2: Atributo Tipo de Venta (Docena surtida)...');
    let tvAttrs = await odoo('product.attribute','search_read',[[['name','=','Tipo de Venta']]],{fields:['id']});
    const tvAttrId = tvAttrs.length > 0 ? tvAttrs[0].id : await odoo('product.attribute','create',[{name:'Tipo de Venta',create_variant:'no_variant'}]);
    let tvVals = await odoo('product.attribute.value','search_read',[[['attribute_id','=',tvAttrId],['name','=','Docena (surtido)']]],{fields:['id']});
    const tvValId = tvVals.length > 0 ? tvVals[0].id : await odoo('product.attribute.value','create',[{name:'Docena (surtido)',attribute_id:tvAttrId}]);
    console.log('  Tipo de Venta ID:', tvAttrId, '| Docena (surtido) ID:', tvValId);

    // PASO 3: Crear template SIN atributo Presentación
    console.log('\nPASO 3: Crear template (sin atributo Presentacion)...');
    const tmplId = await odoo('product.template','create',[{
        name:           'PRUEBA Zapato Deportivo Dama',
        description_sale: 'Zapato deportivo de prueba. 3 colores, 4 tallas.',
        list_price:     10.00,
        standard_price: 6.50,
        type:           'consu',
        is_storable:    true,
        sale_ok:true, purchase_ok:true, is_published:true,
        public_categ_ids: [[6,0,[5]]],
        attribute_line_ids: [
            [0,0,{attribute_id:colorAttrId, value_ids:[[6,0,colorIds]]}],
            [0,0,{attribute_id:tallaAttrId, value_ids:[[6,0,tallaIds]]}],
            [0,0,{attribute_id:tvAttrId,    value_ids:[[6,0,[tvValId]]]}],
        ],
        x_web3_detal_usd:        10.00,
        x_web3_cost_usd:          6.50,
        x_web3_combo_habilitado:  true,
        x_web3_combo_usd:        27.00,
        x_web3_combo_piezas:      3,
        x_web3_combo_surtido:     false,
        x_web3_docena_habilitado: true,
        x_web3_docena_usd:       96.00,
        x_web3_docena_surtido:    true,
        x_web3_bulto_habilitado:  false,
    }]);
    console.log('  Template ID:', tmplId, '✓');

    // PASO 4: Listas de precios
    console.log('\nPASO 4: Asignar listas de precios...');
    for (const [plId,price,label] of [[9,10,'Detal'],[10,27,'Combo 3pz'],[11,96,'Docena surtida']]) {
        await odoo('product.pricelist.item','create',[{pricelist_id:plId,applied_on:'1_product',product_tmpl_id:tmplId,compute_price:'fixed',fixed_price:price}]);
        console.log('  PL'+plId+' ('+label+'): $'+price+' USD ✓');
    }

    // PASO 5: Variantes
    console.log('\nPASO 5: Verificar variantes...');
    const variants = await odoo('product.product','search_read',[[['product_tmpl_id','=',tmplId],['active','=',true]]],{fields:['id','display_name','qty_available']});
    console.log('  Variantes creadas:', variants.length);
    variants.slice(0,4).forEach(v=>console.log('   -', v.display_name, '| stock:', v.qty_available));

    // PASO 6: Verificar costo en Odoo
    console.log('\nPASO 6: Verificar costo y campos web3 en Odoo...');
    const tmpl = await odoo('product.template','read',[[tmplId]],{fields:['standard_price','list_price','x_web3_detal_usd','x_web3_cost_usd','x_web3_docena_surtido','x_web3_combo_piezas']});
    const t = tmpl[0];
    console.log('  standard_price (COSTO):  $'+t.standard_price, t.standard_price===6.5?'✓':'✗ esperado 6.50');
    console.log('  list_price (DETAL):      $'+t.list_price,    t.list_price===10?'✓':'✗ esperado 10.00');
    console.log('  x_web3_detal_usd:        $'+t.x_web3_detal_usd, t.x_web3_detal_usd===10?'✓':'✗');
    console.log('  x_web3_cost_usd:         $'+t.x_web3_cost_usd, t.x_web3_cost_usd===6.5?'✓':'✗');
    console.log('  x_web3_docena_surtido:  ', t.x_web3_docena_surtido, t.x_web3_docena_surtido===true?'✓':'✗ esperado true');
    console.log('  x_web3_combo_piezas:    ', t.x_web3_combo_piezas, t.x_web3_combo_piezas===3?'✓':'✗ esperado 3');

    // PASO 7: Verificar pricelist items
    console.log('\nPASO 7: Verificar items de listas de precios...');
    const plItems = await odoo('product.pricelist.item','search_read',[[['product_tmpl_id','=',tmplId],['pricelist_id','in',[9,10,11,12]]]],{fields:['pricelist_id','fixed_price']});
    const plNames = {9:'Detal',10:'Combo',11:'Docena',12:'Bulto'};
    plItems.forEach(i=>console.log('  PL'+i.pricelist_id[0]+' ('+plNames[i.pricelist_id[0]]+'): $'+i.fixed_price+' ✓'));
    const presAttrUsed = await odoo('product.template.attribute.line','search_read',[[['product_tmpl_id','=',tmplId]]],{fields:['attribute_id']});
    const attrNames = presAttrUsed.map(a=>a.attribute_id[1]);
    console.log('\nPASO 8: Atributos usados en el producto:', attrNames.join(', '));
    const hasPresAttr = attrNames.some(n=>n.toLowerCase().includes('presentaci'));
    console.log('  Atributo Presentación:', hasPresAttr ? '✗ NO DEBE ESTAR' : '✓ NO creado');

    // PASO 9: Ejecutar DATA WEB 3
    console.log('\nPASO 9: Ejecutando DATA WEB 3...');
    const r3 = await odoo('ir.actions.server','run',[[3047]]);
    console.log('  ✓ JSON actualizado:', r3.url);

    // PASO 10: Verificar en JSON v3
    console.log('\nPASO 10: Verificar en JSON v3...');
    await new Promise(r=>setTimeout(r,2000));
    const v3 = await fetchJson('https://listex.odoo.com/web/content/18758/api_catalogo_listex_v3.json?t='+Date.now());
    const prod = v3.find(p=>p.nombre_base.includes('PRUEBA Zapato'));
    if (prod) {
        console.log('  ✓ Producto en JSON v3!');
        console.log('  Presentaciones:');
        prod.presentaciones.forEach(p=>console.log('    ['+p.tipo+'] $'+p.precio_usd+' | PL:'+p.pricelist_id+' | escoge:'+p.cliente_escoge+' | piezas:'+p.piezas_requeridas));
        console.log('  Variantes en JSON:', prod.variantes.length);
    } else {
        console.log('  ✗ No encontrado en JSON v3');
    }

    console.log('\n=== PRUEBA COMPLETA ===');
    console.log('Template ID:', tmplId);
    console.log('Todos los pasos verificados.');
}

run().catch(e=>{ console.error('ERR:',e.message); if(e.faultString) console.error(e.faultString.substring(0,500)); });
