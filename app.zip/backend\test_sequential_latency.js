const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            const start = Date.now();
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                console.log(`[${model}.${method}] took ${(Date.now() - start)/1000}s`);
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        console.log("Preparing Sequential Test...");
        const productData = {
            name: "Test Sequential Product Latency",
            list_price: 10,
        };
        
        console.log("Creating template base...");
        const tmplId = await executeKw('product.template', 'create', [productData]);
        console.log("Template ID:", tmplId);
        
        console.log("Adding Attribute 1...");
        await executeKw('product.template.attribute.line', 'create', [{ attribute_id: 39, product_tmpl_id: tmplId, value_ids: [[6, 0, [612, 613, 614, 615]]] }]);
        
        console.log("Adding Attribute 2...");
        await executeKw('product.template.attribute.line', 'create', [{ attribute_id: 2, product_tmpl_id: tmplId, value_ids: [[6, 0, [28, 409, 410, 411, 430]]] }]);
        
        console.log("Finished Sequential.");
        
    } catch (e) {
        console.error("Error:", e);
    }
});
