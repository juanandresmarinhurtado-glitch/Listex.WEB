const fs = require('fs');
let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const badApply = /await executeKw\\('stock\\.quant', 'action_apply_inventory', \\[\\[(existingQuant\\[0\\]\\.id|quantId)\\]\\]\\);/g;

// We need to replace all instances of this with a try/catch that ignores the marshal None error.
serverJs = serverJs.replace(badApply, (match, idVar) => {
    return "try { await executeKw('stock.quant', 'action_apply_inventory', [[" + idVar + "]]); } catch(e) { if (!e.faultString || !e.faultString.includes('cannot marshal None')) throw e; }";
});

// Let's also fix the POST response for create product where data.id was returned instead of data.productId
const badResponse = /res\\.json\\(\\{ success: true, message: "Producto creado", id: tmplId \\}\\);/;
const goodResponse = 'res.json({ success: true, message: "Producto creado", productId: tmplId });';
serverJs = serverJs.replace(badResponse, goodResponse);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Patched action_apply_inventory error and POST response.");
