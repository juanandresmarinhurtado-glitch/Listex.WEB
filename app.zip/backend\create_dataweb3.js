// Script: Crea campos x_web3_* y la acción DATA WEB 3 en Odoo
// NO modifica DATA WEB 2 (ID: 3007)

const xmlrpc = require('xmlrpc');
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object', timeout: 40000 });
const DB = 'listex', PASS = 'Seguridad400%', UID = 2;

function call(model, method, args, kwargs = {}) {
    return new Promise((res, rej) => {
        models.methodCall('execute_kw', [DB, UID, PASS, model, method, args, kwargs], (e, r) => {
            if (e) return rej(e);
            res(r);
        });
    });
}

// Código Python de DATA WEB 3
// Se usa String.raw para evitar problemas con backslashes
const DATA_WEB3_CODE = [
    "# =========================================================",
    "# DATA WEB 3 - Catalogo Presentacion Universal",
    "# Archivo: api_catalogo_listex_v3.json",
    "# DATA WEB 2 (ID 3007) NO se modifica",
    "# =========================================================",
    "",
    "base_url = env['ir.config_parameter'].sudo().get_param('web.base.url')",
    "",
    "def clean(txt):",
    "    if not txt:",
    "        return ''",
    "    return str(txt).replace('\\\\', '\\\\\\\\').replace('\"', '\\\\\"').replace('\\n', ' ').replace('\\r', '')",
    "",
    "def to_float(val):",
    "    try:",
    "        return float(val or 0)",
    "    except:",
    "        return 0.0",
    "",
    "def to_int(val):",
    "    try:",
    "        return int(val or 0)",
    "    except:",
    "        return 0",
    "",
    "def to_bool(val):",
    "    return 'true' if val else 'false'",
    "",
    "catalogo = []",
    "",
    "templates = env['product.template'].search([",
    "    ('sale_ok', '=', True),",
    "    ('is_published', '=', True),",
    "])",
    "",
    "for tmpl in templates:",
    "    tmpl_id = tmpl.id",
    "    nombre_base = clean(tmpl.name or 'Producto')",
    "    descripcion = clean(tmpl.description_sale or tmpl.name)",
    "    cost_usd = to_float(tmpl.x_web3_cost_usd) if tmpl.x_web3_cost_usd else to_float(tmpl.standard_price)",
    "",
    "    # Categorias",
    "    categs = []",
    "    cat_principal = ''",
    "    if tmpl.public_categ_ids:",
    "        cat_principal = clean(tmpl.public_categ_ids[0].name)",
    "        for c in tmpl.public_categ_ids:",
    "            categs.append('\"' + clean(c.name) + '\"')",
    "    if not categs:",
    "        cat_principal = clean(tmpl.categ_id.name or 'General')",
    "        categs = ['\"' + cat_principal + '\"']",
    "    categs_json = '[' + ','.join(categs) + ']'",
    "",
    "    img_tmpl = base_url + '/web/image/product.template/' + str(tmpl_id) + '/image_1024'",
    "    sin_stock = 'false'",
    "    if 'allow_out_of_stock_order' in tmpl and tmpl.allow_out_of_stock_order:",
    "        sin_stock = 'true'",
    "    elif 'continue_selling' in tmpl and tmpl.continue_selling:",
    "        sin_stock = 'true'",
    "    peso = str(tmpl.weight or 0.0)",
    "",
    "    tags = []",
    "    if 'product_tag_ids' in tmpl:",
    "        for tag in tmpl.product_tag_ids:",
    "            tags.append('\"' + clean(tag.name) + '\"')",
    "    tags_json = '[' + ','.join(tags) + ']'",
    "",
    "    # Leer precios desde listas de precios USD (IDs: 9=Detal, 10=Combo, 11=Docena, 12=Bulto)",
    "    pl_items = env['product.pricelist.item'].search_read(",
    "        [('product_tmpl_id','=',tmpl_id),('pricelist_id','in',[9,10,11,12])],",
    "        ['pricelist_id','fixed_price']",
    "    )",
    "    pl_prices = {}",
    "    for pl in pl_items:",
    "        pl_prices[pl['pricelist_id'][0]] = to_float(pl['fixed_price'])",
    "",
    "    # Precio detal: pricelist 9 es correcto (no se divide, es precio unitario real)",
    "    detal_usd = pl_prices.get(9) or to_float(tmpl.x_web3_detal_usd) or to_float(tmpl.list_price)",
    "    ves_override = to_float(tmpl.x_web3_precio_ves) if tmpl.x_web3_precio_ves else 0",
    "    ves_str = str(ves_override) if ves_override > 0 else 'null'",
    "",
    "    # IMPORTANTE: Para combo/docena/bulto SIEMPRE usar x_web3_*_usd (precio TOTAL de la presentación)",
    "    # NO usar pl_prices.get(10/11/12) porque el PL ya tiene el precio dividido por pieza",
    "    # El JSON debe mostrar el precio total → el backend divide al crear líneas Odoo",
    "    combo_usd_pl  = to_float(tmpl.x_web3_combo_usd)",
    "    docena_usd_pl = to_float(tmpl.x_web3_docena_usd)",
    "    bulto_usd_pl  = to_float(tmpl.x_web3_bulto_usd)",
    "",
    "    # Presentaciones",
    "    pres_list = []",
    "",
    "    # DETAL siempre habilitado",
    "    pres_list.append('{\"tipo\":\"detal\",\"habilitado\":true,\"precio_usd\":' + str(detal_usd) + ',\"precio_ves_override\":' + ves_str + ',\"cliente_escoge\":true,\"piezas_requeridas\":1,\"pricelist_id\":9}')",
    "",
    "    # COMBO: habilitado si tiene precio en pricelist 10 o x_web3_combo_habilitado",
    "    combo_hab = tmpl.x_web3_combo_habilitado or (combo_usd_pl > 0)",
    "    if combo_hab and combo_usd_pl > 0:",
    "        combo_piezas = to_int(tmpl.x_web3_combo_piezas) if tmpl.x_web3_combo_piezas else 3",
    "        pres_list.append('{\"tipo\":\"combo\",\"habilitado\":true,\"precio_usd\":' + str(combo_usd_pl) + ',\"precio_ves_override\":' + ves_str + ',\"cliente_escoge\":' + to_bool(not tmpl.x_web3_combo_surtido) + ',\"piezas_requeridas\":' + str(combo_piezas) + ',\"pricelist_id\":10}')",
    "",
    "    # DOCENA: habilitado si tiene precio en pricelist 11 o x_web3_docena_habilitado",
    "    docena_hab = tmpl.x_web3_docena_habilitado or (docena_usd_pl > 0)",
    "    if docena_hab and docena_usd_pl > 0:",
    "        pres_list.append('{\"tipo\":\"docena\",\"habilitado\":true,\"precio_usd\":' + str(docena_usd_pl) + ',\"precio_ves_override\":' + ves_str + ',\"cliente_escoge\":' + to_bool(not tmpl.x_web3_docena_surtido) + ',\"piezas_requeridas\":12,\"pricelist_id\":11}')",
    "",
    "    # BULTO: habilitado si tiene precio en pricelist 12 o x_web3_bulto_habilitado",
    "    bulto_hab = tmpl.x_web3_bulto_habilitado or (bulto_usd_pl > 0)",
    "    if bulto_hab and bulto_usd_pl > 0:",
    "        bulto_piezas = to_int(tmpl.x_web3_bulto_piezas) if tmpl.x_web3_bulto_piezas else 24",
    "        pres_list.append('{\"tipo\":\"bulto\",\"habilitado\":true,\"precio_usd\":' + str(bulto_usd_pl) + ',\"precio_ves_override\":' + ves_str + ',\"cliente_escoge\":' + to_bool(not tmpl.x_web3_bulto_surtido) + ',\"piezas_requeridas\":' + str(bulto_piezas) + ',\"pricelist_id\":12}')",
    "",
    "    pres_json = '[' + ','.join(pres_list) + ']'",
    "",
    "    # Variantes",
    "    variantes_list = []",
    "    variantes = env['product.product'].search([",
    "        ('product_tmpl_id', '=', tmpl_id),",
    "        ('active', '=', True)",
    "    ])",
    "",
    "    for v in variantes:",
    "        v_id = v.id",
    "        v_stock = v.qty_available if 'qty_available' in v else 0.0",
    "        v_disp = 'in stock' if v_stock > 0 else 'out of stock'",
    "        v_img = base_url + '/web/image/product.product/' + str(v_id) + '/image_1024'",
    "        v_attrs = []",
    "        skip_attrs = ('presentacion', 'presentación', 'tipo de venta')",
    "        for attr_val in v.product_template_attribute_value_ids:",
    "            if attr_val.attribute_id.name.lower() in skip_attrs:",
    "                continue",
    "            v_attrs.append('{\"nombre\":\"' + clean(attr_val.attribute_id.name) + '\",\"valor\":\"' + clean(attr_val.name) + '\"}')",
    "        v_attrs_json = '[' + ','.join(v_attrs) + ']'",
    "        variantes_list.append('{\"id_variante\":' + str(v_id) + ',\"atributos\":' + v_attrs_json + ',\"imagen_url\":\"' + v_img + '\",\"stock_disponible\":' + str(v_stock) + ',\"disponibilidad\":\"' + v_disp + '\"}')",
    "",
    "    variantes_json = '[' + ','.join(variantes_list) + ']'",
    "",
    "    t_data = '{'",
    "    t_data += '\"id_template\":' + str(tmpl_id) + ','",
    "    t_data += '\"nombre_base\":\"' + nombre_base + '\",'",
    "    t_data += '\"categoria_principal\":\"' + cat_principal + '\",'",
    "    t_data += '\"categorias_web\":' + categs_json + ','",
    "    t_data += '\"descripcion\":\"' + descripcion + '\",'",
    "    t_data += '\"imagen_url\":\"' + img_tmpl + '\",'",
    "    t_data += '\"cost_usd\":' + str(cost_usd) + ','",
    "    t_data += '\"peso_kg\":' + peso + ','",
    "    t_data += '\"permitir_venta_sin_stock\":' + sin_stock + ','",
    "    t_data += '\"etiquetas\":' + tags_json + ','",
    "    t_data += '\"presentaciones\":' + pres_json + ','",
    "    t_data += '\"variantes\":' + variantes_json",
    "    t_data += '}'",
    "    catalogo.append(t_data)",
    "",
    "json_data = '[\\n' + ',\\n'.join(catalogo) + '\\n]'",
    "",
    "att_name = 'api_catalogo_listex_v3.json'",
    "att = env['ir.attachment'].search([('name', '=', att_name)], limit=1)",
    "if not att:",
    "    att = env['ir.attachment'].create({",
    "        'name': att_name,",
    "        'type': 'binary',",
    "        'public': True,",
    "        'mimetype': 'application/json',",
    "        'raw': json_data.encode('utf-8')",
    "    })",
    "else:",
    "    att.write({'raw': json_data.encode('utf-8')})",
    "",
    "public_url = base_url + '/web/content/' + str(att.id) + '/' + att_name",
    "",
    "action = {",
    "    'type': 'ir.actions.act_url',",
    "    'url': public_url,",
    "    'target': 'new',",
    "}",
].join('\n');

async function run() {
    // 1. Verificar DATA WEB 2 sigue intacto
    const dw2 = await call('ir.actions.server', 'read', [[3007]], { fields: ['id', 'name'] });
    console.log('✓ DATA WEB 2 intacto:', dw2[0].name, '(ID:', dw2[0].id + ')');

    // 2. Verificar/crear DATA WEB 3
    const existing = await call('ir.actions.server', 'search_read', [
        [['name', '=', 'DATA WEB 3']]
    ], { fields: ['id', 'name'] });

    let actionId;
    if (existing.length > 0) {
        actionId = existing[0].id;
        console.log('DATA WEB 3 ya existe (ID: ' + actionId + ') — actualizando código...');
        await call('ir.actions.server', 'write', [[actionId], { code: DATA_WEB3_CODE }]);
        console.log('✓ Código actualizado.');
    } else {
        const tmplModel = await call('ir.model', 'search_read', [[['model', '=', 'product.template']]], { fields: ['id'], limit: 1 });
        const modelId = tmplModel[0].id;
        actionId = await call('ir.actions.server', 'create', [{
            name: 'DATA WEB 3',
            model_id: modelId,
            state: 'code',
            code: DATA_WEB3_CODE,
        }]);
        console.log('✓ DATA WEB 3 creada con ID:', actionId);
    }

    // 3. Verificar que DATA WEB 2 sigue sin cambios
    const dw2check = await call('ir.actions.server', 'read', [[3007]], { fields: ['id', 'name', 'code'] });
    const codePreview = dw2check[0].code.substring(0, 60);
    console.log('\n✓ Verificación final DATA WEB 2 (primeros 60 chars de código):');
    console.log('  "' + codePreview + '"');
    console.log('\nResumen:');
    console.log('  DATA WEB 2 ID: 3007 — SIN CAMBIOS');
    console.log('  DATA WEB 3 ID:', actionId);
    console.log('  Archivo JSON generado: api_catalogo_listex_v3.json');
    console.log('\nPara ejecutarla en Odoo: Configuración → Acciones técnicas → Acciones de servidor → "DATA WEB 3" → Ejecutar acción');
}

run().catch(e => console.error('ERR FATAL:', e.message, e.faultString || ''));
