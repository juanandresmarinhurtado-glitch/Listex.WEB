const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        const tmplId = 1468; // An ID we created earlier
        const variants = await executeKw('product.product', 'search_read', [
            [['product_tmpl_id', '=', tmplId]],
            ['id', 'product_template_attribute_value_ids', 'qty_available', 'image_variant_1920']
        ]);
        console.log("Variants:", variants);
    } catch (e) {
        console.error("Error fetching variants:", e);
    }
});
