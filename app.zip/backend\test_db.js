require('dotenv').config({ path: 'backend/.env' });
const { Pool } = require('pg');

console.log("DATABASE_URL:", process.env.DATABASE_URL);

const isInternal = process.env.DATABASE_URL && !process.env.DATABASE_URL.includes('.render.com');
const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: isInternal ? false : { rejectUnauthorized: false },
    connectionTimeoutMillis: 5000
});

async function test() {
    try {
        console.log("Connecting to PostgreSQL...");
        const res = await pool.query("SELECT NOW()");
        console.log("Connection successful! DB Time:", res.rows[0]);
    } catch (err) {
        console.error("Connection failed! Error:", err.message);
    } finally {
        await pool.end();
    }
}

test();
