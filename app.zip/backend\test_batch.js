const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        const customAttributes = [{name: 'Talla', values: ['S', 'M']}];
        const requiredAttrNames = ['Presentación'];
        if (customAttributes) {
            for (let attr of customAttributes) {
                if (attr.name && attr.name.trim()) requiredAttrNames.push(attr.name.trim());
            }
        }
        
        const uniqueAttrNames = [...new Set(requiredAttrNames)];
        
        const existingAttrs = await executeKw('product.attribute', 'search_read', [
            [['name', 'in', uniqueAttrNames]],
            ['id', 'name']
        ]);
        
        const existingAttrMap = {};
        existingAttrs.forEach(a => existingAttrMap[a.name] = a.id);
        
        const attrsToCreate = uniqueAttrNames.filter(name => !existingAttrMap[name]);
        if (attrsToCreate.length > 0) {
            console.log("Attrs to create:", attrsToCreate);
            const createPayload = attrsToCreate.map(name => ({ name: name, create_variant: 'always' }));
            const newIds = await executeKw('product.attribute', 'create', [createPayload]);
            console.log("Created attrs:", newIds);
        } else {
            console.log("No attrs to create.");
        }
        console.log("Test finished.");
        
    } catch (e) {
        console.error("Test Error:", e);
    }
});
