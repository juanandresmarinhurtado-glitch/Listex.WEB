const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { pool } = require('../db/init');
const crypto = require('crypto');
const { ingestSupplierJson } = require('../services/jsonIngest');

const JWT_SECRET = process.env.JWT_SECRET || 'mi_clave_secreta_super_segura';

const authenticateSupplier = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: "No token provided" });
    const token = authHeader.split(' ')[1];
    try {
        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch (err) {
        return res.status(401).json({ error: "Invalid token" });
    }
};

function isUUID(id) {
    return typeof id === 'string' && id.includes('-');
}

// In-memory cache: stores pending products when PG is offline
const offlineSyncCache = {};

// ── Caché de productos por proveedor (respuesta lista para servir) ────────────
// Entrega instantánea en cargas repetidas y revalidación en background
const supplierProductsCache = {};   // { [supplierId]: { products, ts } }
const SUPPLIER_CACHE_TTL = 60000;   // 60s

function getCachedProducts(supplierId) {
    const c = supplierProductsCache[supplierId];
    if (!c) return null;
    return { products: c.products, fresh: (Date.now() - c.ts) < SUPPLIER_CACHE_TTL };
}
function setCachedProducts(supplierId, products) {
    supplierProductsCache[supplierId] = { products, ts: Date.now() };
}
function invalidateSupplierCache(supplierId) {
    delete supplierProductsCache[supplierId];
}

// Limpieza de huérfanos: throttle por proveedor (máx 1 cada 5 min, no bloqueante)
const lastOrphanCleanup = {};
function maybeCleanOrphans(supplierId) {
    const now = Date.now();
    if (lastOrphanCleanup[supplierId] && (now - lastOrphanCleanup[supplierId]) < 300000) return;
    lastOrphanCleanup[supplierId] = now;
    // Fire-and-forget: NO bloquea la respuesta
    pool.query(
        `DELETE FROM portal_products WHERE supplier_id=$1 AND sync_status='error' AND odoo_tmpl_id IS NULL`,
        [supplierId]
    ).then(r => { if (r.rowCount > 0) console.log(`[PRODUCTS] Limpiados ${r.rowCount} huérfanos proveedor ${supplierId}`); })
     .catch(() => {});
}

// Circuit breaker: skip PG for 30s after a failure to avoid blocking requests
let pgAvailable = true;
let pgCooldownTimer = null;
function markPgDown() {
    pgAvailable = false;
    if (pgCooldownTimer) clearTimeout(pgCooldownTimer);
    pgCooldownTimer = setTimeout(() => { pgAvailable = true; }, 30000);
}
function markPgUp() {
    pgAvailable = true;
    if (pgCooldownTimer) { clearTimeout(pgCooldownTimer); pgCooldownTimer = null; }
}

// Generate all variant combinations from custom attributes (cartesian product)
// e.g. [{name:"Color", values:["Rojo","Azul"]}, {name:"Talla", values:["S","M"]}]
// → ["Rojo / S", "Rojo / M", "Azul / S", "Azul / M"]
function generateVariantCombinations(customAttributes) {
    const filtered = (customAttributes || []).filter(a => a.name && a.values && a.values.length > 0);
    if (filtered.length === 0) return [{ attributes: 'Variante Base' }];
    let combos = [[]];
    for (const attr of filtered) {
        const next = [];
        for (const combo of combos) {
            for (const val of attr.values) {
                next.push([...combo, val]);
            }
        }
        combos = next;
    }
    return combos.map(c => ({ attributes: c.join(' / ') }));
}

// ─── GET /api/supplier/products ────────────────────────────────────────────
// Mapea fila de portal_products → objeto producto con precios/utilidades
function mapProductRow(p) {
    // Para productos cargados por enlace JSON, los precios vienen en catalog_json.presentaciones
    // Para productos del portal (Odoo-sync), vienen en columnas x_web3_*
    const cj = p.catalog_json || null;

    // Presentaciones indexadas por tipo (catalog_json)
    const pres = {};
    if (cj && Array.isArray(cj.presentaciones)) {
        for (const pr of cj.presentaciones) {
            if (pr.tipo) pres[pr.tipo.toLowerCase()] = pr;
        }
    }

    // Costo
    const cost = parseFloat(cj?.cost_usd || p.x_web3_cost_usd || p.cost) || 0;

    // Detal
    const detalPres = pres['detal'];
    const detal = parseFloat(detalPres?.precio_usd || p.x_web3_detal_usd || p.price_unidad) || 0;

    // Combo
    const comboPres   = pres['combo'];
    const comboHab    = !!(comboPres || p.x_web3_combo_habilitado);
    const comboTotal  = parseFloat(comboPres?.precio_usd || p.x_web3_combo_usd) || 0;
    const comboPiezas = parseInt(comboPres?.piezas || p.x_web3_combo_piezas) || 3;
    const comboSurtido = !!(comboPres?.surtido || p.x_web3_combo_surtido);

    // Docena
    const docenaPres  = pres['docena'];
    const docenaHab   = !!(docenaPres || p.x_web3_docena_habilitado);
    const docenaTotal = parseFloat(docenaPres?.precio_usd || p.x_web3_docena_usd) || 0;
    const docenaSurtido = !!(docenaPres?.surtido || p.x_web3_docena_surtido);

    // Bulto
    const bultoPres   = pres['bulto'];
    const bultoHab    = !!(bultoPres || p.x_web3_bulto_habilitado);
    const bultoTotal  = parseFloat(bultoPres?.precio_usd || p.x_web3_bulto_usd) || 0;
    const bultoPiezas = parseInt(bultoPres?.piezas || p.x_web3_bulto_piezas) || 13;
    const bultoSurtido = !!(bultoPres?.surtido || p.x_web3_bulto_surtido);

    // Precio por pieza
    const comboPpu  = comboPiezas  > 0 ? Math.round(comboTotal  / comboPiezas  * 100) / 100 : 0;
    const docenaPpu = Math.round(docenaTotal / 12 * 100) / 100;
    const bultoPpu  = bultoPiezas  > 0 ? Math.round(bultoTotal  / bultoPiezas  * 100) / 100 : 0;

    return {
        id:             p.odoo_tmpl_id || p.id,
        pg_id:          p.id,
        name:           cj?.nombre_base || p.name,
        imagen_url:     cj?.imagen_url  || p.imagen_url || '',
        source:         p.source || 'portal',
        categoria:      cj?.categoria_principal || p.categoria || '',
        list_price:     detal,
        standard_price: cost,
        qty_available:  0,
        is_published:   p.sync_status === 'synced',
        isPending:      p.sync_status === 'pending' || p.sync_status === 'processing',
        sync_status:    p.sync_status,
        cost_usd:       cost,
        detal_usd:      detal,
        detal_util:     Math.round((detal  - cost) * 100) / 100,
        combo_hab:      comboHab,
        combo_ppu:      comboPpu,
        combo_util:     Math.round((comboPpu  - cost) * 100) / 100,
        combo_surtido:  comboSurtido,
        docena_hab:     docenaHab,
        docena_ppu:     docenaPpu,
        docena_util:    Math.round((docenaPpu - cost) * 100) / 100,
        docena_surtido: docenaSurtido,
        bulto_hab:      bultoHab,
        bulto_ppu:      bultoPpu,
        bulto_util:     Math.round((bultoPpu  - cost) * 100) / 100,
        bulto_surtido:  bultoSurtido,
    };
}

// Consulta fresca a PG y refresca caché (usado en cache-miss y revalidación)
async function fetchSupplierProductsFromDB(supplierId) {
    const qRes = await pool.query(
        `SELECT id, name, price_unidad, cost, sync_status, odoo_tmpl_id, source,
                external_id, categoria, imagen_url, catalog_json,
                x_web3_cost_usd, x_web3_detal_usd,
                x_web3_combo_habilitado, x_web3_combo_usd, x_web3_combo_piezas, x_web3_combo_surtido,
                x_web3_docena_habilitado, x_web3_docena_usd, x_web3_docena_surtido,
                x_web3_bulto_habilitado, x_web3_bulto_usd, x_web3_bulto_piezas, x_web3_bulto_surtido
         FROM portal_products
         WHERE supplier_id = $1
         AND (
           odoo_tmpl_id IS NOT NULL
           OR sync_status IN ('pending','processing')
           OR source = 'json_link'
         )
         ORDER BY created_at DESC NULLS LAST`,
        [supplierId]
    );
    const products = qRes.rows.map(mapProductRow);
    setCachedProducts(supplierId, products);
    return products;
}

router.get('/', authenticateSupplier, async (req, res) => {
    const supplierId = req.user.id;

    // ── 1. CACHÉ: si hay datos en memoria, responder AL INSTANTE ──────────────
    const cached = getCachedProducts(supplierId);
    if (cached) {
        res.json({ success: true, products: cached.products, cached: true });
        // Si la caché está vieja, revalidar en background (stale-while-revalidate)
        if (!cached.fresh && pgAvailable) {
            fetchSupplierProductsFromDB(supplierId)
                .then(() => markPgUp())
                .catch(() => markPgDown());
        }
        maybeCleanOrphans(supplierId);
        return;
    }

    // ── 2. CACHE MISS: consultar PG (o fallback Odoo) ─────────────────────────
    if (!pgAvailable) return serveProductsFallback(supplierId, res);
    try {
        const products = await fetchSupplierProductsFromDB(supplierId);
        markPgUp();
        maybeCleanOrphans(supplierId);   // no bloqueante
        return res.json({ success: true, products });
    } catch (dbError) {
        console.warn("[PRODUCTS] PG offline, falling back.", dbError.message);
        markPgDown();
        return serveProductsFallback(supplierId, res);
    }
});

// ─── Enlace JSON (DEBE ir antes de las rutas /:id para no ser capturado) ──────
router.get('/json-source', authenticateSupplier, async (req, res) => {
    try {
        const r = await pool.query(
            `SELECT source_type, json_url, auto_refresh_min, last_ingested, last_status, last_error, product_count
             FROM supplier_sources WHERE supplier_id=$1`, [req.user.id]);
        res.json({ success: true, source: r.rows[0] || { source_type: 'manual', json_url: null } });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

router.post('/json-source', authenticateSupplier, async (req, res) => {
    const supplierId = req.user.id;
    const { json_url, auto_refresh_min } = req.body;
    if (!json_url || !/^https?:\/\//.test(json_url)) {
        return res.status(400).json({ success: false, error: 'Enlace JSON inválido (debe empezar con http)' });
    }
    invalidateSupplierCache(supplierId);
    try {
        await pool.query(
            `INSERT INTO supplier_sources (supplier_id, source_type, json_url, auto_refresh_min)
             VALUES ($1,'json_link',$2,$3)
             ON CONFLICT (supplier_id) DO UPDATE SET source_type='json_link', json_url=EXCLUDED.json_url, auto_refresh_min=EXCLUDED.auto_refresh_min`,
            [supplierId, json_url, parseInt(auto_refresh_min) || 0]
        );
        const result = await ingestSupplierJson(supplierId, json_url);
        try { require('./public').invalidateV3Cache?.(); } catch(e) {}
        res.json({ success: true, message: `${result.count} productos cargados desde el enlace`, count: result.count });
    } catch (e) {
        console.error('[JSON-SOURCE]', e.message);
        res.status(500).json({ success: false, error: 'No se pudo procesar el enlace: ' + e.message });
    }
});

router.post('/json-refresh', authenticateSupplier, async (req, res) => {
    const supplierId = req.user.id;
    invalidateSupplierCache(supplierId);
    try {
        const r = await pool.query(`SELECT json_url FROM supplier_sources WHERE supplier_id=$1`, [supplierId]);
        const url = r.rows[0]?.json_url;
        if (!url) return res.status(400).json({ success: false, error: 'No tienes un enlace JSON configurado' });
        const result = await ingestSupplierJson(supplierId, url);
        try { require('./public').invalidateV3Cache?.(); } catch(e) {}
        res.json({ success: true, message: `${result.count} productos actualizados`, count: result.count });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

async function serveProductsFallback(supplierId, res) {
    // Si hay caché (aunque vieja), servir al instante mientras Odoo responde
    const cached = getCachedProducts(supplierId);
    if (cached) {
        res.json({ success: true, products: cached.products, cached: true });
        // Revalidar en background sin bloquear
        refreshFallbackInBackground(supplierId);
        return;
    }
    try {
        const { executeKw } = require('../services/odooApi');
        const supplierInfos = await executeKw('product.supplierinfo', 'search_read', [
            [['partner_id', '=', supplierId]]
        ], { fields: ['product_tmpl_id'] });

        let products = [];
        if (supplierInfos && supplierInfos.length > 0) {
            const tmplIds = [...new Set(supplierInfos.map(s => s.product_tmpl_id[0]))];
            const templates = await executeKw('product.template', 'read', [
                tmplIds, ['id','name','list_price','standard_price','qty_available','is_published',
                    'x_web3_cost_usd','x_web3_detal_usd',
                    'x_web3_combo_habilitado','x_web3_combo_usd','x_web3_combo_piezas','x_web3_combo_surtido',
                    'x_web3_docena_habilitado','x_web3_docena_usd','x_web3_docena_surtido',
                    'x_web3_bulto_habilitado','x_web3_bulto_usd','x_web3_bulto_piezas','x_web3_bulto_surtido']
            ]);
            products = templates.map(t => {
                const cost  = t.x_web3_cost_usd  || t.standard_price || 0;
                const detal = t.x_web3_detal_usd || t.list_price     || 0;
                const comboTotal  = t.x_web3_combo_usd  || 0;
                const docenaTotal = t.x_web3_docena_usd || 0;
                const bultoTotal  = t.x_web3_bulto_usd  || 0;
                const comboPiezas = t.x_web3_combo_piezas  || 3;
                const bultoPiezas = t.x_web3_bulto_piezas  || 13;
                const comboPpu    = comboPiezas > 0 ? Math.round(comboTotal  / comboPiezas  * 100) / 100 : 0;
                const docenaPpu   = Math.round(docenaTotal / 12 * 100) / 100;
                const bultoPpu    = bultoPiezas > 0 ? Math.round(bultoTotal  / bultoPiezas  * 100) / 100 : 0;
                return {
                    id: t.id, name: t.name,
                    list_price: detal, standard_price: cost,
                    qty_available: t.qty_available || 0, is_published: t.is_published,
                    isPending: false, sync_status: 'synced',
                    cost_usd: cost, detal_usd: detal, detal_util: Math.round((detal-cost)*100)/100,
                    combo_hab: t.x_web3_combo_habilitado||false, combo_ppu: comboPpu, combo_util: Math.round((comboPpu-cost)*100)/100, combo_surtido: t.x_web3_combo_surtido||false,
                    docena_hab: t.x_web3_docena_habilitado||false, docena_ppu: docenaPpu, docena_util: Math.round((docenaPpu-cost)*100)/100, docena_surtido: t.x_web3_docena_surtido||false,
                    bulto_hab: t.x_web3_bulto_habilitado||false, bulto_ppu: bultoPpu, bulto_util: Math.round((bultoPpu-cost)*100)/100, bulto_surtido: t.x_web3_bulto_surtido||false,
                };
            });
        }

        Object.keys(offlineSyncCache).forEach(tempId => {
            const item = offlineSyncCache[tempId];
            if (item.supplierId === supplierId && item.status !== 'synced') {
                products.unshift({
                    id: tempId,
                    name: item.name + (item.status === 'error' ? ' ⚠ Error' : ' ⏳ Sincronizando...'),
                    list_price: item.priceUnidad, standard_price: item.cost,
                    qty_available: 0, is_published: false,
                    isPending: true, sync_status: item.status
                });
            }
        });

        setCachedProducts(supplierId, products);   // cachear para próximas cargas instantáneas
        return res.json({ success: true, products });
    } catch (odooError) {
        return res.status(500).json({ error: odooError.message });
    }
}

// Revalida la caché del fallback (Odoo) en segundo plano, sin respuesta HTTP
async function refreshFallbackInBackground(supplierId) {
    try {
        const { executeKw } = require('../services/odooApi');
        const supplierInfos = await executeKw('product.supplierinfo', 'search_read',
            [[['partner_id', '=', supplierId]]], { fields: ['product_tmpl_id'] });
        if (!supplierInfos || supplierInfos.length === 0) return;
        const tmplIds = [...new Set(supplierInfos.map(s => s.product_tmpl_id[0]))];
        const templates = await executeKw('product.template', 'read', [tmplIds,
            ['id','name','list_price','standard_price','qty_available','is_published',
             'x_web3_cost_usd','x_web3_detal_usd',
             'x_web3_combo_habilitado','x_web3_combo_usd','x_web3_combo_piezas','x_web3_combo_surtido',
             'x_web3_docena_habilitado','x_web3_docena_usd','x_web3_docena_surtido',
             'x_web3_bulto_habilitado','x_web3_bulto_usd','x_web3_bulto_piezas','x_web3_bulto_surtido']]);
        const products = templates.map(t => {
            const cost  = t.x_web3_cost_usd  || t.standard_price || 0;
            const detal = t.x_web3_detal_usd || t.list_price     || 0;
            const comboPiezas = t.x_web3_combo_piezas || 3;
            const bultoPiezas = t.x_web3_bulto_piezas || 13;
            const comboPpu  = comboPiezas > 0 ? Math.round((t.x_web3_combo_usd||0)/comboPiezas*100)/100 : 0;
            const docenaPpu = Math.round((t.x_web3_docena_usd||0)/12*100)/100;
            const bultoPpu  = bultoPiezas > 0 ? Math.round((t.x_web3_bulto_usd||0)/bultoPiezas*100)/100 : 0;
            return {
                id: t.id, name: t.name, list_price: detal, standard_price: cost,
                qty_available: t.qty_available||0, is_published: t.is_published, isPending: false, sync_status: 'synced',
                cost_usd: cost, detal_usd: detal, detal_util: Math.round((detal-cost)*100)/100,
                combo_hab: t.x_web3_combo_habilitado||false, combo_ppu: comboPpu, combo_util: Math.round((comboPpu-cost)*100)/100, combo_surtido: t.x_web3_combo_surtido||false,
                docena_hab: t.x_web3_docena_habilitado||false, docena_ppu: docenaPpu, docena_util: Math.round((docenaPpu-cost)*100)/100, docena_surtido: t.x_web3_docena_surtido||false,
                bulto_hab: t.x_web3_bulto_habilitado||false, bulto_ppu: bultoPpu, bulto_util: Math.round((bultoPpu-cost)*100)/100, bulto_surtido: t.x_web3_bulto_surtido||false,
            };
        });
        setCachedProducts(supplierId, products);
    } catch(e) { /* silencioso */ }
}

// ─── Helper: Odoo background sync (fallback when PG offline) ───────────────
async function createProductInOdooBackground(supplierId, data, tempId) {
    offlineSyncCache[tempId] = {
        ...offlineSyncCache[tempId],
        status: 'processing'
    };

    try {
        console.log(`[BACKGROUND SYNC] Starting for "${data.name}"...`);
        const { executeKw } = require('../services/odooApi');
        const priceUnidad = parseFloat(data.priceUnidad) || 0;
        const priceDocena = parseFloat(data.priceDocena) || 0;
        const priceBulto  = parseFloat(data.priceBulto)  || 0;
        const cost        = parseFloat(data.cost)        || 0;
        const customAttributes = data.customAttributes || [];

        const { ensureTipoVentaAttr, setVariantPricelists } = require('../services/odooSyncHelpers');
        const web3 = extractWeb3Fields(data);
        const hasSurtido = (web3.x_web3_combo_habilitado && web3.x_web3_combo_surtido)
                        || (web3.x_web3_docena_habilitado && web3.x_web3_docena_surtido)
                        || (web3.x_web3_bulto_habilitado  && web3.x_web3_bulto_surtido);

        const existingAttrMap = {};
        const existingValMap  = {};
        const odooAttrs = await executeKw('product.attribute', 'search_read', [[]], { fields: ['id', 'name', 'create_variant'] });
        odooAttrs.forEach(a => existingAttrMap[a.name] = a.id);
        const odooVals = await executeKw('product.attribute.value', 'search_read', [[]], { fields: ['id', 'name', 'attribute_id'] });
        odooVals.forEach(v => { if (v.attribute_id) existingValMap[`${v.attribute_id[0]}_${v.name}`] = v.id; });

        const ptalPayload = [];

        // ── 1. Tipo de Venta (no_variant): Unidad SIEMPRE + valores surtido opcionales
        const { tvAttrId, allTvValIds } = await ensureTipoVentaAttr(web3, existingAttrMap, existingValMap, executeKw);
        ptalPayload.push([0, 0, { attribute_id: tvAttrId, value_ids: [[6, 0, allTvValIds]] }]);

        // ── 2. Atributos custom + valor "Surtido" si hay presentación surtida
        for (const customAttr of customAttributes) {
            if (!customAttr.name || !customAttr.values || customAttr.values.length === 0) continue;
            if (!existingAttrMap[customAttr.name]) {
                existingAttrMap[customAttr.name] = await executeKw('product.attribute', 'create',
                    [{ name: customAttr.name, create_variant: 'always' }]);
            }
            const attrId = existingAttrMap[customAttr.name];
            const values = [...customAttr.values];
            // Agregar "Surtido" para crear variante universal cuando hay presentación surtida
            if (hasSurtido && !values.map(v => v.toLowerCase()).includes('surtido')) values.push('Surtido');
            const valIds = [];
            for (const valName of values) {
                const key = `${attrId}_${valName}`;
                if (!existingValMap[key]) existingValMap[key] = await executeKw('product.attribute.value', 'create',
                    [{ name: valName, attribute_id: attrId }]);
                valIds.push(existingValMap[key]);
            }
            ptalPayload.push([0, 0, { attribute_id: attrId, value_ids: [[6, 0, valIds]] }]);
        }

        const detalUsd = parseFloat(web3.x_web3_detal_usd || priceUnidad) || priceUnidad;
        const productData = {
            name: data.name, list_price: detalUsd, standard_price: cost,
            sale_ok: true, purchase_ok: true, is_published: true, is_storable: true,
            seller_ids: [[0, 0, { partner_id: supplierId, delay: 1 }]],
            attribute_line_ids: ptalPayload,
            x_web3_detal_usd:         detalUsd,
            x_web3_cost_usd:          cost,
            x_web3_combo_habilitado:  web3.x_web3_combo_habilitado,
            x_web3_combo_usd:         parseFloat(web3.x_web3_combo_usd) || 0,
            x_web3_combo_piezas:      web3.x_web3_combo_piezas || 3,
            x_web3_combo_surtido:     web3.x_web3_combo_surtido,
            x_web3_docena_habilitado: web3.x_web3_docena_habilitado,
            x_web3_docena_usd:        parseFloat(web3.x_web3_docena_usd) || 0,
            x_web3_docena_surtido:    web3.x_web3_docena_surtido,
            x_web3_bulto_habilitado:  web3.x_web3_bulto_habilitado,
            x_web3_bulto_usd:         parseFloat(web3.x_web3_bulto_usd) || 0,
            x_web3_bulto_piezas:      web3.x_web3_bulto_piezas || 24,
            x_web3_bulto_surtido:     web3.x_web3_bulto_surtido,
            x_web3_precio_ves:        parseFloat(web3.x_web3_precio_ves) || 0,
        };
        if (data.categoryId) productData.public_categ_ids = [[6, 0, [parseInt(data.categoryId)]]];

        const tmplId = await executeKw('product.template', 'create', [productData]);

        if (data.imageBase64) {
            const rawB64 = data.imageBase64.split(',')[1] || data.imageBase64;
            await executeKw('product.template', 'write', [[tmplId], { image_1920: rawB64 }]);
        }

        // ── 3. PL a nivel VARIANTE con precios divididos (sin fallback template)
        // IMPORTANTE: No crear PL a nivel template para evitar que el precio detal
        // se aplique a variantes surtido (causaría que docena/bulto surtido se facture al precio detal)
        await setVariantPricelists(tmplId, { ...web3, cost, price_unidad: priceUnidad }, executeKw);

        // ── Stock inicial de variantes ──
        if (offlineSyncCache[tempId] && offlineSyncCache[tempId].variants && offlineSyncCache[tempId].variants.length > 0) {
            await syncVariantAssetsToOdoo(tmplId, offlineSyncCache[tempId].variants, null, executeKw, customAttributes);
        }

        offlineSyncCache[tempId].status = 'synced';
        offlineSyncCache[tempId].odooId = tmplId;
        console.log(`[BACKGROUND SYNC] ✓ "${data.name}" → Odoo tmplId=${tmplId}`);

        // ── Ejecutar DATA WEB 3 automáticamente ──
        try {
            await executeKw('ir.actions.server', 'run', [[3047]]);
            console.log('[BACKGROUND SYNC] ✓ DATA WEB 3 ejecutado');
        } catch(e) { console.warn('[BACKGROUND SYNC] DATA WEB 3 falló:', e.message); }

        try {
            await pool.query(
                `INSERT INTO portal_products (id, supplier_id, name, category_id, price_unidad, price_docena, price_bulto, cost, sync_status, odoo_tmpl_id, created_at)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'synced',$9,$10)
                 ON CONFLICT (id) DO UPDATE SET sync_status='synced', odoo_tmpl_id=EXCLUDED.odoo_tmpl_id`,
                [tempId, supplierId, data.name, data.categoryId ? parseInt(data.categoryId) : null,
                 priceUnidad, priceDocena || null, priceBulto || null, cost, tmplId, Date.now()]
            );
        } catch(dbErr) {}

    } catch (err) {
        console.error(`[BACKGROUND SYNC] ✗ "${data.name}":`, err.message);
        if (offlineSyncCache[tempId]) {
            offlineSyncCache[tempId].status = 'error';
            offlineSyncCache[tempId].error = err.message;
        }
    }
}

// Apply variant photos and stock to Odoo
// customAttributes: [{name, values}] — used to sort PTAVs in correct order
async function syncVariantAssetsToOdoo(tmplId, localVariants, presAttrId, executeKw, customAttributes = []) {
    try {
        const odooVariants = await executeKw('product.product', 'search_read',
            [[['product_tmpl_id', '=', tmplId]]],
            { fields: ['id', 'product_template_attribute_value_ids'] }
        );
        const allPtavIds = new Set();
        odooVariants.forEach(v => (v.product_template_attribute_value_ids || []).forEach(id => allPtavIds.add(id)));
        if (allPtavIds.size === 0) return;

        const ptavs = await executeKw('product.template.attribute.value', 'search_read',
            [[['id', 'in', [...allPtavIds]]]], { fields: ['id', 'name', 'attribute_id'] }
        );
        const ptavNameMap = {}, ptavAttrMap = {};
        ptavs.forEach(pt => { ptavNameMap[pt.id] = pt.name; ptavAttrMap[pt.id] = pt.attribute_id[0]; });

        // Build attribute order map from customAttributes definition
        const attrOrder = { [presAttrId]: -1 };
        customAttributes.forEach((ca, idx) => {
            const matchingPtav = ptavs.find(pt => ptavAttrMap[pt.id] !== presAttrId &&
                localVariants.some(lv => (lv.attribute_names || lv.attributes || '').includes(ca.values[0])));
            // Simpler: build order by finding attr IDs from the ptavs that match custom attr values
            const attrIds = [...new Set(
                ptavs.filter(pt => ca.values.includes(pt.name)).map(pt => pt.attribute_id[0])
            )];
            attrIds.forEach(id => { attrOrder[id] = idx; });
        });

        let stockLocId = null;
        try {
            let locs = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'WH/']]], { fields: ['id'], limit: 1 });
            if (locs.length === 0) locs = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal']]], { fields: ['id'], limit: 1 });
            if (locs.length > 0) stockLocId = locs[0].id;
        } catch(e) {}

        const matchedLocalVarIds = new Set();
        for (const ov of odooVariants) {
            const customParts = (ov.product_template_attribute_value_ids || [])
                .filter(ptavId => ptavAttrMap[ptavId] !== presAttrId)
                .sort((a, b) => (attrOrder[ptavAttrMap[a]] ?? 99) - (attrOrder[ptavAttrMap[b]] ?? 99))
                .map(ptavId => ptavNameMap[ptavId] || '')
                .filter(Boolean);
            const customName = customParts.length > 0 ? customParts.join(' / ') : 'Variante Base';

            const localVar = localVariants.find(lv =>
                !matchedLocalVarIds.has(lv.id || lv.attribute_names) &&
                (lv.attribute_names || lv.attributes) === customName
            );
            if (!localVar) continue;
            matchedLocalVarIds.add(localVar.id || localVar.attribute_names);

            const imgB64 = localVar.image_variant_1920 || localVar.image_base64;
            if (imgB64) {
                try {
                    const raw = imgB64.split(',')[1] || imgB64;
                    await executeKw('product.product', 'write', [[ov.id], { image_1920: raw }]);
                    console.log(`[ASSETS] ✓ Photo uploaded for variant "${customName}"`);
                } catch(e) {
                    console.error(`[ASSETS] ✗ Photo failed for "${customName}":`, e.message);
                }
            }

            const qty = parseInt(localVar.qty_available || localVar.qty) || 0;
            if (qty > 0 && stockLocId) {
                try {
                    const existingQuants = await executeKw('stock.quant', 'search_read', [
                        [['product_id', '=', ov.id], ['location_id', '=', stockLocId]]
                    ], { fields: ['id'] });
                    let quantId;
                    if (existingQuants.length > 0) {
                        quantId = existingQuants[0].id;
                        await executeKw('stock.quant', 'write', [[quantId], { inventory_quantity: qty }]);
                    } else {
                        quantId = await executeKw('stock.quant', 'create', [{ product_id: ov.id, location_id: stockLocId, inventory_quantity: qty }]);
                    }
                    await executeKw('stock.quant', 'action_apply_inventory', [[quantId]]);
                    console.log(`[ASSETS] ✓ Stock set for variant "${customName}": qty=${qty}`);
                } catch(e) {
                    console.error(`[ASSETS] ✗ Stock failed for "${customName}":`, e.message);
                }
            }
        }
    } catch(e) {
        console.error('[SYNC ASSETS] Fatal error:', e.message);
    }
}

// Helper: extrae campos web3 del body del request
function extractWeb3Fields(data) {
    const p = data.presentaciones || {};
    const detal   = p.detal   || {};
    const combo   = p.combo   || {};
    const docena  = p.docena  || {};
    const bulto   = p.bulto   || {};
    return {
        x_web3_detal_usd:        parseFloat(detal.precio_usd  || data.priceUnidad || 0) || null,
        x_web3_combo_habilitado: combo.habilitado  === true,
        x_web3_combo_usd:        parseFloat(combo.precio_usd  || 0) || null,
        x_web3_combo_piezas:     parseInt(combo.piezas || 3),
        x_web3_combo_surtido:    combo.surtido  === true,
        x_web3_docena_habilitado:docena.habilitado === true,
        x_web3_docena_usd:       parseFloat(docena.precio_usd || data.priceDocena || 0) || null,
        x_web3_docena_surtido:   docena.surtido === true,
        x_web3_bulto_habilitado: bulto.habilitado  === true,
        x_web3_bulto_usd:        parseFloat(bulto.precio_usd  || data.priceBulto  || 0) || null,
        x_web3_bulto_piezas:     parseInt(bulto.piezas || 24),
        x_web3_bulto_surtido:    bulto.surtido  === true,
        x_web3_precio_ves:       parseFloat(detal.precio_ves_override || 0) || null,
    };
}

// ─── POST /api/supplier/products — Create product (responds in <10ms) ──────
router.post('/', authenticateSupplier, async (req, res) => {
    const supplierId = req.user.id;
    invalidateSupplierCache(supplierId);
    const data       = req.body;
    const priceUnidad = parseFloat((data.presentaciones?.detal?.precio_usd) || data.priceUnidad) || 0;
    const priceDocena = parseFloat((data.presentaciones?.docena?.precio_usd) || data.priceDocena) || 0;
    const priceBulto  = parseFloat((data.presentaciones?.bulto?.precio_usd)  || data.priceBulto)  || 0;
    const cost        = parseFloat(data.cost)        || 0;
    const tempId = crypto.randomUUID();
    const customAttributes = data.customAttributes || [];
    const isStorable = data.isStorable === true || data.isStorable === 'true';
    const web3 = extractWeb3Fields(data);

    // Generate variant combinations immediately (no DB needed)
    const variantCombos = generateVariantCombinations(customAttributes);
    const variantsForCache = variantCombos.map(() => ({
        id: crypto.randomUUID(),
        attribute_names: null,
        qty_available: 0,
        image_variant_1920: null
    }));
    variantCombos.forEach((c, i) => { variantsForCache[i].attribute_names = c.attributes; });

    // Register in memory so GET /products/:id works immediately after creation
    offlineSyncCache[tempId] = {
        supplierId, name: data.name, priceUnidad, priceDocena, priceBulto, cost,
        categoryId: data.categoryId || null,
        imageBase64: data.imageBase64 || null,
        isStorable,
        customAttributes,
        variants: variantsForCache,
        status: 'pending'
    };

    // Respond IMMEDIATELY — client gets success in <10ms
    res.json({
        success: true,
        message: "Producto registrado. Sincronizando en segundo plano...",
        id: tempId,
        isPending: true,
        variants: variantsForCache
    });

    // Background: persist to PostgreSQL (doesn't block the response)
    setImmediate(async () => {
        if (!pgAvailable) {
            createProductInOdooBackground(supplierId, data, tempId);
            return;
        }
        try {
            await pool.query(
                `INSERT INTO portal_products (id, supplier_id, name, category_id, price_unidad, price_docena, price_bulto, cost, image_base64, custom_attributes, is_storable,
                  x_web3_detal_usd, x_web3_combo_habilitado, x_web3_combo_usd, x_web3_combo_piezas, x_web3_combo_surtido,
                  x_web3_docena_habilitado, x_web3_docena_usd, x_web3_docena_surtido,
                  x_web3_bulto_habilitado, x_web3_bulto_usd, x_web3_bulto_piezas, x_web3_bulto_surtido, x_web3_precio_ves,
                  sync_status, created_at)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,'pending',$25)`,
                [tempId, supplierId, data.name, data.categoryId ? parseInt(data.categoryId) : null,
                 priceUnidad, priceDocena || null, priceBulto || null, cost,
                 data.imageBase64 || null,
                 customAttributes.length > 0 ? JSON.stringify(customAttributes) : null,
                 isStorable,
                 web3.x_web3_detal_usd, web3.x_web3_combo_habilitado, web3.x_web3_combo_usd, web3.x_web3_combo_piezas, web3.x_web3_combo_surtido,
                 web3.x_web3_docena_habilitado, web3.x_web3_docena_usd, web3.x_web3_docena_surtido,
                 web3.x_web3_bulto_habilitado, web3.x_web3_bulto_usd, web3.x_web3_bulto_piezas, web3.x_web3_bulto_surtido, web3.x_web3_precio_ves,
                 Date.now()]
            );
            for (const v of variantsForCache) {
                await pool.query(
                    `INSERT INTO portal_variants (id, product_id, attributes, qty, image_base64) VALUES ($1,$2,$3,$4,$5)`,
                    [v.id, tempId, v.attribute_names, 0, null]
                );
            }
            markPgUp();
            console.log(`[PRODUCTS] PG write OK: ${tempId} (${variantsForCache.length} variant(s))`);
        } catch (dbError) {
            console.warn("[PRODUCTS] PG write failed, falling back to direct Odoo sync.", dbError.message);
            markPgDown();
            createProductInOdooBackground(supplierId, data, tempId);
        }
    });
});

// Construye el objeto presentaciones desde una fila de portal_products
function buildPresentacionesFromRow(p) {
    return {
        detal: {
            precio_usd: parseFloat(p.x_web3_detal_usd || p.price_unidad) || 0,
            precio_ves_override: parseFloat(p.x_web3_precio_ves) || null,
        },
        combo: {
            habilitado: p.x_web3_combo_habilitado || false,
            precio_usd: parseFloat(p.x_web3_combo_usd) || 0,
            piezas: parseInt(p.x_web3_combo_piezas) || 3,
            surtido: p.x_web3_combo_surtido || false,
        },
        docena: {
            habilitado: p.x_web3_docena_habilitado || false,
            precio_usd: parseFloat(p.x_web3_docena_usd || p.price_docena) || 0,
            surtido: p.x_web3_docena_surtido || false,
        },
        bulto: {
            habilitado: p.x_web3_bulto_habilitado || false,
            precio_usd: parseFloat(p.x_web3_bulto_usd || p.price_bulto) || 0,
            piezas: parseInt(p.x_web3_bulto_piezas) || 24,
            surtido: p.x_web3_bulto_surtido || false,
        },
    };
}

// ─── GET /api/supplier/products/:id/variants ───────────────────────────────
// This is the PRIMARY endpoint for openEditModal — returns ALL product fields + variants
router.get('/:id/variants', authenticateSupplier, async (req, res) => {
    const id = req.params.id;

    // ── UUID (pending / recently created) ───────────────────────────────────
    if (isUUID(id)) {
        if (pgAvailable) {
            try {
                const pRes = await pool.query("SELECT * FROM portal_products WHERE id=$1", [id]);
                if (pRes.rows.length > 0) {
                    const p = pRes.rows[0];
                    const vRes = await pool.query("SELECT * FROM portal_variants WHERE product_id=$1 ORDER BY id", [id]);
                    markPgUp();
                    return res.json({
                        success: true,
                        product: {
                            id: p.id, name: p.name,
                            isPending: p.sync_status !== 'synced',
                            cost: parseFloat(p.cost) || 0,
                            priceUnidad: parseFloat(p.price_unidad) || 0,
                            priceDocena: parseFloat(p.price_docena) || "",
                            priceBulto: parseFloat(p.price_bulto) || "",
                            categoryId: p.category_id,
                            imageBase64: p.image_base64 || null,
                            isStorable: p.is_storable || false,
                            presentaciones: buildPresentacionesFromRow(p),
                            variants: vRes.rows.map(v => ({
                                id: v.odoo_prod_id || v.id,
                                attribute_names: v.attributes,
                                qty_available: v.qty || 0,
                                image_variant_1920: v.image_base64 || null
                            }))
                        }
                    });
                }
            } catch(e) { markPgDown(); }
        }
        // Memory fallback
        const item = offlineSyncCache[id];
        if (item) {
            return res.json({
                success: true,
                product: {
                    id, name: item.name, isPending: true,
                    cost: item.cost, priceUnidad: item.priceUnidad,
                    priceDocena: item.priceDocena || "", priceBulto: item.priceBulto || "",
                    categoryId: item.categoryId || null, imageBase64: item.imageBase64 || null,
                    isStorable: item.isStorable || false,
                    variants: item.variants || []
                }
            });
        }
        return res.status(404).json({ error: "Product not found" });
    }

    // ── Numeric Odoo ID (synced product) ────────────────────────────────────
    const tmplId = parseInt(id);

    // STEP 1: Try portal_products first — has exact saved values (cost, isStorable, prices)
    let pgProductData = null;
    let pgVariants = [];
    if (pgAvailable) {
        try {
            const pRes = await pool.query("SELECT * FROM portal_products WHERE odoo_tmpl_id=$1", [tmplId]);
            if (pRes.rows.length > 0) {
                const p = pRes.rows[0];
                const vRes = await pool.query("SELECT * FROM portal_variants WHERE product_id=$1 ORDER BY id", [p.id]);
                markPgUp();
                pgProductData = p;
                pgVariants = vRes.rows;

                // If portal_variants has data, return immediately (fastest path)
                if (pgVariants.length > 0) {
                    return res.json({
                        success: true,
                        product: {
                            id: tmplId, name: p.name, isPending: false,
                            cost: parseFloat(p.cost) || 0,
                            priceUnidad: parseFloat(p.price_unidad) || 0,
                            priceDocena: parseFloat(p.price_docena) || "",
                            priceBulto: parseFloat(p.price_bulto) || "",
                            categoryId: p.category_id,
                            imageBase64: p.image_base64 || null,
                            isStorable: p.is_storable || false,
                            variants: pgVariants.map(v => ({
                                id: v.odoo_prod_id || v.id,
                                attribute_names: v.attributes,
                                qty_available: v.qty || 0,
                                image_variant_1920: v.image_base64 || null
                            }))
                        }
                    });
                }
                // Product found in DB but no variants → fall through to Odoo for variants only
            }
        } catch(e) { markPgDown(); }
    }

    // STEP 2: Fetch variants from Odoo (either PG had no variants, or PG is offline)
    try {
        const { executeKw } = require('../services/odooApi');
        const [templates, odooVariants] = await Promise.all([
            executeKw('product.template', 'read',
                [[tmplId], ['id', 'name', 'list_price', 'standard_price', 'image_1920', 'public_categ_ids',
                  'is_storable', 'x_web3_detal_usd', 'x_web3_combo_habilitado', 'x_web3_combo_usd',
                  'x_web3_combo_piezas', 'x_web3_combo_surtido', 'x_web3_docena_habilitado',
                  'x_web3_docena_usd', 'x_web3_docena_surtido', 'x_web3_bulto_habilitado',
                  'x_web3_bulto_usd', 'x_web3_bulto_piezas', 'x_web3_bulto_surtido',
                  'x_web3_cost_usd', 'x_web3_precio_ves'
                ]]),
            executeKw('product.product', 'search_read',
                [[['product_tmpl_id', '=', tmplId], ['active', '=', true]]],
                { fields: ['id', 'product_template_attribute_value_ids', 'qty_available', 'image_1920', 'standard_price'] })
        ]);
        if (!templates || templates.length === 0) return res.status(404).json({ error: "Producto no encontrado en Odoo" });
        const tmpl = templates[0];

        const allPtavIds = new Set();
        odooVariants.forEach(v => (v.product_template_attribute_value_ids || []).forEach(ptavId => allPtavIds.add(ptavId)));

        let ptavNameMap = {}, ptavAttrMap = {}, presAttrId = null;
        if (allPtavIds.size > 0) {
            const ptavs = await executeKw('product.template.attribute.value', 'search_read',
                [[['id', 'in', [...allPtavIds]]]], { fields: ['id', 'name', 'attribute_id'] }
            );
            ptavs.forEach(pt => { ptavNameMap[pt.id] = pt.name; ptavAttrMap[pt.id] = pt.attribute_id[0]; });
            const presNames = new Set(['unidad variada', 'docena cerrada', 'bulto']);
            for (const pt of ptavs) {
                if (presNames.has(pt.name)) { presAttrId = pt.attribute_id[0]; break; }
            }
        }

        // Deduplicate by custom-attribute combination (exclude Presentación)
        const seen = new Map();
        for (const ov of odooVariants) {
            const customParts = (ov.product_template_attribute_value_ids || [])
                .filter(ptavId => ptavAttrMap[ptavId] !== presAttrId)
                .map(ptavId => ptavNameMap[ptavId] || '')
                .filter(Boolean);
            const customName = customParts.length > 0 ? customParts.join(' / ') : 'Variante Base';
            if (!seen.has(customName)) {
                seen.set(customName, {
                    id: ov.id, attribute_names: customName,
                    qty_available: ov.qty_available || 0,
                    image_variant_1920: ov.image_1920 || null
                });
            }
        }

        // Leer listas de precios nuevas (PL 9-12) y legacy (2,3)
        let plPrices = {};
        try {
            const plItems = await executeKw('product.pricelist.item', 'search_read',
                [[['product_tmpl_id', '=', tmplId], ['pricelist_id', 'in', [2, 3, 9, 10, 11, 12]]]],
                { fields: ['pricelist_id', 'fixed_price'] }
            );
            plItems.forEach(item => { plPrices[item.pricelist_id[0]] = item.fixed_price; });
        } catch(e) {}

        // Costo real desde product.product (en Odoo 18 standard_price está en la variante)
        const variantCost = odooVariants.length > 0 ? (parseFloat(odooVariants[0].standard_price) || 0) : 0;

        // Prefer portal_products data para campos guardados, Odoo como fallback
        const costFinal  = pgProductData ? (parseFloat(pgProductData.cost) || variantCost) : variantCost;
        const priceFinal = pgProductData ? (parseFloat(pgProductData.price_unidad) || 0) : (parseFloat(plPrices[9]) || tmpl.list_price || 0);
        // is_storable: leer de Odoo directamente (fix: no defaultear a false)
        const isStorable = pgProductData ? (pgProductData.is_storable === true) : (tmpl.is_storable === true);
        // categoryId: public_categ_ids retorna array de IDs en Odoo XML-RPC
        const categoryId = pgProductData?.category_id ?? (Array.isArray(tmpl.public_categ_ids) && tmpl.public_categ_ids.length > 0 ? tmpl.public_categ_ids[0] : null);

        // Construir presentaciones desde Odoo (pricelist items + x_web3 fields)
        const odooPresRow = {
            x_web3_detal_usd:         tmpl.x_web3_detal_usd || plPrices[9] || tmpl.list_price || 0,
            x_web3_combo_habilitado:  tmpl.x_web3_combo_habilitado || (plPrices[10] > 0),
            x_web3_combo_usd:         tmpl.x_web3_combo_usd || plPrices[10] || 0,
            x_web3_combo_piezas:      tmpl.x_web3_combo_piezas || 3,
            x_web3_combo_surtido:     tmpl.x_web3_combo_surtido || false,
            x_web3_docena_habilitado: tmpl.x_web3_docena_habilitado || (plPrices[11] > 0),
            x_web3_docena_usd:        tmpl.x_web3_docena_usd || plPrices[11] || plPrices[3] || 0,
            x_web3_docena_surtido:    tmpl.x_web3_docena_surtido || false,
            x_web3_bulto_habilitado:  tmpl.x_web3_bulto_habilitado || (plPrices[12] > 0),
            x_web3_bulto_usd:         tmpl.x_web3_bulto_usd || plPrices[12] || plPrices[2] || 0,
            x_web3_bulto_piezas:      tmpl.x_web3_bulto_piezas || 24,
            x_web3_bulto_surtido:     tmpl.x_web3_bulto_surtido || false,
            price_unidad:             priceFinal,
            price_docena:             plPrices[11] || plPrices[3] || 0,
            price_bulto:              plPrices[12] || plPrices[2] || 0,
            x_web3_precio_ves:        tmpl.x_web3_precio_ves || 0,
        };
        const presentacionesFinal = pgProductData ? buildPresentacionesFromRow(pgProductData) : buildPresentacionesFromRow(odooPresRow);
        const imageBase64  = pgProductData?.image_base64 || tmpl.image_1920 || null;
        const pDocena      = plPrices[11] || plPrices[3] || (pgProductData ? parseFloat(pgProductData.price_docena) : 0) || "";
        const pBulto       = plPrices[12] || plPrices[2] || (pgProductData ? parseFloat(pgProductData.price_bulto) : 0) || "";

        return res.json({
            success: true,
            product: {
                id: tmplId, name: pgProductData?.name || tmpl.name, isPending: false,
                cost: costFinal, priceUnidad: priceFinal,
                priceDocena: pDocena, priceBulto: pBulto,
                categoryId, imageBase64, isStorable,
                presentaciones: presentacionesFinal,
                variants: [...seen.values()]
            }
        });
    } catch (odooError) {
        return res.status(500).json({ error: odooError.message });
    }
});

// ─── GET /api/supplier/products/:id ───────────────────────────────────────
router.get('/:id', authenticateSupplier, async (req, res) => {
    const id = req.params.id;

    // Helper to build product response from portal_products + portal_variants rows
    function buildProductResponse(p, variantRows, odooTmplId = null) {
        return {
            success: true,
            product: {
                id: odooTmplId || p.id,
                name: p.name,
                categoryId: p.category_id,
                cost: parseFloat(p.cost) || 0,
                priceUnidad: parseFloat(p.price_unidad) || 0,
                priceDocena: parseFloat(p.price_docena) || "",
                priceBulto: parseFloat(p.price_bulto) || "",
                imageBase64: p.image_base64 || null,
                isStorable: p.is_storable || false,
                isPending: p.sync_status !== 'synced',
                variants: variantRows.map(v => ({
                    // Use odoo_prod_id when available so photo/stock pushes go to Odoo directly
                    id: v.odoo_prod_id || v.id,
                    attribute_names: v.attributes,
                    qty_available: v.qty || 0,
                    image_variant_1920: v.image_base64 || null
                }))
            }
        };
    }

    if (isUUID(id)) {
        if (pgAvailable) {
            try {
                const pRes = await pool.query("SELECT * FROM portal_products WHERE id=$1", [id]);
                if (pRes.rows.length > 0) {
                    const vRes = await pool.query("SELECT * FROM portal_variants WHERE product_id=$1 ORDER BY id", [id]);
                    markPgUp();
                    return res.json(buildProductResponse(pRes.rows[0], vRes.rows));
                }
            } catch(e) { markPgDown(); }
        }
        // Fallback: in-memory cache
        const item = offlineSyncCache[id];
        if (item) {
            return res.json({
                success: true,
                product: {
                    id, name: item.name, categoryId: item.categoryId || null,
                    cost: item.cost, priceUnidad: item.priceUnidad,
                    priceDocena: item.priceDocena || "", priceBulto: item.priceBulto || "",
                    imageBase64: item.imageBase64 || null,
                    isStorable: item.isStorable || false,
                    isPending: true,
                    variants: item.variants || []
                }
            });
        }
        return res.status(404).json({ error: "Product not found" });
    }

    // Numeric Odoo ID — FIRST check portal_products (fastest, has all saved data)
    const tmplId = parseInt(id);
    if (pgAvailable) {
        try {
            const pRes = await pool.query("SELECT * FROM portal_products WHERE odoo_tmpl_id=$1", [tmplId]);
            if (pRes.rows.length > 0) {
                const vRes = await pool.query("SELECT * FROM portal_variants WHERE product_id=$1 ORDER BY id", [pRes.rows[0].id]);
                markPgUp();
                return res.json(buildProductResponse(pRes.rows[0], vRes.rows, tmplId));
            }
        } catch(e) { markPgDown(); }
    }

    // Fallback: fetch from Odoo API (for products not in portal_products)
    try {
        const { executeKw } = require('../services/odooApi');
        const templates = await executeKw('product.template', 'read',
            [[tmplId], ['id', 'name', 'list_price', 'standard_price', 'public_categ_ids']]
        );
        if (!templates || templates.length === 0) return res.status(404).json({ error: "Producto no encontrado" });
        const t = templates[0];
        let priceDocena = "", priceBulto = "";
        try {
            const plItems = await executeKw('product.pricelist.item', 'search_read',
                [[['product_tmpl_id', '=', tmplId], ['pricelist_id', 'in', [2, 3]]]], { fields: ['pricelist_id', 'fixed_price'] }
            );
            plItems.forEach(item => {
                if (item.pricelist_id[0] === 3) priceDocena = item.fixed_price;
                if (item.pricelist_id[0] === 2) priceBulto  = item.fixed_price;
            });
        } catch(e) {}
        return res.json({
            success: true,
            product: {
                id: t.id, name: t.name,
                categoryId: t.public_categ_ids && t.public_categ_ids.length > 0 ? t.public_categ_ids[0][0] : null,
                cost: t.standard_price || 0, priceUnidad: t.list_price || 0,
                priceDocena, priceBulto,
                isStorable: false, isPending: false, variants: []
            }
        });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
});

// ─── POST /api/supplier/products/:id/edit ─────────────────────────────────
router.post('/:id/edit', authenticateSupplier, async (req, res) => {
    invalidateSupplierCache(req.user.id);
    const id = req.params.id;
    const data = req.body;
    const priceUnidad = parseFloat((data.presentaciones?.detal?.precio_usd) || data.priceUnidad) || 0;
    const priceDocena = parseFloat((data.presentaciones?.docena?.precio_usd) || data.priceDocena) || 0;
    const priceBulto  = parseFloat((data.presentaciones?.bulto?.precio_usd)  || data.priceBulto)  || 0;
    const cost        = parseFloat(data.cost)        || 0;
    const web3 = extractWeb3Fields(data);

    if (!pgAvailable) {
        const tmplId = parseInt(id);
        if (!isNaN(tmplId)) {
            (async () => {
                try {
                    const { executeKw } = require('../services/odooApi');
                    const upd = { name: data.name, list_price: priceUnidad, standard_price: cost, ...web3 };
                    if (data.categoryId) upd.public_categ_ids = [[6, 0, [parseInt(data.categoryId)]]];
                    if (data.imageBase64) upd.image_1920 = data.imageBase64.split(',')[1] || data.imageBase64;
                    await executeKw('product.template', 'write', [[tmplId], upd]);
                } catch(err) { console.error("[BACKGROUND EDIT]", err.message); }
            })();
        }
        return res.json({ success: true, message: "Editando en segundo plano..." });
    }

    const isStorable = data.isStorable === true || data.isStorable === 'true';

    try {
        if (isUUID(id)) {
            await pool.query(
                `UPDATE portal_products SET name=$1, category_id=$2, cost=$3, price_unidad=$4, price_docena=$5, price_bulto=$6, is_storable=$7,
                  x_web3_detal_usd=$8, x_web3_combo_habilitado=$9, x_web3_combo_usd=$10, x_web3_combo_piezas=$11, x_web3_combo_surtido=$12,
                  x_web3_docena_habilitado=$13, x_web3_docena_usd=$14, x_web3_docena_surtido=$15,
                  x_web3_bulto_habilitado=$16, x_web3_bulto_usd=$17, x_web3_bulto_piezas=$18, x_web3_bulto_surtido=$19, x_web3_precio_ves=$20,
                  image_base64=$21, sync_status='pending' WHERE id=$22 AND supplier_id=$23`,
                [data.name, data.categoryId ? parseInt(data.categoryId) : null, cost, priceUnidad, priceDocena || null, priceBulto || null, isStorable,
                 web3.x_web3_detal_usd, web3.x_web3_combo_habilitado, web3.x_web3_combo_usd, web3.x_web3_combo_piezas, web3.x_web3_combo_surtido,
                 web3.x_web3_docena_habilitado, web3.x_web3_docena_usd, web3.x_web3_docena_surtido,
                 web3.x_web3_bulto_habilitado, web3.x_web3_bulto_usd, web3.x_web3_bulto_piezas, web3.x_web3_bulto_surtido, web3.x_web3_precio_ves,
                 data.imageBase64 || null, id, req.user.id]
            );
        } else {
            const check = await pool.query("SELECT id FROM portal_products WHERE odoo_tmpl_id=$1", [parseInt(id)]);
            if (check.rows.length > 0) {
                await pool.query(
                    `UPDATE portal_products SET name=$1, category_id=$2, cost=$3, price_unidad=$4, price_docena=$5, price_bulto=$6, is_storable=$7,
                      x_web3_detal_usd=$8, x_web3_combo_habilitado=$9, x_web3_combo_usd=$10, x_web3_combo_piezas=$11, x_web3_combo_surtido=$12,
                      x_web3_docena_habilitado=$13, x_web3_docena_usd=$14, x_web3_docena_surtido=$15,
                      x_web3_bulto_habilitado=$16, x_web3_bulto_usd=$17, x_web3_bulto_piezas=$18, x_web3_bulto_surtido=$19, x_web3_precio_ves=$20,
                      image_base64=$21, sync_status='pending' WHERE odoo_tmpl_id=$22`,
                    [data.name, data.categoryId ? parseInt(data.categoryId) : null, cost, priceUnidad, priceDocena || null, priceBulto || null, isStorable,
                     web3.x_web3_detal_usd, web3.x_web3_combo_habilitado, web3.x_web3_combo_usd, web3.x_web3_combo_piezas, web3.x_web3_combo_surtido,
                     web3.x_web3_docena_habilitado, web3.x_web3_docena_usd, web3.x_web3_docena_surtido,
                     web3.x_web3_bulto_habilitado, web3.x_web3_bulto_usd, web3.x_web3_bulto_piezas, web3.x_web3_bulto_surtido, web3.x_web3_precio_ves,
                     data.imageBase64 || null, parseInt(id)]
                );
            } else {
                await pool.query(
                    `INSERT INTO portal_products (id, supplier_id, name, category_id, price_unidad, price_docena, price_bulto, cost, is_storable,
                      x_web3_detal_usd, x_web3_combo_habilitado, x_web3_combo_usd, x_web3_combo_piezas, x_web3_combo_surtido,
                      x_web3_docena_habilitado, x_web3_docena_usd, x_web3_docena_surtido,
                      x_web3_bulto_habilitado, x_web3_bulto_usd, x_web3_bulto_piezas, x_web3_bulto_surtido, x_web3_precio_ves,
                      image_base64, sync_status, odoo_tmpl_id, created_at)
                     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,'pending',$24,$25)`,
                    [crypto.randomUUID(), req.user.id, data.name, data.categoryId ? parseInt(data.categoryId) : null,
                     priceUnidad, priceDocena || null, priceBulto || null, cost, isStorable,
                     web3.x_web3_detal_usd, web3.x_web3_combo_habilitado, web3.x_web3_combo_usd, web3.x_web3_combo_piezas, web3.x_web3_combo_surtido,
                     web3.x_web3_docena_habilitado, web3.x_web3_docena_usd, web3.x_web3_docena_surtido,
                     web3.x_web3_bulto_habilitado, web3.x_web3_bulto_usd, web3.x_web3_bulto_piezas, web3.x_web3_bulto_surtido, web3.x_web3_precio_ves,
                     data.imageBase64 || null, parseInt(id), Date.now()]
                );
            }
        }

        const tmplId = parseInt(id);
        if (!isNaN(tmplId)) {
            (async () => {
                try {
                    const { executeKw } = require('../services/odooApi');
                    const upd = { name: data.name, list_price: priceUnidad, standard_price: cost, ...web3 };
                    if (data.categoryId) upd.public_categ_ids = [[6, 0, [parseInt(data.categoryId)]]];
                    if (data.imageBase64) upd.image_1920 = data.imageBase64.split(',')[1] || data.imageBase64;
                    await executeKw('product.template', 'write', [[tmplId], upd]);
                    console.log(`[BACKGROUND EDIT] Sync to Odoo completed for product ${tmplId}`);
                    await pool.query("UPDATE portal_products SET sync_status='synced' WHERE odoo_tmpl_id=$1", [tmplId]);
                } catch(err) { 
                    console.error("[BACKGROUND EDIT] Sync to Odoo failed:", err.message);
                    await pool.query("UPDATE portal_products SET sync_status='error', sync_error=$1 WHERE odoo_tmpl_id=$2", [err.message, tmplId]);
                }
            })();
        }
        
        markPgUp();
        return res.json({ success: true, message: "Cambios guardados. Sincronizando con Odoo..." });
    } catch (dbError) {
        markPgDown();
        const tmplId = parseInt(id);
        if (!isNaN(tmplId)) {
            (async () => {
                try {
                    const { executeKw } = require('../services/odooApi');
                    const upd = { name: data.name, list_price: priceUnidad, standard_price: cost };
                    if (data.categoryId) upd.public_categ_ids = [[6, 0, [parseInt(data.categoryId)]]];
                    if (data.imageBase64) upd.image_1920 = data.imageBase64.split(',')[1] || data.imageBase64;
                    await executeKw('product.template', 'write', [[tmplId], upd]);
                    if (priceDocena) {
                        const ex = await executeKw('product.pricelist.item', 'search_read', [[['pricelist_id', '=', 3], ['product_tmpl_id', '=', tmplId]]], { fields: ['id'] });
                        if (ex.length > 0) await executeKw('product.pricelist.item', 'write', [[ex[0].id], { fixed_price: priceDocena }]);
                        else await executeKw('product.pricelist.item', 'create', [{ pricelist_id: 3, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: priceDocena }]);
                    }
                } catch(err) { console.error("[BACKGROUND EDIT]", err.message); }
            })();
        }
        return res.json({ success: true, message: "Editando en segundo plano..." });
    }
});

// ─── POST /api/supplier/products/:id/toggle_publish ───────────────────────
router.post('/:id/toggle_publish', authenticateSupplier, async (req, res) => {
    invalidateSupplierCache(req.user.id);
    const id = req.params.id;
    try {
        if (!isUUID(id)) {
            const check = await pool.query("SELECT id FROM portal_products WHERE odoo_tmpl_id=$1", [parseInt(id)]);
            if (check.rows.length > 0) {
                await pool.query("UPDATE portal_products SET sync_status='pending' WHERE odoo_tmpl_id=$1", [parseInt(id)]);
            }
        }
        return res.json({ success: true, is_published: true });
    } catch (dbError) {
        const tmplId = parseInt(id);
        if (!isNaN(tmplId)) {
            (async () => {
                try {
                    const { executeKw } = require('../services/odooApi');
                    const t = await executeKw('product.template', 'read', [[tmplId], ['is_published']]);
                    if (t.length > 0) await executeKw('product.template', 'write', [[tmplId], { is_published: !t[0].is_published }]);
                } catch(e) {}
            })();
        }
        return res.json({ success: true, is_published: true });
    }
});

// ─── POST /api/supplier/variants/:variantId/image ─────────────────────────
router.post('/variants/:variantId/image', authenticateSupplier, async (req, res) => {
    const { variantId } = req.params;
    const { imageBase64 } = req.body;
    if (!imageBase64) return res.status(400).json({ error: "imageBase64 required" });

    if (isUUID(variantId)) {
        // Update memory cache immediately (instant UI feedback)
        for (const key of Object.keys(offlineSyncCache)) {
            const item = offlineSyncCache[key];
            if (item.variants) {
                const v = item.variants.find(v => v.id === variantId);
                if (v) v.image_variant_1920 = imageBase64;
            }
        }

        // Update PostgreSQL
        let odooVariantId = null;
        if (pgAvailable) {
            try {
                const result = await pool.query(
                    "UPDATE portal_variants SET image_base64=$1 WHERE id=$2 RETURNING odoo_prod_id",
                    [imageBase64, variantId]
                );
                markPgUp();
                if (result.rows.length > 0 && result.rows[0].odoo_prod_id) {
                    odooVariantId = result.rows[0].odoo_prod_id;
                }
            } catch(e) { markPgDown(); }
        }

        // If variant is already synced → push photo to Odoo in background
        if (odooVariantId) {
            (async () => {
                try {
                    const { executeKw } = require('../services/odooApi');
                    const rawB64 = imageBase64.split(',')[1] || imageBase64;
                    await executeKw('product.product', 'write', [[odooVariantId], { image_1920: rawB64 }]);
                    console.log(`[VARIANT IMG] Odoo variant ${odooVariantId} image updated.`);
                } catch(e) { console.warn('[VARIANT IMG]', e.message); }
            })();
        }

        return res.json({ success: true });
    }

    // Numeric Odoo product.product ID → update Odoo AND portal_variants (so edit modal reloads correctly)
    const odooVariantId = parseInt(variantId);
    res.json({ success: true }); // respond immediately

    // Update portal_variants so the edit modal shows the correct image on next load
    if (pgAvailable) {
        try {
            await pool.query(
                "UPDATE portal_variants SET image_base64=$1 WHERE odoo_prod_id=$2",
                [imageBase64, odooVariantId]
            );
            markPgUp();
        } catch(e) { markPgDown(); }
    }

    // Push to Odoo in background
    (async () => {
        try {
            const { executeKw } = require('../services/odooApi');
            const rawB64 = imageBase64.split(',')[1] || imageBase64;
            await executeKw('product.product', 'write', [[odooVariantId], { image_1920: rawB64 }]);
            console.log(`[VARIANT IMG] ✓ Odoo variant ${odooVariantId} image updated`);
        } catch(e) { console.warn('[VARIANT IMG]', e.message); }
    })();
});

// ─── POST /api/supplier/variants/:variantId/stock ─────────────────────────
router.post('/variants/:variantId/stock', authenticateSupplier, async (req, res) => {
    const { variantId } = req.params;
    const qty = parseInt(req.body.qty) || 0;

    if (isUUID(variantId)) {
        // Update memory cache immediately
        for (const key of Object.keys(offlineSyncCache)) {
            const item = offlineSyncCache[key];
            if (item.variants) {
                const v = item.variants.find(v => v.id === variantId);
                if (v) v.qty_available = qty;
            }
        }

        // Update PostgreSQL
        let odooVariantId = null;
        if (pgAvailable) {
            try {
                const result = await pool.query(
                    "UPDATE portal_variants SET qty=$1 WHERE id=$2 RETURNING odoo_prod_id",
                    [qty, variantId]
                );
                markPgUp();
                if (result.rows.length > 0 && result.rows[0].odoo_prod_id) {
                    odooVariantId = result.rows[0].odoo_prod_id;
                }
            } catch(e) { markPgDown(); }
        }

        // If variant is already synced → push stock to Odoo in background
        if (odooVariantId) {
            setOdooStock(odooVariantId, qty);
        }

        return res.json({ success: true });
    }

    // Numeric Odoo product.product ID → update portal_variants AND Odoo
    const odooVariantId = parseInt(variantId);
    res.json({ success: true }); // respond immediately

    // Update portal_variants.qty so the edit modal shows correct stock on next load
    if (pgAvailable) {
        try {
            await pool.query(
                "UPDATE portal_variants SET qty=$1 WHERE odoo_prod_id=$2",
                [qty, odooVariantId]
            );
            markPgUp();
            console.log(`[STOCK] portal_variants.qty updated for odoo_prod_id=${odooVariantId}`);
        } catch(e) { markPgDown(); }
    }

    // Push stock to Odoo in background
    setOdooStock(odooVariantId, qty);
});

// Reusable: set stock on an Odoo product.product in background
async function setOdooStock(odooVariantId, qty) {
    try {
        const { executeKw } = require('../services/odooApi');

        // Verificar si el producto es storable; si no, corregirlo automáticamente
        const varData = await executeKw('product.product', 'read', [[odooVariantId], ['product_tmpl_id', 'type']]);
        if (!varData || varData.length === 0) { console.warn('[STOCK] Variante no encontrada:', odooVariantId); return; }
        const tmplId = varData[0].product_tmpl_id[0];

        const tmplData = await executeKw('product.template', 'read', [[tmplId], ['is_storable', 'type']]);
        if (!tmplData[0].is_storable) {
            console.log(`[STOCK] Producto ${tmplId} no es storable — corrigiendo...`);
            await executeKw('product.template', 'write', [[tmplId], { is_storable: true }]);
            console.log(`[STOCK] ✓ is_storable = true aplicado`);
        }

        let locs = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'WH/']]], { fields: ['id'], limit: 1 });
        if (locs.length === 0) locs = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal']]], { fields: ['id'], limit: 1 });
        if (locs.length === 0) { console.warn('[STOCK] No hay location interna'); return; }
        const locId = locs[0].id;

        const existing = await executeKw('stock.quant', 'search_read', [
            [['product_id', '=', odooVariantId], ['location_id', '=', locId]]
        ], { fields: ['id'] });

        let quantId;
        if (existing.length > 0) {
            quantId = existing[0].id;
            await executeKw('stock.quant', 'write', [[quantId], { inventory_quantity: qty }]);
        } else {
            quantId = await executeKw('stock.quant', 'create', [{ product_id: odooVariantId, location_id: locId, inventory_quantity: qty }]);
        }

        // Aplicar con fallback para distintas versiones Odoo
        try {
            await executeKw('stock.quant', 'action_apply_inventory', [[quantId]]);
        } catch(e) {
            console.warn(`[STOCK] action_apply_inventory failed (${e.message}), intentando fallback`);
            try { await executeKw('stock.quant', 'write', [[quantId], { inventory_quantity_set: true }]); } catch(_) {}
        }
        console.log(`[STOCK] ✓ Variante ${odooVariantId} qty=${qty}`);
    } catch(e) {
        console.error(`[STOCK] ✗ Variante ${odooVariantId}:`, e.message);
    }
}

// ─── POST /api/supplier/repair-sync ── Reparar productos que están en Odoo pero con error en DB ──
// Busca en Odoo los productos del proveedor y actualiza portal_products con odoo_tmpl_id correcto
router.post('/repair-sync', authenticateSupplier, async (req, res) => {
    const supplierId = req.user.id;
    invalidateSupplierCache(supplierId);
    try {
        const { executeKw } = require('../services/odooApi');

        // 1. Obtener productos del proveedor en Odoo
        const suppInfos = await executeKw('product.supplierinfo', 'search_read', [
            [['partner_id', '=', supplierId]]
        ], { fields: ['product_tmpl_id'] });

        const odooTmplIds = [...new Set(suppInfos.map(s => s.product_tmpl_id[0]))];
        if (odooTmplIds.length === 0) {
            return res.json({ success: true, repaired: 0, message: 'No hay productos en Odoo para este proveedor' });
        }

        const templates = await executeKw('product.template', 'read', [odooTmplIds],
            { fields: ['id', 'name', 'list_price', 'standard_price', 'is_published'] });

        let repaired = 0, inserted = 0;

        if (pgAvailable) {
            for (const tmpl of templates) {
                // Buscar si ya existe en portal_products por nombre o tmpl_id
                const existing = await pool.query(
                    `SELECT id, sync_status, odoo_tmpl_id FROM portal_products
                     WHERE supplier_id=$1 AND (odoo_tmpl_id=$2 OR (LOWER(name)=LOWER($3) AND odoo_tmpl_id IS NULL))
                     LIMIT 1`,
                    [supplierId, tmpl.id, tmpl.name]
                );

                if (existing.rows.length > 0) {
                    const row = existing.rows[0];
                    if (!row.odoo_tmpl_id || row.sync_status !== 'synced') {
                        await pool.query(
                            `UPDATE portal_products SET odoo_tmpl_id=$1, sync_status='synced', sync_error=NULL
                             WHERE id=$2`,
                            [tmpl.id, row.id]
                        );
                        repaired++;
                        console.log(`[REPAIR] Reparado: "${tmpl.name}" → odoo_tmpl_id=${tmpl.id}`);
                    }
                } else {
                    // Producto en Odoo pero no en portal_products → insertar
                    await pool.query(
                        `INSERT INTO portal_products (id, supplier_id, name, price_unidad, cost, sync_status, odoo_tmpl_id, created_at)
                         VALUES (gen_random_uuid(), $1, $2, $3, $4, 'synced', $5, $6)
                         ON CONFLICT DO NOTHING`,
                        [supplierId, tmpl.name, tmpl.list_price || 0, tmpl.standard_price || 0, tmpl.id, Date.now()]
                    );
                    inserted++;
                    console.log(`[REPAIR] Insertado: "${tmpl.name}" → odoo_tmpl_id=${tmpl.id}`);
                }
            }

            // Limpiar huérfanos de este proveedor
            const cleanRes = await pool.query(
                `DELETE FROM portal_products WHERE supplier_id=$1 AND sync_status='error' AND odoo_tmpl_id IS NULL`,
                [supplierId]
            );

            markPgUp();
            res.json({
                success: true,
                repaired,
                inserted,
                cleaned: cleanRes.rowCount,
                message: `Reparados: ${repaired}, Insertados: ${inserted}, Huérfanos eliminados: ${cleanRes.rowCount}`
            });
        } else {
            res.json({ success: false, error: 'Base de datos no disponible' });
        }
    } catch (err) {
        console.error('[REPAIR SYNC]', err.message);
        res.status(500).json({ success: false, error: err.message });
    }
});

module.exports = router;
