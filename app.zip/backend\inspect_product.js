const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

common.methodCall('authenticate', [db, username, password, {}], function (error, uid) {
    if (error) return console.error(error);

    // Get a recent product
    models.methodCall('execute_kw', [db, uid, password, 'product.template', 'search_read', [[['sale_ok', '=', true]], ['name', 'attribute_line_ids', 'standard_price', 'list_price', 'seller_ids', 'public_categ_ids'], 0, 2]], function (err, templates) {
        if (err) return console.error(err);
        console.log("Templates:", JSON.stringify(templates, null, 2));

        if (templates.length > 0 && templates[0].attribute_line_ids.length > 0) {
            models.methodCall('execute_kw', [db, uid, password, 'product.template.attribute.line', 'read', [templates[0].attribute_line_ids, []]], function(err, lines) {
                 console.log("Attribute Lines:", JSON.stringify(lines, null, 2));
            });
        }
    });
});
