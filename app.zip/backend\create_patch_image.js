const fs = require('fs');

let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

const badImageLogicRegex = /document\.getElementById\('image-preview'\)\.innerHTML = `<img src="\$\{base64Image\}" \/> <input type="file" id="prod-image-hidden" style="display:none;">`;\s*document\.getElementById\('prod-image'\)\.removeAttribute\('required'\);/;

const fixedImageLogic = `
                        document.getElementById('image-preview').innerHTML = \`<img src="\${base64Image}" /> <input type="file" id="prod-image" accept="image/png, image/jpeg, image/webp" style="display:none;">\`;
`;

// Wait, if I do that, the input is NOT required, so that's good. But wait! If I just delete the removeAttribute, it won't crash.
html = html.replace(badImageLogicRegex, fixedImageLogic);

// But wait, there is another place where the input might be accessed? Let's check where prod-image is used.
fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/patch_image.js', 
`const fs = require('fs');
let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');
const badRegex = /document\\.getElementById\\('image-preview'\\)\\.innerHTML = \\\`<img src="\\\$\\{base64Image\\}" \\/> <input type="file" id="prod-image-hidden" style="display:none;">\\\`;\\s*document\\.getElementById\\('prod-image'\\)\\.removeAttribute\\('required'\\);/;
const goodCode = "document.getElementById('image-preview').innerHTML = \\\`<img src=\\"\\$\\{base64Image\\}\\" /> <input type=\\"file\\" id=\\"prod-image\\" accept=\\"image/png, image/jpeg, image/webp\\" style=\\"display:none;\\">\\\`;";
html = html.replace(badRegex, goodCode);
fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log('Image logic patched');
`);
