$url = 'https://listex.odoo.com/web/content/16027/api_catalogo_listex.json'
$data = Invoke-RestMethod -Uri $url
Write-Output "Total productos: $($data.Count)"
if ($data.Count -gt 0) {
    Write-Output "--- Primer Producto ---"
    $data[0] | ConvertTo-Json -Depth 10
    
    $withVariants = $data | Where-Object { $_.variantes -and $_.variantes.Count -gt 0 } | Select-Object -First 1
    if ($withVariants) {
        Write-Output "--- Producto con Variantes ---"
        $withVariants | ConvertTo-Json -Depth 10
    }
}
