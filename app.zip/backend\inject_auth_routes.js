const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

// Inject jsonwebtoken
if (!serverJs.includes("const jwt = require('jsonwebtoken');")) {
    serverJs = serverJs.replace("const express = require('express');", "const express = require('express');\nconst jwt = require('jsonwebtoken');");
}

const JWT_SECRET = "process.env.JWT_SECRET || 'super_secret_portal_key'";

// Inject routes
const authRoutes = `
// ==========================================
// SUPPLIER PORTAL AUTHENTICATION
// ==========================================
const JWT_SECRET = ${JWT_SECRET};

app.post('/api/supplier/register', async (req, res) => {
    try {
        await authenticate();
        const { name, email, phone, address, rif, password } = req.body;
        
        if (!name || !email || !password) {
            return res.status(400).json({ error: "Name, email and password are required" });
        }

        // Check if exists
        const existing = await executeKw('res.partner', 'search', [[['email', '=', email]]]);
        if (existing.length > 0) {
            return res.status(400).json({ error: "Email already registered" });
        }

        const partnerData = {
            name: name,
            email: email,
            phone: phone || '',
            street: address || '',
            x_studio_is_portal_supplier: true,
            x_studio_supplier_status: 'pending',
            x_studio_portal_password: password,
            x_studio_supplier_rif: rif || ''
        };

        const newPartnerId = await executeKw('res.partner', 'create', [partnerData]);
        res.json({ success: true, message: "Registrado correctamente. En espera de aprobación.", id: newPartnerId });
    } catch (error) {
        console.error("Register Error:", error);
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/supplier/login', async (req, res) => {
    try {
        await authenticate();
        const { email, password } = req.body;
        
        if (!email || !password) return res.status(400).json({ error: "Email and password required" });

        const partners = await executeKw('res.partner', 'search_read', [
            [['email', '=', email], ['x_studio_portal_password', '=', password]],
            ['id', 'name', 'x_studio_supplier_status', 'x_studio_is_portal_supplier']
        ]);

        if (partners.length === 0) {
            return res.status(401).json({ error: "Credenciales incorrectas" });
        }

        const partner = partners[0];
        if (partner.x_studio_supplier_status !== 'approved') {
            return res.status(403).json({ error: "Tu cuenta de proveedor aún está pendiente de aprobación." });
        }

        const token = jwt.sign({ id: partner.id, name: partner.name, email: email }, JWT_SECRET, { expiresIn: '7d' });
        res.json({ success: true, token: token, user: { id: partner.id, name: partner.name, email: email } });
    } catch (error) {
        console.error("Login Error:", error);
        res.status(500).json({ error: error.message });
    }
});

// Middleware to protect routes
function authenticateSupplier(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: "No token provided" });
    const token = authHeader.split(' ')[1];
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ error: "Invalid token" });
        req.user = user;
        next();
    });
}
// ==========================================
`;

if (!serverJs.includes("/api/supplier/register")) {
    serverJs = serverJs.replace("app.listen(PORT", authRoutes + "\napp.listen(PORT");
    fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
    console.log("Injected auth routes");
} else {
    console.log("Routes already exist");
}
