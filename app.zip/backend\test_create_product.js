const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

common.methodCall('authenticate', [db, username, password, {}], async function (error, uid) {
    if (error) return console.error("Auth:", error);

    function executeKw(model, method, args) {
        return new Promise((resolve, reject) => {
            models.methodCall('execute_kw', [db, uid, password, model, method, args], (err, res) => {
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        const productData = {
            name: "Test Prod API 2",
            list_price: 10,
            standard_price: 5,
            sale_ok: true,
            purchase_ok: true,
            is_published: true
        };
        const tmplId = await executeKw('product.template', 'create', [productData]);
        console.log("Created Tmpl:", tmplId);
    } catch(err) {
        console.error("Error creating:", err);
    }
});
