const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const targetFunction = `app.post('/api/supplier/products', authenticateSupplier, async (req, res) => {`;
const replacementFunction = `app.post('/api/supplier/products', authenticateSupplier, async (req, res) => {
    const t0 = Date.now();
    const logTime = (msg) => console.log(\`[Time] \${msg}: \${(Date.now() - t0)/1000}s\`);
`;

serverJs = serverJs.replace(targetFunction, replacementFunction);

// Inject log statements at various points
serverJs = serverJs.replace(`// 1. Batch collect required attributes`, `logTime('Start Batch Collect Attributes'); // 1. Batch collect required attributes`);
serverJs = serverJs.replace(`const existingAttrs = await executeKw`, `logTime('Before search_read product.attribute'); const existingAttrs = await executeKw`);
serverJs = serverJs.replace(`const attrsToCreate = uniqueAttrNames`, `logTime('After search_read product.attribute'); const attrsToCreate = uniqueAttrNames`);
serverJs = serverJs.replace(`const newAttrIds = await executeKw('product.attribute', 'create'`, `logTime('Before create product.attribute'); const newAttrIds = await executeKw('product.attribute', 'create'`);
serverJs = serverJs.replace(`// 2. Batch collect required attribute values`, `logTime('Start Batch Collect Attribute Values'); // 2. Batch collect required attribute values`);
serverJs = serverJs.replace(`const existingVals = await executeKw('product.attribute.value', 'search_read'`, `logTime('Before search_read product.attribute.value'); const existingVals = await executeKw('product.attribute.value', 'search_read'`);
serverJs = serverJs.replace(`const existingValMap = {};`, `logTime('After search_read product.attribute.value'); const existingValMap = {};`);
serverJs = serverJs.replace(`const newValIds = await executeKw('product.attribute.value', 'create'`, `logTime('Before create product.attribute.value'); const newValIds = await executeKw('product.attribute.value', 'create'`);
serverJs = serverJs.replace(`// 3. Prepare Attribute Lines for Inline Creation`, `logTime('Start Prepare Attribute Lines'); // 3. Prepare Attribute Lines for Inline Creation`);
serverJs = serverJs.replace(`// 4. Create Product Template`, `logTime('Before Create Product Template'); // 4. Create Product Template`);
serverJs = serverJs.replace(`const tmplId = await executeKw('product.template', 'create', [productData]);`, `const tmplId = await executeKw('product.template', 'create', [productData]); logTime('After Create Product Template');`);
serverJs = serverJs.replace(`// 5. Batch Create Pricelists`, `logTime('Start Create Pricelists'); // 5. Batch Create Pricelists`);
serverJs = serverJs.replace(`res.json({ success: true, message: "Producto creado", productId: tmplId });`, `logTime('Finished /products POST'); res.json({ success: true, message: "Producto creado", productId: tmplId });`);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Injected timing logs into server.js");
