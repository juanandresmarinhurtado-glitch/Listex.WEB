const fs = require('fs');

let code = fs.readFileSync('backend/server.js', 'utf8');

// 1. Imports and Globals
code = code.replace(
    /const queueFile = path\.join\(__dirname, 'queue\.json'\);[\s\S]*?function writeDashCache[\s\S]*?\}/,
    `const { pool, initDB } = require('./db');
initDB();`
);

// 2. Dashboard
const dashRegex = /app\.get\('\/api\/supplier\/products', authenticateSupplier, async \(req, res\) => \{[\s\S]*?(?=\napp\.post\('\/api\/supplier\/products',)/;
code = code.replace(dashRegex, `app.get('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        const partnerId = req.user.id;
        
        const cacheRes = await pool.query('SELECT products FROM dashboard_cache WHERE partner_id = $1', [partnerId]);
        let cachedProducts = cacheRes.rows.length > 0 ? cacheRes.rows[0].products : [];
        
        const mergedProducts = [...cachedProducts];
        try {
            const qRes = await pool.query("SELECT * FROM queue_products WHERE partner_id = $1 AND status IN ('pending', 'processing', 'error')", [partnerId]);
            for (const item of qRes.rows) {
                if (!mergedProducts.find(p => p.id === item.id)) {
                    mergedProducts.unshift({
                        id: item.id,
                        name: item.data.name + (item.status==='error' ? ' (Error)' : ' (Procesando...)'),
                        list_price: item.data.priceUnidad,
                        standard_price: item.data.cost,
                        qty_available: 0,
                        is_published: false,
                        isPending: true
                    });
                }
            }
        } catch(e) {}
        
        if (mergedProducts.length > 0) {
            res.json({ success: true, products: mergedProducts });
        }
        
        authenticate().then(async () => {
            const supplierInfos = await executeKw('product.supplierinfo', 'search_read', [
                [['partner_id', '=', partnerId]]
            ], { fields: ['product_tmpl_id'] });
            
            let freshProducts = [];
            if (supplierInfos.length > 0) {
                const templateIds = supplierInfos.map(s => s.product_tmpl_id[0]);
                freshProducts = await executeKw('product.template', 'search_read', [
                    [['id', 'in', templateIds]],
                    ['id', 'name', 'list_price', 'standard_price', 'qty_available', 'is_published', 'image_128']
                ]);
            }
            await pool.query(
                "INSERT INTO dashboard_cache (partner_id, products, timestamp) VALUES ($1, $2, $3) ON CONFLICT (partner_id) DO UPDATE SET products = EXCLUDED.products, timestamp = EXCLUDED.timestamp",
                [partnerId, JSON.stringify(freshProducts), Date.now()]
            );
        }).catch(err => console.error("Background Cache Refresh Error:", err));
        
        if (mergedProducts.length === 0) {
            setTimeout(async () => {
                if (!res.headersSent) {
                    const c2 = await pool.query('SELECT products FROM dashboard_cache WHERE partner_id = $1', [partnerId]);
                    if (c2.rows.length > 0) res.json({ success: true, products: c2.rows[0].products });
                    else res.json({ success: true, products: [] });
                }
            }, 1500);
        }
        
    } catch (error) {
        if (!res.headersSent) res.status(500).json({ error: error.message });
    }
});`);

// 3. Create Product
const createRegex = /const queue = readJson\(queueFile\);[\s\S]*?writeJson\(queueFile, queue\);/;
code = code.replace(createRegex, `await pool.query(
            "INSERT INTO queue_products (id, partner_id, status, data, timestamp) VALUES ($1, $2, $3, $4, $5)",
            [tempId, req.user.id, 'pending', JSON.stringify(productData), Date.now()]
        );`);

const createVarsRegex = /const variantsQueue = readJson\(variantsFile\);[\s\S]*?writeJson\(variantsFile, variantsQueue\);/;
code = code.replace(createVarsRegex, `await pool.query(
            "INSERT INTO queue_variants (product_id, variants) VALUES ($1, $2)",
            [tempId, JSON.stringify(fakeVariants)]
        );`);

// 4. Get Product
const getProdRegex = /const queue = readJson\(queueFile\);[\s\S]*?const fakeVariants = variantsQueue\[reqId\] \|\| \[\];/;
code = code.replace(getProdRegex, `const qRes = await pool.query("SELECT * FROM queue_products WHERE id = $1", [reqId]);
            if (qRes.rows.length === 0 || qRes.rows[0].partner_id !== req.user.id) return res.status(404).json({ error: "No encontrado en cola" });
            const qData = qRes.rows[0];
            
            const vRes = await pool.query("SELECT variants FROM queue_variants WHERE product_id = $1", [reqId]);
            const fakeVariants = vRes.rows.length > 0 ? vRes.rows[0].variants : [];`);

// 5. Save Variants
const saveVarsRegex = /const queue = readJson\(queueFile\);[\s\S]*?const variantsQueue = readJson\(variantsFile\);[\s\S]*?const fakeVariants = variantsQueue\[reqId\] \|\| \[\];/;
code = code.replace(saveVarsRegex, `const qRes = await pool.query("SELECT * FROM queue_products WHERE id = $1", [reqId]);
        if (qRes.rows.length === 0 || qRes.rows[0].partner_id !== req.user.id) return res.status(404).json({ error: "Producto no encontrado en cola" });
        const qData = qRes.rows[0];
        
        const vRes = await pool.query("SELECT variants FROM queue_variants WHERE product_id = $1", [reqId]);
        const fakeVariants = vRes.rows.length > 0 ? vRes.rows[0].variants : [];`);

const writeVarsRegex = /writeJson\(variantsFile, variantsQueue\);/;
code = code.replace(writeVarsRegex, `await pool.query("UPDATE queue_variants SET variants = $1 WHERE product_id = $2", [JSON.stringify(fakeVariants), reqId]);`);

// 6. Process Queue Worker
const processRegex = /async function processQueue\(\) \{[\s\S]*?\}\n\}\n\nsetInterval\(processQueue, 15000\);/;
code = code.replace(processRegex, `async function processQueue() {
    try {
        const qRes = await pool.query("SELECT * FROM queue_products WHERE status IN ('pending', 'error') ORDER BY timestamp ASC");
        if (qRes.rows.length === 0) return;
        
        await authenticate();
        
        for (const item of qRes.rows) {
            const tempId = item.id;
            try {
                await pool.query("UPDATE queue_products SET status = 'processing' WHERE id = $1", [tempId]);
                const data = item.data;
                const { name, cost, priceUnidad, priceDocena, priceBulto, categoryId, isStorable, customAttributes, imageBase64 } = data;
                
                // (Odoo Sync Logic using XML-RPC...)
                // To keep it simple, we reuse the existing Odoo logic block. We will just paste it here.
                
                const existingAttrMap = {};
                const existingValMap = {};
                const odooAttrs = await executeKw('product.attribute', 'search_read', [[]], { fields: ['id', 'name'] });
                odooAttrs.forEach(a => existingAttrMap[a.name] = a.id);
                
                const requiredAttrNames = ['Presentacin'];
                if (customAttributes) {
                    for (let attr of customAttributes) if (attr.name && attr.name.trim()) requiredAttrNames.push(attr.name.trim());
                }
                for (let attrName of requiredAttrNames) {
                    if (!existingAttrMap[attrName]) {
                        const newAttrId = await executeKw('product.attribute', 'create', [{ name: attrName, create_variant: 'always' }]);
                        existingAttrMap[attrName] = newAttrId;
                    }
                }
                
                const odooVals = await executeKw('product.attribute.value', 'search_read', [[]], { fields: ['id', 'name', 'attribute_id'] });
                odooVals.forEach(v => {
                    if (v.attribute_id) existingValMap[\`\${v.attribute_id[0]}_\${v.name}\`] = v.id;
                });
                
                const valuesToCreate = [];
                const presAttrId = existingAttrMap['Presentacin'];
                if (!existingValMap[\`\${presAttrId}_unidad variada\`]) valuesToCreate.push({ attrId: presAttrId, valName: 'unidad variada' });
                if (priceDocena && !existingValMap[\`\${presAttrId}_docena cerrada\`]) valuesToCreate.push({ attrId: presAttrId, valName: 'docena cerrada' });
                if (priceBulto && !existingValMap[\`\${presAttrId}_bulto\`]) valuesToCreate.push({ attrId: presAttrId, valName: 'bulto' });
                
                if (customAttributes) {
                    for (let attr of customAttributes) {
                        if (!attr.name || !attr.name.trim() || !attr.values || attr.values.length === 0) continue;
                        const attrId = existingAttrMap[attr.name.trim()];
                        for (let v of attr.values) {
                            if (v.trim() && !existingValMap[\`\${attrId}_\${v.trim()}\`]) {
                                valuesToCreate.push({ attrId: attrId, valName: v.trim() });
                            }
                        }
                    }
                }
                
                if (valuesToCreate.length > 0) {
                    const uniqueValsToCreate = valuesToCreate.filter((v, i, a) => a.findIndex(t => (t.attrId === v.attrId && t.valName === v.valName)) === i);
                    const createPayload = uniqueValsToCreate.map(v => ({ attribute_id: v.attrId, name: v.valName }));
                    const newValIds = await executeKw('product.attribute.value', 'create', [createPayload]);
                    if (Array.isArray(newValIds)) {
                        uniqueValsToCreate.forEach((r, idx) => existingValMap[\`\${r.attrId}_\${r.valName}\`] = newValIds[idx]);
                    } else {
                        uniqueValsToCreate.forEach((r, idx) => existingValMap[\`\${r.attrId}_\${r.valName}\`] = newValIds);
                    }
                }
                
                const ptalPayload = [];
                let presValIds = [existingValMap[\`\${existingAttrMap['Presentacin']}_unidad variada\`]];
                if (priceDocena) presValIds.push(existingValMap[\`\${existingAttrMap['Presentacin']}_docena cerrada\`]);
                if (priceBulto) presValIds.push(existingValMap[\`\${existingAttrMap['Presentacin']}_bulto\`]);
                ptalPayload.push([0, 0, { attribute_id: existingAttrMap['Presentacin'], value_ids: [[6, 0, presValIds]] }]);
                
                if (customAttributes) {
                    for (let attr of customAttributes) {
                        if (!attr.name || !attr.name.trim() || !attr.values || attr.values.length === 0) continue;
                        const attrId = existingAttrMap[attr.name.trim()];
                        let valIds = [];
                        for (let v of attr.values) {
                            if (v.trim()) {
                                const vId = existingValMap[\`\${attrId}_\${v.trim()}\`];
                                if (vId) valIds.push(vId);
                            }
                        }
                        if (valIds.length > 0) ptalPayload.push([0, 0, { attribute_id: attrId, value_ids: [[6, 0, valIds]] }]);
                    }
                }
                
                const productDataPayload = {
                    name: name,
                    list_price: parseFloat(priceUnidad) || 0,
                    standard_price: parseFloat(cost) || 0,
                    sale_ok: true, purchase_ok: true, is_published: true,
                    is_storable: isStorable ? true : false,
                    seller_ids: [[0, 0, { partner_id: item.partner_id, delay: 1 }]],
                    attribute_line_ids: ptalPayload
                };
                if (categoryId) productDataPayload.public_categ_ids = [[6, 0, [parseInt(categoryId)]]];
                
                const tmplId = await executeKw('product.template', 'create', [productDataPayload]);
                
                if (imageBase64) {
                    const rawB64 = imageBase64.split(',')[1] || imageBase64;
                    await executeKw('product.template', 'write', [[tmplId], { image_1920: rawB64 }]);
                }
                
                const pricelistPayload = [];
                if (priceDocena) pricelistPayload.push({ pricelist_id: 3, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceDocena) });
                if (priceBulto) pricelistPayload.push({ pricelist_id: 2, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceBulto) });
                for (let pl of pricelistPayload) {
                    await executeKw('product.pricelist.item', 'create', [pl]);
                }
                
                const vRes = await pool.query("SELECT variants FROM queue_variants WHERE product_id = $1", [tempId]);
                const fakeVariants = vRes.rows.length > 0 ? vRes.rows[0].variants : [];
                
                if (fakeVariants.length > 0) {
                    const odooVariants = await executeKw('product.product', 'search_read', [[['product_tmpl_id', '=', tmplId]], ['id', 'product_template_attribute_value_ids']]);
                    
                    const allPtavIds = new Set();
                    odooVariants.forEach(v => {
                        if (v.product_template_attribute_value_ids) v.product_template_attribute_value_ids.forEach(id => allPtavIds.add(id));
                    });
                    const ptavMap = {};
                    if (allPtavIds.size > 0) {
                        const ptavs = await executeKw('product.template.attribute.value', 'search_read', [[['id', 'in', [...allPtavIds]]], ['id', 'name']]);
                        ptavs.forEach(pt => ptavMap[pt.id] = pt.name);
                    }
                    
                    let stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'WH/']]], { fields: ['id'], limit: 1 });
                    if (stockLocations.length === 0) stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'PT/']]], { fields: ['id'], limit: 1 });
                    if (stockLocations.length === 0) stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal']]], { fields: ['id'], limit: 1 });
                    const locId = stockLocations.length > 0 ? stockLocations[0].id : null;

                    for (let ov of odooVariants) {
                        let ovName = "Variante Base";
                        if (ov.product_template_attribute_value_ids && ov.product_template_attribute_value_ids.length > 0) {
                            ovName = ov.product_template_attribute_value_ids.map(id => ptavMap[id] || '').filter(Boolean).join(' / ');
                        }
                        
                        const matchFake = fakeVariants.find(fv => fv.attribute_names === ovName || ovName.includes(fv.attribute_names) || fv.attribute_names.includes(ovName));
                        
                        if (matchFake) {
                            if (matchFake.stock_updated && matchFake.qty_available > 0 && locId) {
                                const quantId = await executeKw('stock.quant', 'create', [{ product_id: ov.id, location_id: locId, inventory_quantity: matchFake.qty_available }]);
                                try { await executeKw('stock.quant', 'action_apply_inventory', [[quantId]]); } catch(e){}
                            }
                            if (matchFake.image_updated && matchFake.image_variant_1920) {
                                await executeKw('product.product', 'write', [[ov.id], { image_1920: matchFake.image_variant_1920 }]);
                            }
                        }
                    }
                }
                
                await pool.query("UPDATE queue_products SET status = 'done', data = jsonb_set(data, '{odooId}', $1) WHERE id = $2", [tmplId, tempId]);
                console.log(\`[SYNC] Producto \${tempId} sincronizado exitosamente.\`);
            } catch (syncErr) {
                console.error(\`[SYNC] Error con \${tempId}:\`, syncErr);
                await pool.query("UPDATE queue_products SET status = 'error', data = jsonb_set(data, '{error}', $1) WHERE id = $2", [JSON.stringify(syncErr.message), tempId]);
            }
        }
    } catch (err) {
        console.error("Queue loop error:", err);
    }
}

setInterval(processQueue, 15000);`);

fs.writeFileSync('backend/server.js', code, 'utf8');
console.log("Migration script complete.");
