const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const newRoutes = `
// GET full product details for edit
app.get('/api/supplier/products/:id', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const tmplId = parseInt(req.params.id);
        
        // Security check
        const supplierInfos = await executeKw('product.supplierinfo', 'search_count', [[['partner_id', '=', req.user.id], ['product_tmpl_id', '=', tmplId]]]);
        if (supplierInfos === 0) return res.status(403).json({ error: "Access denied" });
        
        const products = await executeKw('product.template', 'search_read', [
            [['id', '=', tmplId]], 
            ['name', 'standard_price', 'list_price', 'public_categ_ids', 'is_storable', 'image_1920']
        ]);
        if (products.length === 0) return res.status(404).json({ error: "Not found" });
        
        const p = products[0];
        
        // Fetch pricelists
        const pricelists = await executeKw('product.pricelist.item', 'search_read', [
            [['product_tmpl_id', '=', tmplId], ['pricelist_id', 'in', [2, 3]]]
        ], { fields: ['pricelist_id', 'fixed_price'] });
        
        let priceDocena = "";
        let priceBulto = "";
        pricelists.forEach(pl => {
            if (pl.pricelist_id[0] === 3) priceDocena = pl.fixed_price; // 3 = Docena
            if (pl.pricelist_id[0] === 2) priceBulto = pl.fixed_price;  // 2 = Bulto
        });
        
        // Fetch variants and their stock
        const variants = await executeKw('product.product', 'search_read', [
            [['product_tmpl_id', '=', tmplId]],
            ['id', 'product_template_attribute_value_ids', 'qty_available', 'image_variant_1920']
        ]);
        
        for (let v of variants) {
            if (v.product_template_attribute_value_ids.length > 0) {
                const ptavs = await executeKw('product.template.attribute.value', 'search_read', [
                    [['id', 'in', v.product_template_attribute_value_ids]],
                    ['name', 'attribute_id']
                ]);
                v.attribute_names = ptavs.map(pt => pt.name).join(' / ');
            } else {
                v.attribute_names = "Variante Base";
            }
        }
        
        res.json({ success: true, product: {
            id: p.id,
            name: p.name,
            cost: p.standard_price,
            priceUnidad: p.list_price,
            categoryId: p.public_categ_ids && p.public_categ_ids.length > 0 ? p.public_categ_ids[0] : "",
            isStorable: p.is_storable,
            priceDocena: priceDocena,
            priceBulto: priceBulto,
            imageBase64: p.image_1920,
            variants: variants
        }});
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Edit Product Full
app.post('/api/supplier/products/:id/edit', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const tmplId = parseInt(req.params.id);
        const { name, cost, priceUnidad, priceDocena, priceBulto, categoryId, isStorable, imageBase64 } = req.body;
        
        const supplierInfos = await executeKw('product.supplierinfo', 'search_count', [[['partner_id', '=', req.user.id], ['product_tmpl_id', '=', tmplId]]]);
        if (supplierInfos === 0) return res.status(403).json({ error: "Access denied" });
        
        const writeData = {
            name: name,
            standard_price: parseFloat(cost) || 0,
            list_price: parseFloat(priceUnidad) || 0,
            is_storable: isStorable ? true : false
        };
        
        if (categoryId) {
            writeData.public_categ_ids = [[6, 0, [parseInt(categoryId)]]];
        }
        
        if (imageBase64) {
            writeData.image_1920 = imageBase64.split(',')[1] || imageBase64;
        }
        
        await executeKw('product.template', 'write', [[tmplId], writeData]);
        
        // Handle Pricelists
        async function updatePricelist(plId, price) {
            const existing = await executeKw('product.pricelist.item', 'search_read', [[['product_tmpl_id', '=', tmplId], ['pricelist_id', '=', plId]]], { limit: 1 });
            if (price) {
                if (existing.length > 0) {
                    await executeKw('product.pricelist.item', 'write', [[existing[0].id], { fixed_price: parseFloat(price) }]);
                } else {
                    await executeKw('product.pricelist.item', 'create', [{ pricelist_id: plId, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(price) }]);
                }
            } else {
                if (existing.length > 0) {
                    await executeKw('product.pricelist.item', 'unlink', [[existing[0].id]]);
                }
            }
        }
        
        await updatePricelist(3, priceDocena); // 3 = Docena
        await updatePricelist(2, priceBulto);  // 2 = Bulto
        
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update Variant Stock
app.post('/api/supplier/variants/:variantId/stock', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const variantId = parseInt(req.params.variantId);
        const { qty } = req.body;
        
        if (qty === undefined || qty === null) return res.status(400).json({ error: "No quantity provided" });
        
        const stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal']]], { fields: ['id'], limit: 1 });
        if (stockLocations.length === 0) return res.status(500).json({ error: "No internal stock location found in Odoo" });
        const locId = stockLocations[0].id;
        
        const existingQuant = await executeKw('stock.quant', 'search_read', [[['product_id', '=', variantId], ['location_id', '=', locId]]], { fields: ['id'], limit: 1 });
        
        if (existingQuant.length > 0) {
            await executeKw('stock.quant', 'write', [[existingQuant[0].id], { inventory_quantity: parseFloat(qty) }]);
            await executeKw('stock.quant', 'action_apply_inventory', [[existingQuant[0].id]]);
        } else {
            const quantId = await executeKw('stock.quant', 'create', [{ product_id: variantId, location_id: locId, inventory_quantity: parseFloat(qty) }]);
            await executeKw('stock.quant', 'action_apply_inventory', [[quantId]]);
        }
        
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
`;

// Replace old quick edit route
const startEditMarker = "// Edit Product";
const endEditMarker = "// Toggle Publish Status";

const startIndex = serverJs.indexOf(startEditMarker);
const endIndex = serverJs.indexOf(endEditMarker);

if (startIndex !== -1 && endIndex !== -1) {
    serverJs = serverJs.substring(0, startIndex) + newRoutes + "\n" + serverJs.substring(endIndex);
} else {
    // If we can't find old edit, just append
    serverJs = serverJs.replace("// Categories endpoint", newRoutes + "\n// Categories endpoint");
}

// Ensure `isStorable` is supported in creation route
serverJs = serverJs.replace('const { name, cost, priceUnidad, priceDocena, priceBulto, categoryId, customAttributes, imageBase64 } = req.body;', 'const { name, cost, priceUnidad, priceDocena, priceBulto, categoryId, customAttributes, imageBase64, isStorable } = req.body;');
serverJs = serverJs.replace('is_published: true,', 'is_published: true,\n            is_storable: isStorable ? true : false,');

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Backend updated successfully.");
