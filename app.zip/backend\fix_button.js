const fs = require('fs');
let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// Fix the corrupted openEditModal button
// Current bad string: <button onclick="openEditModal(${p.id}).replace(/\"/g, '&quot;')}', ${p.standard_price}, ${p.list_price})" class="btn"
html = html.replace(/<button onclick="openEditModal\(\$\{p\.id\}\)\.replace.*?<\/button>/g, `<button onclick="openEditModal(\${p.id})" class="btn" style="background:#e0f2fe; color:#0284c7; padding:6px 12px; font-size:0.8rem;" title="Editar"><ion-icon name="create-outline"></ion-icon></button>`);

// Just in case it matches differently
html = html.replace(/openEditModal\(\$\{p\.id\}\)\.replace[^"]*"/g, 'openEditModal(${p.id})"');

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("Button fixed.");
