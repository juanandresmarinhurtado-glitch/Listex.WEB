const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

common.methodCall('authenticate', [db, username, password, {}], function (error, uid) {
    if (error) return console.error(error);

    // Create custom view
    const viewData = {
        name: 'proveedores.pendientes.list',
        type: 'list', // list view (tree)
        model: 'res.partner',
        arch_base: `
            <list string="Proveedores">
                <field name="name"/>
                <field name="email"/>
                <field name="phone"/>
                <field name="x_studio_supplier_rif"/>
                <field name="x_studio_supplier_status" widget="badge"/>
            </list>
        `
    };

    models.methodCall('execute_kw', [db, uid, password, 'ir.ui.view', 'create', [viewData]], function (err, viewId) {
        if (err) return console.error("View Error:", err);
        console.log("Created View ID:", viewId);

        // Link view to action 3046
        models.methodCall('execute_kw', [db, uid, password, 'ir.actions.act_window', 'write', [[3046], { view_id: viewId }]], function (err, result) {
            if (err) return console.error("Action Update Error:", err);
            console.log("Updated Action 3046 with View ID:", result);
        });
    });
});
