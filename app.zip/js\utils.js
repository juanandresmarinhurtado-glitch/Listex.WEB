/* ==========================================================================
   LISTEX - Funciones de Utilidad
   Plataforma de e-commerce mayorista
   ========================================================================== */

/* ==========================================================================
   Formato de Precios
   ========================================================================== */

/**
 * Formatea un número como precio en dólares estadounidenses.
 * @param {number|string} price - Precio a formatear
 * @returns {string} - Precio formateado (ej: '$6.90')
 */
function formatPrice(price) {
  // --- Convertir a número si es string ---
  var numericPrice = parseFloat(price);

  // --- Verificar que sea un número válido ---
  if (isNaN(numericPrice)) {
    return '$0.00';
  }

  // --- Formatear con 2 decimales y símbolo de dólar ---
  return '$' + numericPrice.toFixed(2);
}

/* ==========================================================================
   Notificaciones Toast
   ========================================================================== */

/**
 * Muestra una notificación toast en la esquina superior derecha.
 * Se oculta automáticamente después de 3 segundos.
 * @param {string} message - Mensaje a mostrar
 * @param {string} [type='success'] - Tipo de toast: 'success', 'error', 'warning'
 */
function showToast(message, type) {
  // --- Valor por defecto del tipo ---
  if (!type) {
    type = 'success';
  }

  // --- Obtener o crear el contenedor de toasts ---
  var container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  // --- Determinar ícono y clase según el tipo ---
  var iconSvg = '';
  var toastClass = 'toast';

  if (type === 'success') {
    iconSvg = '<svg class="toast-icon success" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>';
  } else if (type === 'error') {
    iconSvg = '<svg class="toast-icon error" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>';
    toastClass += ' toast-error';
  } else if (type === 'warning') {
    iconSvg = '<svg class="toast-icon warning" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';
    toastClass += ' toast-warning';
  }

  // --- Crear el elemento toast ---
  var toast = document.createElement('div');
  toast.className = toastClass;
  toast.innerHTML = iconSvg +
    '<span class="toast-message">' + message + '</span>' +
    '<button class="toast-close" onclick="this.parentElement.classList.remove(\'show\'); setTimeout(function() { this.parentElement.remove(); }.bind(this), 300);">' +
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
    '</button>';

  // --- Agregar al contenedor ---
  container.appendChild(toast);

  // --- Mostrar con animación (pequeño delay para activar la transición) ---
  requestAnimationFrame(function() {
    requestAnimationFrame(function() {
      toast.classList.add('show');
    });
  });

  // --- Ocultar automáticamente después de 3 segundos ---
  setTimeout(function() {
    toast.classList.remove('show');
    // --- Eliminar del DOM después de la animación ---
    setTimeout(function() {
      if (toast.parentElement) {
        toast.remove();
      }
    }, 300);
  }, 3000);
}

/* ==========================================================================
   Utilidad Debounce
   ========================================================================== */

/**
 * Crea una versión retrasada de una función que solo se ejecuta
 * después de un periodo de inactividad.
 * Útil para búsquedas en tiempo real, resize, scroll, etc.
 * @param {function} fn - Función a ejecutar
 * @param {number} delay - Milisegundos de espera
 * @returns {function} - Función con debounce aplicado
 */
function debounce(fn, delay) {
  var timeoutId = null;

  return function() {
    var context = this;
    var args = arguments;

    // --- Cancelar el timeout anterior ---
    if (timeoutId) {
      clearTimeout(timeoutId);
    }

    // --- Programar nueva ejecución ---
    timeoutId = setTimeout(function() {
      fn.apply(context, args);
    }, delay);
  };
}

/* ==========================================================================
   Utilidad Slugify
   ========================================================================== */

/**
 * Convierte un texto a formato slug para URLs amigables.
 * Elimina acentos, caracteres especiales y espacios.
 * @param {string} text - Texto a convertir
 * @returns {string} - Slug resultante (ej: 'remera-basica-algodon')
 */
function slugify(text) {
  if (!text || typeof text !== 'string') {
    return '';
  }

  return text
    .toString()
    .toLowerCase()
    .trim()
    // --- Reemplazar acentos y caracteres especiales ---
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    // --- Reemplazar ñ ---
    .replace(/ñ/g, 'n')
    // --- Reemplazar espacios y guiones múltiples ---
    .replace(/\s+/g, '-')
    // --- Eliminar caracteres no alfanuméricos ---
    .replace(/[^a-z0-9\-]/g, '')
    // --- Eliminar guiones duplicados ---
    .replace(/\-\-+/g, '-')
    // --- Eliminar guiones al inicio y final ---
    .replace(/^-+/, '')
    .replace(/-+$/, '');
}

/* ==========================================================================
   Capitalizar Primera Letra
   ========================================================================== */

/**
 * Capitaliza la primera letra de un texto.
 * @param {string} text - Texto a capitalizar
 * @returns {string} - Texto con primera letra en mayúscula
 */
function capitalizeFirst(text) {
  if (!text || typeof text !== 'string') {
    return '';
  }

  return text.charAt(0).toUpperCase() + text.slice(1);
}

/* ==========================================================================
   Funciones de LocalStorage
   ========================================================================== */

/**
 * Obtiene un valor del localStorage y lo parsea como JSON.
 * @param {string} key - Clave a buscar
 * @returns {*} - Valor parseado, o null si no existe o hay error
 */
function getFromStorage(key) {
  try {
    var item = localStorage.getItem(key);
    if (item === null) {
      return null;
    }
    return JSON.parse(item);
  } catch (error) {
    console.error('[Listex Utils] Error al leer de localStorage:', key, error);
    return null;
  }
}

/**
 * Guarda un valor en localStorage como JSON.
 * @param {string} key - Clave para almacenar
 * @param {*} value - Valor a almacenar (se serializa como JSON)
 */
function saveToStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('[Listex Utils] Error al guardar en localStorage:', key, error);
  }
}

/**
 * Elimina un valor del localStorage.
 * @param {string} key - Clave a eliminar
 */
function removeFromStorage(key) {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    console.error('[Listex Utils] Error al eliminar de localStorage:', key, error);
  }
}

/* ==========================================================================
   Generador de Enlace de WhatsApp
   ========================================================================== */

/**
 * Genera un enlace de WhatsApp con número y mensaje precargado.
 * @param {string} phone - Número de teléfono con código de país (ej: '5491112345678')
 * @param {string} message - Mensaje a precorporar
 * @returns {string} - URL de WhatsApp (https://wa.me/...)
 */
function generateWhatsAppLink(phone, message) {
  // --- Limpiar número de teléfono (solo dígitos) ---
  var cleanPhone = phone ? phone.toString().replace(/\D/g, '') : '';

  // --- Codificar el mensaje para URL ---
  var encodedMessage = message ? encodeURIComponent(message) : '';

  // --- Construir la URL ---
  var url = 'https://wa.me/' + cleanPhone;
  if (encodedMessage) {
    url += '?text=' + encodedMessage;
  }

  return url;
}

/* ==========================================================================
   Animaciones de Elementos
   ========================================================================== */

/**
 * Agrega una clase de animación CSS a un elemento y la remueve al finalizar.
 * Útil para animaciones de entrada, salida, resaltado, etc.
 * @param {HTMLElement} element - Elemento al que aplicar la animación
 * @param {string} animationClass - Clase CSS que contiene la animación
 */
function animateElement(element, animationClass) {
  if (!element || !animationClass) {
    return;
  }

  // --- Remover la clase si ya existe (para reiniciar la animación) ---
  element.classList.remove(animationClass);

  // --- Forzar reflow para reiniciar la animación ---
  void element.offsetWidth;

  // --- Agregar la clase de animación ---
  element.classList.add(animationClass);

  // --- Escuchar el fin de la animación para remover la clase ---
  function handleAnimationEnd() {
    element.classList.remove(animationClass);
    element.removeEventListener('animationend', handleAnimationEnd);
  }

  element.addEventListener('animationend', handleAnimationEnd);
}

/* ==========================================================================
   Librería de Íconos SVG
   ========================================================================== */

/**
 * Retorna un string SVG para el ícono solicitado.
 * Todos los íconos son de 24x24 con stroke, estilo Feather Icons.
 * @param {string} name - Nombre del ícono
 * @returns {string} - String HTML del SVG, o string vacío si no existe
 */
function createSVGIcon(name) {
  // --- Atributos base compartidos por todos los íconos ---
  var base = 'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24"';

  // --- Mapa de íconos disponibles ---
  var icons = {
    // --- Ícono de búsqueda (lupa) ---
    'search': '<svg ' + base + '>' +
      '<circle cx="11" cy="11" r="8"></circle>' +
      '<line x1="21" y1="21" x2="16.65" y2="16.65"></line>' +
      '</svg>',

    // --- Ícono de carrito de compras ---
    'cart': '<svg ' + base + '>' +
      '<circle cx="9" cy="21" r="1"></circle>' +
      '<circle cx="20" cy="21" r="1"></circle>' +
      '<path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>' +
      '</svg>',

    // --- Ícono de usuario ---
    'user': '<svg ' + base + '>' +
      '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>' +
      '<circle cx="12" cy="7" r="4"></circle>' +
      '</svg>',

    // --- Ícono de corazón (favoritos) ---
    'heart': '<svg ' + base + '>' +
      '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>' +
      '</svg>',

    // --- Ícono de corazón relleno (favorito activo) ---
    'heart-filled': '<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24">' +
      '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>' +
      '</svg>',

    // --- Ícono de filtro ---
    'filter': '<svg ' + base + '>' +
      '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon>' +
      '</svg>',

    // --- Ícono de WhatsApp ---
    'whatsapp': '<svg viewBox="0 0 24 24" fill="currentColor" width="24" height="24">' +
      '<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"></path>' +
      '</svg>',

    // --- Ícono de camión (envío) ---
    'truck': '<svg ' + base + '>' +
      '<rect x="1" y="3" width="15" height="13"></rect>' +
      '<polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>' +
      '<circle cx="5.5" cy="18.5" r="2.5"></circle>' +
      '<circle cx="18.5" cy="18.5" r="2.5"></circle>' +
      '</svg>',

    // --- Ícono de verificación (check) ---
    'check': '<svg ' + base + '>' +
      '<polyline points="20 6 9 17 4 12"></polyline>' +
      '</svg>',

    // --- Ícono de verificación con círculo ---
    'check-circle': '<svg ' + base + '>' +
      '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>' +
      '<polyline points="22 4 12 14.01 9 11.01"></polyline>' +
      '</svg>',

    // --- Ícono de estrella ---
    'star': '<svg ' + base + '>' +
      '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>' +
      '</svg>',

    // --- Ícono de estrella rellena ---
    'star-filled': '<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24">' +
      '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>' +
      '</svg>',

    // --- Ícono de flecha derecha ---
    'arrow-right': '<svg ' + base + '>' +
      '<line x1="5" y1="12" x2="19" y2="12"></line>' +
      '<polyline points="12 5 19 12 12 19"></polyline>' +
      '</svg>',

    // --- Ícono de flecha izquierda ---
    'arrow-left': '<svg ' + base + '>' +
      '<line x1="19" y1="12" x2="5" y2="12"></line>' +
      '<polyline points="12 19 5 12 12 5"></polyline>' +
      '</svg>',

    // --- Ícono de cerrar (X) ---
    'x': '<svg ' + base + '>' +
      '<line x1="18" y1="6" x2="6" y2="18"></line>' +
      '<line x1="6" y1="6" x2="18" y2="18"></line>' +
      '</svg>',

    // --- Ícono de menos (restar) ---
    'minus': '<svg ' + base + '>' +
      '<line x1="5" y1="12" x2="19" y2="12"></line>' +
      '</svg>',

    // --- Ícono de más (sumar) ---
    'plus': '<svg ' + base + '>' +
      '<line x1="12" y1="5" x2="12" y2="19"></line>' +
      '<line x1="5" y1="12" x2="19" y2="12"></line>' +
      '</svg>',

    // --- Ícono de paquete ---
    'package': '<svg ' + base + '>' +
      '<line x1="16.5" y1="9.4" x2="7.5" y2="4.21"></line>' +
      '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>' +
      '<polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>' +
      '<line x1="12" y1="22.08" x2="12" y2="12"></line>' +
      '</svg>',

    // --- Ícono de copiar ---
    'copy': '<svg ' + base + '>' +
      '<rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>' +
      '<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>' +
      '</svg>',

    // --- Ícono de enlace externo ---
    'external-link': '<svg ' + base + '>' +
      '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>' +
      '<polyline points="15 3 21 3 21 9"></polyline>' +
      '<line x1="10" y1="14" x2="21" y2="3"></line>' +
      '</svg>',

    // --- Ícono de menú hamburguesa ---
    'menu': '<svg ' + base + '>' +
      '<line x1="3" y1="12" x2="21" y2="12"></line>' +
      '<line x1="3" y1="6" x2="21" y2="6"></line>' +
      '<line x1="3" y1="18" x2="21" y2="18"></line>' +
      '</svg>',

    // --- Ícono de chevron abajo ---
    'chevron-down': '<svg ' + base + '>' +
      '<polyline points="6 9 12 15 18 9"></polyline>' +
      '</svg>',

    // --- Ícono de chevron arriba ---
    'chevron-up': '<svg ' + base + '>' +
      '<polyline points="18 15 12 9 6 15"></polyline>' +
      '</svg>',

    // --- Ícono de chevron derecha ---
    'chevron-right': '<svg ' + base + '>' +
      '<polyline points="9 18 15 12 9 6"></polyline>' +
      '</svg>',

    // --- Ícono de chevron izquierda ---
    'chevron-left': '<svg ' + base + '>' +
      '<polyline points="15 18 9 12 15 6"></polyline>' +
      '</svg>',

    // --- Ícono de ojo (vistas) ---
    'eye': '<svg ' + base + '>' +
      '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>' +
      '<circle cx="12" cy="12" r="3"></circle>' +
      '</svg>',

    // --- Ícono de etiqueta (oferta) ---
    'tag': '<svg ' + base + '>' +
      '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>' +
      '<line x1="7" y1="7" x2="7.01" y2="7"></line>' +
      '</svg>',

    // --- Ícono de teléfono ---
    'phone': '<svg ' + base + '>' +
      '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>' +
      '</svg>',

    // --- Ícono de correo electrónico ---
    'mail': '<svg ' + base + '>' +
      '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>' +
      '<polyline points="22,6 12,13 2,6"></polyline>' +
      '</svg>',

    // --- Ícono de ubicación (mapa) ---
    'map-pin': '<svg ' + base + '>' +
      '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>' +
      '<circle cx="12" cy="10" r="3"></circle>' +
      '</svg>',

    // --- Ícono de reloj ---
    'clock': '<svg ' + base + '>' +
      '<circle cx="12" cy="12" r="10"></circle>' +
      '<polyline points="12 6 12 12 16 14"></polyline>' +
      '</svg>',

    // --- Ícono de escudo (seguridad) ---
    'shield': '<svg ' + base + '>' +
      '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>' +
      '</svg>',

    // --- Ícono de escudo con check ---
    'shield-check': '<svg ' + base + '>' +
      '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>' +
      '<polyline points="9 12 11.5 14.5 15.5 10.5"></polyline>' +
      '</svg>',

    // --- Ícono de porcentaje (descuento) ---
    'percent': '<svg ' + base + '>' +
      '<line x1="19" y1="5" x2="5" y2="19"></line>' +
      '<circle cx="6.5" cy="6.5" r="2.5"></circle>' +
      '<circle cx="17.5" cy="17.5" r="2.5"></circle>' +
      '</svg>',

    // --- Ícono de compartir ---
    'share': '<svg ' + base + '>' +
      '<circle cx="18" cy="5" r="3"></circle>' +
      '<circle cx="6" cy="12" r="3"></circle>' +
      '<circle cx="18" cy="19" r="3"></circle>' +
      '<line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>' +
      '<line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>' +
      '</svg>',

    // --- Ícono de imagen ---
    'image': '<svg ' + base + '>' +
      '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>' +
      '<circle cx="8.5" cy="8.5" r="1.5"></circle>' +
      '<polyline points="21 15 16 10 5 21"></polyline>' +
      '</svg>',

    // --- Ícono de información ---
    'info': '<svg ' + base + '>' +
      '<circle cx="12" cy="12" r="10"></circle>' +
      '<line x1="12" y1="16" x2="12" y2="12"></line>' +
      '<line x1="12" y1="8" x2="12.01" y2="8"></line>' +
      '</svg>',

    // --- Ícono de papelera (eliminar) ---
    'trash': '<svg ' + base + '>' +
      '<polyline points="3 6 5 6 21 6"></polyline>' +
      '<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>' +
      '<line x1="10" y1="11" x2="10" y2="17"></line>' +
      '<line x1="14" y1="11" x2="14" y2="17"></line>' +
      '</svg>',

    // --- Ícono de editar (lápiz) ---
    'edit': '<svg ' + base + '>' +
      '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>' +
      '<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>' +
      '</svg>',

    // --- Ícono de descarga ---
    'download': '<svg ' + base + '>' +
      '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>' +
      '<polyline points="7 10 12 15 17 10"></polyline>' +
      '<line x1="12" y1="15" x2="12" y2="3"></line>' +
      '</svg>',

    // --- Ícono de grid (cuadrícula) ---
    'grid': '<svg ' + base + '>' +
      '<rect x="3" y="3" width="7" height="7"></rect>' +
      '<rect x="14" y="3" width="7" height="7"></rect>' +
      '<rect x="14" y="14" width="7" height="7"></rect>' +
      '<rect x="3" y="14" width="7" height="7"></rect>' +
      '</svg>',

    // --- Ícono de lista ---
    'list': '<svg ' + base + '>' +
      '<line x1="8" y1="6" x2="21" y2="6"></line>' +
      '<line x1="8" y1="12" x2="21" y2="12"></line>' +
      '<line x1="8" y1="18" x2="21" y2="18"></line>' +
      '<line x1="3" y1="6" x2="3.01" y2="6"></line>' +
      '<line x1="3" y1="12" x2="3.01" y2="12"></line>' +
      '<line x1="3" y1="18" x2="3.01" y2="18"></line>' +
      '</svg>'
  };

  // --- Retornar el ícono solicitado o string vacío ---
  if (icons[name]) {
    return icons[name];
  }

  console.warn('[Listex Utils] Ícono no encontrado:', name);
  return '';
}
