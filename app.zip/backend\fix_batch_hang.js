const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

// Replace the batch create for pricelists
serverJs = serverJs.replace(
    /if \(pricelistPayload\.length > 0\) \{\s*await executeKw\('product\.pricelist\.item', 'create', \[pricelistPayload\]\);\s*\}/,
    `for (let pl of pricelistPayload) {
            await executeKw('product.pricelist.item', 'create', [pl]);
        }`
);

// Replace the batch create for attribute lines
serverJs = serverJs.replace(
    /if \(ptalPayload\.length > 0\) \{\s*await executeKw\('product\.template\.attribute\.line', 'create', \[ptalPayload\]\);\s*\}/,
    `for (let ptal of ptalPayload) {
            await executeKw('product.template.attribute.line', 'create', [ptal]);
        }`
);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Fixed batching hanging by using sequential for the final 2 models.");
