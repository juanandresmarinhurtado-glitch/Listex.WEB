const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        const tmplId = await executeKw('product.template', 'create', [{ name: "Test Batch Product", list_price: 10 }]);
        console.log("Created tmpl:", tmplId);
        
        const ptalPayload = [
            { product_tmpl_id: tmplId, attribute_id: 39, value_ids: [[6, 0, [49]]] },
        ];
        
        console.log("Sending ptalPayload");
        const ptalIds = await executeKw('product.template.attribute.line', 'create', [ptalPayload]);
        console.log("Created ptal:", ptalIds);
        
    } catch (e) {
        console.error("Test Error:", e);
    }
});
