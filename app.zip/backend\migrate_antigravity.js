// Migrar antigravity a nueva estrategia: Tipo de Venta + variante Surtido
const xmlrpc = require('xmlrpc');
const models = xmlrpc.createSecureClient({ host:'listex.odoo.com', port:443, path:'/xmlrpc/2/object', timeout:120000 });
const DB='listex', PASS='Seguridad400%', UID=2;
function odoo(m,mt,a,k={}) { return new Promise((r,j)=>{ models.methodCall('execute_kw',[DB,UID,PASS,m,mt,a,k],(e,res)=>{ if(e) return j(e); r(res); }); }); }

const tmplId = 1502; // antigravity

function calcPrecios(item) {
    const detalUsd  = parseFloat(item.x_web3_detal_usd) || 0;
    const comboUsd  = parseFloat(item.x_web3_combo_usd) || 0;
    const docenaUsd = parseFloat(item.x_web3_docena_usd) || 0;
    const bultoUsd  = parseFloat(item.x_web3_bulto_usd) || 0;
    const comboPiezas = parseInt(item.x_web3_combo_piezas) || 3;
    const bultoPiezas = parseInt(item.x_web3_bulto_piezas) || 13;
    return {
        detalUsd, comboUsd, comboPiezas,
        comboPieza:  comboPiezas > 0 ? Math.round((comboUsd/comboPiezas)*100)/100 : comboUsd,
        docenaUsd, docenaPieza: Math.round((docenaUsd/12)*100)/100,
        bultoUsd, bultoPiezas,
        bultoPieza: bultoPiezas > 0 ? Math.round((bultoUsd/bultoPiezas)*100)/100 : bultoUsd,
    };
}

async function run() {
    console.log('=== MIGRANDO ANTIGRAVITY (1502) ===\n');

    // Leer estado actual
    const attrLines = await odoo('product.template.attribute.line','search_read',[
        [['product_tmpl_id','=',tmplId]]
    ],{fields:['id','attribute_id','value_ids']});
    console.log('Atributos actuales:');
    for (const al of attrLines) {
        const vals = await odoo('product.attribute.value','read',[al.value_ids],{fields:['name']});
        console.log(' -', al.attribute_id[1]+':', vals.map(v=>v.name).join(', '));
    }

    // PASO 1: Tipo de Venta (no_variant) con Unidad + surtidos
    console.log('\nPASO 1: Tipo de Venta (no_variant)...');
    let tvAttrs = await odoo('product.attribute','search_read',[[['name','=','Tipo de Venta']]],{fields:['id']});
    const tvAttrId = tvAttrs.length > 0 ? tvAttrs[0].id : await odoo('product.attribute','create',[{name:'Tipo de Venta',create_variant:'no_variant'}]);
    try { await odoo('product.attribute','write',[[tvAttrId],{create_variant:'no_variant'}]); } catch(e){}
    console.log('  ID:', tvAttrId);

    const tvValueNames = ['Unidad', 'Docena (surtido)', 'Bulto (surtido)', 'Combo (surtido)'];
    const tvValIds = [];
    for (const vName of tvValueNames) {
        let ex = await odoo('product.attribute.value','search_read',[
            [['attribute_id','=',tvAttrId],['name','=',vName]]
        ],{fields:['id']});
        const vid = ex.length > 0 ? ex[0].id : await odoo('product.attribute.value','create',[{name:vName,attribute_id:tvAttrId}]);
        tvValIds.push(vid);
        console.log('  Valor:', vName, '→ ID:', vid);
    }

    // Agregar/actualizar línea Tipo de Venta
    const tvLine = attrLines.find(l=>l.attribute_id[0]===tvAttrId);
    if (!tvLine) {
        await odoo('product.template','write',[[tmplId],{
            attribute_line_ids:[[0,0,{attribute_id:tvAttrId,value_ids:[[6,0,tvValIds]]}]]
        }]);
        console.log('  ✓ Línea Tipo de Venta CREADA');
    } else {
        await odoo('product.template.attribute.line','write',[[tvLine.id],{value_ids:[[6,0,tvValIds]]}]);
        console.log('  ✓ Línea Tipo de Venta ACTUALIZADA');
    }

    // PASO 2: Agregar "Surtido" a Color y Talla para crear variante surtida universal
    console.log('\nPASO 2: Agregar valor Surtido a atributos...');
    for (const al of attrLines) {
        const attrName = al.attribute_id[1];
        if (al.attribute_id[0] === tvAttrId) continue; // skip Tipo de Venta
        const attrId = al.attribute_id[0];
        let surtidoVal = await odoo('product.attribute.value','search_read',[
            [['attribute_id','=',attrId],['name','=','Surtido']]
        ],{fields:['id']});
        const surtidoId = surtidoVal.length > 0 ? surtidoVal[0].id : await odoo('product.attribute.value','create',[{name:'Surtido',attribute_id:attrId}]);
        console.log(' ', attrName, '→ Surtido ID:', surtidoId);
        const newValIds = [...new Set([...al.value_ids, surtidoId])];
        await odoo('product.template.attribute.line','write',[[al.id],{value_ids:[[6,0,newValIds]]}]);
        console.log('  ✓ Valor Surtido agregado a', attrName);
    }

    // PASO 3: Ver variantes generadas
    await new Promise(r=>setTimeout(r,3000));
    const variants = await odoo('product.product','search_read',[
        [['product_tmpl_id','=',tmplId],['active','=',true]]
    ],{fields:['id','display_name','product_template_attribute_value_ids']});
    console.log('\nPASO 3: Variantes ('+variants.length+'):');

    // Leer PTAVs para identificar surtido
    const allPtavIds = new Set();
    variants.forEach(v=>v.product_template_attribute_value_ids.forEach(id=>allPtavIds.add(id)));
    const ptavData = allPtavIds.size > 0 ? await odoo('product.template.attribute.value','search_read',[
        [['id','in',[...allPtavIds]]]
    ],{fields:['id','name','attribute_id']}) : [];
    const ptavById = {};
    ptavData.forEach(p=>{ ptavById[p.id]=p; });

    const item1502 = {
        x_web3_detal_usd:25, x_web3_cost_usd:10,
        x_web3_combo_habilitado:true, x_web3_combo_usd:50, x_web3_combo_piezas:3, x_web3_combo_surtido:false,
        x_web3_docena_habilitado:true, x_web3_docena_usd:180, x_web3_docena_surtido:true,
        x_web3_bulto_habilitado:true, x_web3_bulto_usd:182, x_web3_bulto_piezas:13, x_web3_bulto_surtido:true,
    };
    const precios = calcPrecios(item1502);
    console.log('\nPrecios calculados:');
    console.log('  Detal: $'+precios.detalUsd+' (cada variante normal)');
    console.log('  Combo: $'+precios.comboUsd+' / '+precios.comboPiezas+' piezas = $'+precios.comboPieza+' c/u');
    console.log('  Docena surtida: $'+precios.docenaUsd+' (variante surtido, completo)');
    console.log('  Bulto surtido: $'+precios.bultoUsd+' (variante surtido, completo)');

    // PASO 4: Asignar PL por variante
    console.log('\nPASO 4: Asignando PL por variante...');
    for (const v of variants) {
        const ptavs = v.product_template_attribute_value_ids.map(id=>ptavById[id]).filter(p=>p);
        // Excluir Tipo de Venta para determinar si es surtido
        const variantPtavs = ptavs.filter(p=>p.name!=='Unidad' && !['Combo (surtido)','Docena (surtido)','Bulto (surtido)'].includes(p.name));
        const isSurtido = variantPtavs.length>0 && variantPtavs.every(p=>p.name.toLowerCase()==='surtido');

        const plEntries = [];
        if (isSurtido) {
            if (item1502.x_web3_docena_habilitado && item1502.x_web3_docena_surtido) plEntries.push([11, precios.docenaUsd]);
            if (item1502.x_web3_bulto_habilitado  && item1502.x_web3_bulto_surtido)  plEntries.push([12, precios.bultoUsd]);
        } else {
            plEntries.push([9, precios.detalUsd]);
            if (item1502.x_web3_combo_habilitado && !item1502.x_web3_combo_surtido) plEntries.push([10, precios.comboPieza]);
        }

        // Costo
        try { await odoo('product.product','write',[[v.id],{standard_price:precios.detalUsd>0?item1502.x_web3_cost_usd:0}]); } catch(e){}

        for (const [plId, price] of plEntries) {
            const ex = await odoo('product.pricelist.item','search_read',[
                [['pricelist_id','=',plId],['product_id','=',v.id]]
            ],{fields:['id']});
            if (ex.length>0) {
                await odoo('product.pricelist.item','write',[[ex[0].id],{fixed_price:price}]);
            } else {
                await odoo('product.pricelist.item','create',[{pricelist_id:plId,applied_on:'0_product_variant',product_id:v.id,compute_price:'fixed',fixed_price:price}]);
            }
        }
        const tag = isSurtido ? '[SURTIDO]' : '[normal]';
        console.log('  '+v.id, v.display_name.substring(0,50), tag, plEntries.map(([pl,p])=>'PL'+pl+'=$'+p).join(', '));
    }

    // PASO 5: DATA WEB 3
    console.log('\nPASO 5: Ejecutando DATA WEB 3...');
    await odoo('ir.actions.server','run',[[3047]]);
    console.log('  ✓ JSON v3 actualizado');

    console.log('\n=== MIGRACIÓN COMPLETADA ===');
}
run().catch(e=>{ console.error('ERR:',e.message); if(e.faultString) console.error(e.faultString.substring(0,600)); });
