const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { executeKw } = require('../services/odooApi');
const { pool } = require('../db/init');

const JWT_SECRET = process.env.JWT_SECRET || 'mi_clave_secreta_super_segura';

router.post('/register', async (req, res) => {
    try {
        const { name, email, phone, address, rif, password } = req.body;
        
        if (!name || !email || !password) {
            return res.status(400).json({ error: "Name, email and password are required" });
        }

        const existing = await executeKw('res.partner', 'search', [[['email', '=', email]]]);
        if (existing.length > 0) {
            return res.status(400).json({ error: "Email already registered" });
        }

        const partnerData = {
            name: name,
            email: email,
            phone: phone || '',
            street: address || '',
            x_studio_is_portal_supplier: true,
            x_studio_supplier_status: 'pending',
            x_studio_portal_password: password,
            x_studio_supplier_rif: rif || ''
        };

        const newPartnerId = await executeKw('res.partner', 'create', [partnerData]);
        res.json({ success: true, message: "Registrado correctamente. En espera de aprobación.", id: newPartnerId });
    } catch (error) {
        console.error("[AUTH] Register Error:", error);
        res.status(500).json({ error: error.message || String(error) });
    }
});

router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) return res.status(400).json({ error: "Email and password required" });

        const partners = await executeKw('res.partner', 'search_read', [
            [['email', '=', email], ['x_studio_portal_password', '=', password]]
        ], { fields: ['id', 'name', 'x_studio_supplier_status', 'x_studio_is_portal_supplier'] });

        if (partners.length === 0) {
            return res.status(401).json({ error: "Credenciales incorrectas" });
        }

        const partner = partners[0];
        if (partner.x_studio_supplier_status !== 'approved') {
            return res.status(403).json({ error: "Tu cuenta de proveedor aún está pendiente de aprobación." });
        }

        // Save or update in local PostgreSQL cache (non-blocking, optional)
        pool.query(
            "INSERT INTO suppliers (id, name, email, last_sync) VALUES ($1, $2, $3, $4) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name",
            [partner.id, partner.name, email, Date.now()]
        ).catch(dbErr => {
            console.error("[AUTH] DB cache error (non-fatal):", dbErr.message);
        });

        const token = jwt.sign(
            { id: partner.id, name: partner.name, email: email },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        res.json({
            success: true,
            token,
            user: { id: partner.id, name: partner.name, email: email }
        });
    } catch (error) {
        console.error("[AUTH] Login Error:", error);
        res.status(500).json({ error: error.message || String(error) });
    }
});

module.exports = router;
