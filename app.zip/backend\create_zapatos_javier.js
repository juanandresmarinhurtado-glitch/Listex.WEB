/**
 * Crea los productos de zapatos de Javier Serrano (partner 5167) en Odoo
 * Lee las imágenes de la carpeta zapatos, agrupa por modelo, calcula precios y crea en Odoo
 * Sigue exactamente la misma lógica que el portal de proveedores
 */
const fs = require('fs');
const path = require('path');
const xmlrpc = require('xmlrpc');
const { ensureTipoVentaAttr, setVariantPricelists } = require('./services/odooSyncHelpers');

const models_client = xmlrpc.createSecureClient({ host:'listex.odoo.com', port:443, path:'/xmlrpc/2/object', timeout:120000 });
const DB='listex', PASS='Seguridad400%', UID=2;
function odoo(m,mt,a,k={}) { return new Promise((r,j)=>{ models_client.methodCall('execute_kw',[DB,UID,PASS,m,mt,a,k],(e,res)=>{ if(e) return j(e); r(res); }); }); }

const JAVIER_ID = 5167;
const ZAPATOS_DIR = 'C:\\Users\\juan\\Documents\\catalogo web\\zapatos';
const SUBFOLDERS = ['', 'zapato brillante', 'zapatos niños'];

// ── Prefijos de modelos en orden de precedencia (más específico primero) ──────
// IMPORTANTE: Más específicos primero; "Zapatos*" antes que "Zapato" para evitar captura prematura
const MODEL_PREFIXES = [
    'Adidas Samba','Adidas',
    'Asics',
    'Bota Casual','Bota Caterpillar','Bota Timberland',
    'Caterpillar',
    'Deportivo Dior','Deportivo QC','Deportivo',
    'New Balance',
    'Nike Air Force','Nike Airmax','Nike Shox','Nike Zoomx','Nike Zoom','Nike',
    'Puma',
    'Reebok',
    'Sandalias Nike Mind',
    'Timberland',
    'Tommy Hilfiger',
    'Vans',
    // Zapatos* ANTES que Zapato para evitar captura incorrecta
    'Zapato Brillante','Zapato Negro Ancho Estilo Skate',
    'Zapatos Anchos','Zapatos DC','Zapatos Infantiles',
    'Zapatos Minnie Mouse','Zapatos Paw Patrol','Zapatos Spiderman','Zapatos Skate',
    'Zapatos', 'Zapato',
];

// ── Fórmulas de precio (siempre redondear hacia arriba) ───────────────────────
function ceilPrice(v) { return Math.ceil(v * 100) / 100; }

function calcPrecios(cost) {
    const detal     = ceilPrice(cost * 1.55);
    const comboPpu  = ceilPrice(cost * 1.45);  // precio por par en combo
    const docenaPpu = ceilPrice(cost * 1.35);  // precio por par en docena
    const bultoPpu  = ceilPrice(cost * 1.20);  // precio por par en bulto
    return {
        detal,
        combo:  Math.round(comboPpu  * 3  * 100) / 100,   // total 3 pares
        docena: Math.round(docenaPpu * 12 * 100) / 100,   // total 12 pares
        bulto:  Math.round(bultoPpu  * 13 * 100) / 100,   // total 13 pares
        comboPpu, docenaPpu, bultoPpu,
    };
}

// ── Parsear nombre de archivo ─────────────────────────────────────────────────
function parseFilename(filename) {
    // "Adidas Blanco Rayas Negras 1 - Costo $12.57.webp"
    const base = filename.replace(/\.webp$/i, '');
    const match = base.match(/^(.+?)\s*-\s*Costo\s*\$(\d+\.?\d*)/i);
    if (!match) return null;
    let fullName = match[1].trim();
    const cost = parseFloat(match[2]);
    // Quitar sufijos numéricos: " 1", " 2", " 3" al final del nombre
    const nameClean = fullName.replace(/\s+\d+$/, '').trim();
    return { fullName: nameClean, cost };
}

// ── Extraer modelo y color del nombre ─────────────────────────────────────────
function extractModelColor(fullName) {
    for (const prefix of MODEL_PREFIXES) {
        if (fullName.toLowerCase().startsWith(prefix.toLowerCase())) {
            const color = fullName.slice(prefix.length).trim();
            return { model: prefix, color: color || 'Único' };
        }
    }
    return { model: fullName, color: 'Único' };
}

// ── Leer todas las imágenes ────────────────────────────────────────────────────
function readAllImages() {
    const images = [];
    for (const sub of SUBFOLDERS) {
        const dir = sub ? path.join(ZAPATOS_DIR, sub) : ZAPATOS_DIR;
        if (!fs.existsSync(dir)) continue;
        const files = fs.readdirSync(dir).filter(f => f.endsWith('.webp') && !fs.statSync(path.join(dir,f)).isDirectory());
        for (const file of files) {
            const parsed = parseFilename(file);
            if (!parsed) continue;
            const { model, color } = extractModelColor(parsed.fullName);
            images.push({
                filepath: path.join(dir, file),
                filename: file,
                model, color, cost: parsed.cost,
                subfolder: sub || 'main',
            });
        }
    }
    return images;
}

// ── Agrupar por modelo ────────────────────────────────────────────────────────
function groupByModel(images) {
    const groups = {};
    for (const img of images) {
        const key = img.model;
        if (!groups[key]) {
            groups[key] = { model: img.model, cost: img.cost, variants: {}, subfolder: img.subfolder };
        }
        // Usar el primer costo encontrado como referencia
        const color = img.color || 'Único';
        // Evitar duplicados: si ya existe ese color, solo actualizar imagen si no hay una
        if (!groups[key].variants[color]) {
            groups[key].variants[color] = img.filepath;
        }
    }
    return groups;
}

// ── Convertir imagen a base64 ─────────────────────────────────────────────────
function imgToBase64(filepath) {
    try {
        const buf = fs.readFileSync(filepath);
        return buf.toString('base64');
    } catch(e) { return null; }
}

// ── Crear un grupo de producto en Odoo ────────────────────────────────────────
async function createProductGroup(group, catId, existingAttrMap, existingValMap) {
    const { model, cost, variants } = group;
    const colors = Object.keys(variants);
    const precios = calcPrecios(cost);

    console.log(`\n  → ${model} | costo:$${cost} | colores:${colors.length}`);
    console.log(`    Detal:$${precios.detal} | Combo(3):$${precios.combo} | Docena(12):$${precios.docena} | Bulto(13):$${precios.bulto}`);

    const web3 = {
        x_web3_detal_usd:          precios.detal,
        x_web3_cost_usd:           cost,
        x_web3_combo_habilitado:   true,
        x_web3_combo_usd:          precios.combo,
        x_web3_combo_piezas:       3,
        x_web3_combo_surtido:      false,   // cliente escoge colores en combo
        x_web3_docena_habilitado:  true,
        x_web3_docena_usd:         precios.docena,
        x_web3_docena_surtido:     false,   // cliente escoge colores en docena
        x_web3_bulto_habilitado:   true,
        x_web3_bulto_usd:          precios.bulto,
        x_web3_bulto_piezas:       13,
        x_web3_bulto_surtido:      true,    // SURTIDO: proveedor elige en bulto
        x_web3_precio_ves:         0,
    };

    // 1. Tipo de Venta (Unidad) — no_variant
    const { tvAttrId, allTvValIds } = await ensureTipoVentaAttr(web3, existingAttrMap, existingValMap, odoo);
    const ptalPayload = [[0,0,{attribute_id:tvAttrId, value_ids:[[6,0,allTvValIds]]}]];

    // 2. Atributo Color
    if (!existingAttrMap['Color']) {
        existingAttrMap['Color'] = await odoo('product.attribute','create',[{name:'Color',create_variant:'always'}]);
    }
    const colorAttrId = existingAttrMap['Color'];
    const colorValIds = [];
    for (const color of colors) {
        const k = `${colorAttrId}_${color}`;
        if (!existingValMap[k]) {
            existingValMap[k] = await odoo('product.attribute.value','create',[{name:color, attribute_id:colorAttrId}]);
        }
        colorValIds.push(existingValMap[k]);
    }
    ptalPayload.push([0,0,{attribute_id:colorAttrId, value_ids:[[6,0,colorValIds]]}]);

    // 3. Crear template
    const tmplId = await odoo('product.template','create',[{
        name:  model,
        type:  'consu',
        is_storable: false,       // NO controlar inventario
        sale_ok: true, purchase_ok: true, is_published: true,
        list_price:      precios.detal,
        standard_price:  cost,
        public_categ_ids: [[6,0,[catId]]],
        seller_ids: [[0,0,{partner_id:JAVIER_ID, delay:1, price:cost}]],
        attribute_line_ids: ptalPayload,
        ...web3,
    }]);

    // 4. Imagen principal (primer color)
    const firstImg = imgToBase64(variants[colors[0]]);
    if (firstImg) {
        await odoo('product.template','write',[[tmplId],{image_1920:firstImg}]);
    }

    // 5. PL por variante (precio dividido)
    await setVariantPricelists(tmplId, web3, odoo);

    // 6. Imágenes individuales por color
    const variantsList = await odoo('product.product','search_read',[
        [['product_tmpl_id','=',tmplId],['active','=',true]]
    ],{fields:['id','display_name','product_template_attribute_value_ids']});

    // Mapear PTAV → nombre
    const allPtavIds = new Set();
    variantsList.forEach(v=>v.product_template_attribute_value_ids.forEach(id=>allPtavIds.add(id)));
    const ptavMap = {};
    if (allPtavIds.size > 0) {
        const ptavs = await odoo('product.template.attribute.value','search_read',[
            [['id','in',[...allPtavIds]]]
        ],{fields:['id','name','attribute_id']});
        ptavs.forEach(p=>{ptavMap[p.id]=p;});
    }

    let imgUploaded = 0;
    for (const v of variantsList) {
        const colorPtav = v.product_template_attribute_value_ids
            .map(id=>ptavMap[id])
            .find(p=>p && p.attribute_id[0]===colorAttrId);
        if (!colorPtav) continue;
        const colorName = colorPtav.name;
        const imgPath = variants[colorName];
        if (!imgPath) continue;
        const b64 = imgToBase64(imgPath);
        if (!b64) continue;
        await odoo('product.product','write',[[v.id],{image_1920:b64}]);
        imgUploaded++;
    }

    console.log(`    ✓ tmplId:${tmplId} | ${variantsList.length} variantes | ${imgUploaded} fotos subidas`);
    return tmplId;
}

// ── MAIN ──────────────────────────────────────────────────────────────────────
async function main() {
    console.log('=== CREANDO ZAPATOS DE JAVIER SERRANO ===\n');

    // Categoría zapato colombiano
    const cats = await odoo('product.public.category','search_read',[
        [['name','ilike','zapato']]
    ],{fields:['id','name']});
    console.log('Categorías de zapatos:', cats.map(c=>c.id+':'+c.name).join(', '));
    const catId = cats.find(c=>c.name.toLowerCase().includes('colombian'))?.id || cats[0]?.id;
    console.log('Usando categoría ID:', catId);

    // Pre-cargar atributos y valores existentes
    console.log('\nCargando atributos existentes...');
    const existingAttrMap = {}, existingValMap = {};
    const odooAttrs = await odoo('product.attribute','search_read',[[]], {fields:['id','name']});
    odooAttrs.forEach(a=>existingAttrMap[a.name]=a.id);
    const odooVals = await odoo('product.attribute.value','search_read',[[]], {fields:['id','name','attribute_id']});
    odooVals.forEach(v=>{ if(v.attribute_id) existingValMap[v.attribute_id[0]+'_'+v.name]=v.id; });
    console.log('  Atributos:', Object.keys(existingAttrMap).length, '| Valores:', Object.keys(existingValMap).length);

    // Leer y agrupar imágenes
    const images = readAllImages();
    console.log('\nImágenes leídas:', images.length);
    const groups = groupByModel(images);
    const groupNames = Object.keys(groups).sort();
    console.log('Modelos agrupados:', groupNames.length);
    groupNames.forEach(g => {
        const gr = groups[g];
        const colors = Object.keys(gr.variants);
        console.log(`  - ${g}: ${colors.length} colores | costo:$${gr.cost}`);
    });

    // Preguntar confirmación mostrando resumen de precios
    console.log('\n=== RESUMEN DE PRECIOS ===');
    const uniqueCosts = [...new Set(Object.values(groups).map(g=>g.cost))].sort((a,b)=>a-b);
    uniqueCosts.forEach(cost => {
        const p = calcPrecios(cost);
        console.log(`Costo $${cost}: Detal=$${p.detal} | Combo3=$${p.combo} | Docena12=$${p.docena} | Bulto13=$${p.bulto}`);
    });

    console.log('\nCreando productos en Odoo...');
    const created = [];
    let idx = 0;
    for (const name of groupNames) {
        idx++;
        process.stdout.write(`[${idx}/${groupNames.length}] `);
        try {
            const tmplId = await createProductGroup(groups[name], catId, existingAttrMap, existingValMap);
            created.push({ model: name, tmplId });
        } catch(e) {
            console.error(`  ✗ ERROR en ${name}:`, e.message?.substring(0,100));
            if (e.faultString) console.error('  ', e.faultString.substring(0,200));
        }
    }

    // Ejecutar DATA WEB 3
    console.log('\nActualizando catálogo (DATA WEB 3)...');
    await odoo('ir.actions.server','run',[[3047]]);
    console.log('✓ JSON v3 actualizado');

    console.log('\n=== RESUMEN FINAL ===');
    console.log('Productos creados:', created.length, '/', groupNames.length);
    created.forEach(c=>console.log('  tmpl:'+c.tmplId, c.model));
}

main().catch(e=>{ console.error('FATAL:', e.message); if(e.faultString) console.error(e.faultString.substring(0,500)); });
