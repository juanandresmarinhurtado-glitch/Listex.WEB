const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

// Replace stock location search
const oldLocSearch = /const stockLocations = await executeKw\('stock\.location', 'search_read', \[\[\['usage', '=', 'internal'\]\]\], \{ fields: \['id'\], limit: 1 \}\);/;

const newLocSearch = `let stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'WH/']]], { fields: ['id'], limit: 1 });
        if (stockLocations.length === 0) {
            stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'PT/']]], { fields: ['id'], limit: 1 });
        }
        if (stockLocations.length === 0) {
            stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal']]], { fields: ['id'], limit: 1 });
        }`;

serverJs = serverJs.replace(oldLocSearch, newLocSearch);
fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Patched location search.");
