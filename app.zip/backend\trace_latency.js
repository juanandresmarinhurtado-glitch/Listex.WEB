const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            const start = Date.now();
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                console.log(`[${model}.${method}] took ${(Date.now() - start)/1000}s`);
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        console.log("Creating template with inline attributes...");
        const productData = {
            name: "Test Timing Product",
            list_price: 15,
            attribute_line_ids: [
                [0, 0, { attribute_id: 39, value_ids: [[6, 0, [49, 50, 51]]] }]
            ]
        };
        
        const tmplId = await executeKw('product.template', 'create', [productData]);
        console.log("Template ID:", tmplId);
        
        console.log("Fetching variants...");
        const variants = await executeKw('product.product', 'search_read', [
            [['product_tmpl_id', '=', tmplId]],
            ['id', 'product_template_attribute_value_ids', 'image_variant_128', 'qty_available']
        ]);
        console.log(`Fetched ${variants.length} variants.`);
        
    } catch (e) {
        console.error("Error:", e);
    }
});
