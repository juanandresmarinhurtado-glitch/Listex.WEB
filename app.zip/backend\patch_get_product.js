const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const getProductRegex = /app\.get\('\/api\/supplier\/products\/:id', authenticateSupplier, async \(req, res\) => \{[\s\S]*?(?=\/\/ Edit Product Full|\napp\.post\('\/api\/supplier\/products\/:id\/edit')/;

const newGetProductCode = `app.get('/api/supplier/products/:id', authenticateSupplier, async (req, res) => {
    try {
        const reqId = req.params.id;
        
        if (reqId.startsWith('temp_')) {
            const queue = readJson(queueFile);
            const qData = queue[reqId];
            if (!qData || qData.partner_id !== req.user.id) return res.status(404).json({ error: "No encontrado en cola" });
            
            const variantsQueue = readJson(variantsFile);
            const fakeVariants = variantsQueue[reqId] || [];
            
            const p = qData.data;
            return res.json({ success: true, product: {
                id: reqId,
                name: p.name,
                standard_price: parseFloat(p.cost) || 0,
                list_price: parseFloat(p.priceUnidad) || 0,
                priceUnidad: parseFloat(p.priceUnidad) || 0,
                priceDocena: parseFloat(p.priceDocena) || "",
                priceBulto: parseFloat(p.priceBulto) || "",
                categoryId: p.categoryId,
                isStorable: p.isStorable,
                imageBase64: p.imageBase64 ? p.imageBase64.split(',')[1] : null,
                variants: fakeVariants,
                isPending: true
            }});
        }
        
        await authenticate();
        const tmplId = parseInt(reqId);
        if (isNaN(tmplId)) return res.status(400).json({ error: "Invalid ID" });
        
        const supplierInfos = await executeKw('product.supplierinfo', 'search_count', [[['partner_id', '=', req.user.id], ['product_tmpl_id', '=', tmplId]]]);
        if (supplierInfos === 0) return res.status(403).json({ error: "Access denied" });
        
        const products = await executeKw('product.template', 'search_read', [
            [['id', '=', tmplId]], 
            ['name', 'standard_price', 'list_price', 'public_categ_ids', 'is_storable', 'image_1920']
        ]);
        if (products.length === 0) return res.status(404).json({ error: "Not found" });
        
        const p = products[0];
        
        const pricelists = await executeKw('product.pricelist.item', 'search_read', [
            [['product_tmpl_id', '=', tmplId], ['pricelist_id', 'in', [2, 3]]]
        ], { fields: ['pricelist_id', 'fixed_price'] });
        
        let priceDocena = "";
        let priceBulto = "";
        pricelists.forEach(pl => {
            if (pl.pricelist_id[0] === 3) priceDocena = pl.fixed_price;
            if (pl.pricelist_id[0] === 2) priceBulto = pl.fixed_price; 
        });
        
        const variants = await executeKw('product.product', 'search_read', [
            [['product_tmpl_id', '=', tmplId]],
            ['id', 'product_template_attribute_value_ids', 'qty_available', 'image_variant_128']
        ]);
        
        const allPtavIds = new Set();
        variants.forEach(v => {
            if (v.product_template_attribute_value_ids) {
                v.product_template_attribute_value_ids.forEach(id => allPtavIds.add(id));
            }
        });
        const uniquePtavIds = [...allPtavIds];
        let ptavMap = {};
        if (uniquePtavIds.length > 0) {
            const ptavs = await executeKw('product.template.attribute.value', 'search_read', [[['id', 'in', uniquePtavIds]], ['id', 'name']]);
            ptavs.forEach(pt => ptavMap[pt.id] = pt.name);
        }
        
        for (let v of variants) {
            if (v.product_template_attribute_value_ids && v.product_template_attribute_value_ids.length > 0) {
                v.attribute_names = v.product_template_attribute_value_ids.map(id => ptavMap[id] || '').filter(Boolean).join(' / ');
            } else {
                v.attribute_names = "Variante Base";
            }
            v.image_variant_1920 = v.image_variant_128;
            delete v.image_variant_128;
        }
        
        res.json({ success: true, product: {
            id: p.id,
            name: p.name,
            standard_price: p.standard_price,
            list_price: p.list_price,
            priceUnidad: p.list_price,
            priceDocena: priceDocena,
            priceBulto: priceBulto,
            categoryId: p.public_categ_ids.length > 0 ? p.public_categ_ids[0] : "",
            isStorable: p.is_storable,
            imageBase64: p.image_1920,
            variants: variants,
            isPending: false
        }});
    } catch (error) {
        console.error("Get Product Error:", error);
        res.status(500).json({ error: error.message });
    }
});
`;

serverJs = serverJs.replace(getProductRegex, newGetProductCode);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Patched GET product by ID");
