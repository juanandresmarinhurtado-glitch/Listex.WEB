
        const API_BASE = '/api/supplier';
        let currentUser = null;
        let base64Image = null;

        function showToast(msg) {
            const toast = document.getElementById('toast');
            toast.textContent = msg;
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 4000);
        }

        function toggleAuthMode() {
            const loginForm = document.getElementById('login-form');
            const regForm = document.getElementById('register-form');
            const title = document.getElementById('auth-title');
            
            if (loginForm.classList.contains('hidden')) {
                loginForm.classList.remove('hidden');
                regForm.classList.add('hidden');
                title.textContent = 'Acceso de Proveedores';
            } else {
                loginForm.classList.add('hidden');
                regForm.classList.remove('hidden');
                title.textContent = 'Solicitud de Ingreso';
            }
        }

        function switchTab(tabId, btn) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
            document.querySelectorAll('.dash-tab').forEach(el => el.classList.remove('active'));
            document.getElementById(tabId).classList.remove('hidden');
            btn.classList.add('active');
            
            if(tabId === 'tab-productos') loadProducts();
        }

        
        async function togglePublish(id, btn) {
            btn.innerHTML = '<ion-icon name="sync-outline" class="spin"></ion-icon>';
            try {
                const res = await fetch(API_BASE + '/products/' + id + '/toggle_publish', {
                    method: 'POST',
                    headers: getAuthHeaders()
                });
                const data = await res.json();
                if (data.success) {
                    showToast(data.is_published ? 'Producto publicado' : 'Producto oculto');
                    loadProducts(); // reload row
                } else {
                    showToast('Error al cambiar estado');
                    loadProducts();
                }
            } catch (err) {
                showToast('Error de red');
                loadProducts();
            }
        }

        
        
        let editModeId = null;

        async function openEditModal(id) {
            editModeId = id;
            document.getElementById('btn-create-product').innerHTML = '<ion-icon name="sync-outline" class="spin"></ion-icon> Cargando Datos...';
            document.getElementById('btn-create-product').disabled = true;
            
            // Switch to form tab
            switchTab('tab-crear', document.querySelectorAll('.dash-tab')[1]);
            document.querySelectorAll('.dash-tab')[1].innerHTML = '<ion-icon name="create-outline"></ion-icon> Editando Producto';
            
            // Hide custom attributes section
            document.getElementById('custom-attributes-container').parentElement.style.display = 'none';
            
            try {
                const res = await fetch(API_BASE + '/products/' + id, { headers: getAuthHeaders() });
                const data = await res.json();
                
                if (data.success) {
                    const p = data.product;
                    document.getElementById('prod-name').value = p.name;
                    document.getElementById('prod-category').value = p.categoryId;
                    document.getElementById('prod-cost').value = p.cost;
                    document.getElementById('prod-price-unidad').value = p.priceUnidad;
                    document.getElementById('prod-price-docena').value = p.priceDocena || '';
                    document.getElementById('prod-price-bulto').value = p.priceBulto || '';
                    document.getElementById('prod-inventario').checked = p.isStorable;
                    
                    if (p.imageBase64) {
                        base64Image = 'data:image/webp;base64,' + p.imageBase64;
                        document.getElementById('image-preview').innerHTML = `<img src="${base64Image}" /> <input type="file" id="prod-image" accept="image/png, image/jpeg, image/webp" style="display:none;">`; // No longer required if editing
                    }
                    
                    // Show Variants section
                    const vSection = document.getElementById('variants-manager-section');
                    vSection.classList.remove('hidden');
                    const vList = document.getElementById('inline-variants-list');
                    vList.innerHTML = '';
                    
                    if (p.variants && p.variants.length > 0) {
                        p.variants.forEach(v => {
                            const imgHtml = v.image_variant_1920 
                                ? `<img id="img-var-${v.id}" src="data:image/webp;base64,${v.image_variant_1920}" style="width:100%; height:100%; object-fit:cover;">`
                                : `<ion-icon name="camera-outline" style="font-size:1.5rem; color:var(--text-muted);" id="icon-var-${v.id}"></ion-icon>
                                   <img id="img-var-${v.id}" style="width:100%; height:100%; object-fit:cover; display:none;">`;
                                   
                            const stockHtml = p.isStorable 
                                ? `<div style="display:flex; align-items:center; gap:8px;">
                                       <span style="font-size:0.8rem; color:var(--text-muted);">Stock:</span>
                                       <input type="number" id="stock-var-${v.id}" value="${v.qty_available || 0}" style="width:70px; padding:6px; border-radius:4px; border:1px solid var(--border-color); text-align:center;">
                                       <button type="button" class="btn btn-secondary" onclick="updateVariantStock(${v.id})" style="padding:6px 10px; font-size:0.8rem;">Guardar</button>
                                       <span id="stock-status-${v.id}" style="font-size:0.8rem; margin-left:5px;"></span>
                                   </div>`
                                : `<p style="font-size:0.8rem; color:var(--text-muted); margin-top:5px;">Inventario no controlado</p>`;
                                
                            vList.innerHTML += `
                                <div style="display:flex; align-items:center; gap:15px; padding:15px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-color);">
                                    <div style="flex:1;">
                                        <strong style="color:var(--text-main);">${v.attribute_names}</strong>
                                        ${stockHtml}
                                    </div>
                                    <div style="display:flex; flex-direction:column; align-items:center; gap:5px;">
                                        <div style="width:60px; height:60px; border-radius:8px; overflow:hidden; background:#e2e8f0; display:flex; align-items:center; justify-content:center; position:relative; cursor:pointer;" onclick="document.getElementById('file-var-${v.id}').click()">
                                            ${imgHtml}
                                        </div>
                                        <span id="status-var-${v.id}" style="font-size:0.7rem; color:var(--text-muted);">Cambiar</span>
                                    </div>
                                    <input type="file" id="file-var-${v.id}" style="display:none;" accept="image/*" onchange="uploadVariantImage(this, ${v.id})">
                                </div>
                            `;
                        });
                    } else {
                        vList.innerHTML = '<p style="color:var(--text-muted); font-size:0.9rem;">No hay variantes creadas.</p>';
                    }
                } else {
                    throw new Error(data.error || "Error desconocido");
                }
            } catch (err) {
                showToast('Error cargando: ' + err.message);
                console.error("Edit Modal Error:", err);
            }

            
            document.getElementById('btn-create-product').disabled = false;
            document.getElementById('btn-create-product').innerHTML = '<ion-icon name="save-outline"></ion-icon> Guardar Cambios';
        }

        async function updateVariantStock(variantId) {
            const qty = document.getElementById('stock-var-' + variantId).value;
            const statusEl = document.getElementById('stock-status-' + variantId);
            statusEl.textContent = "Guardando...";
            statusEl.style.color = "var(--primary)";
            
            try {
                const res = await fetch(API_BASE + '/variants/' + variantId + '/stock', {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify({ qty: qty })
                });
                if ((await res.json()).success) {
                    statusEl.textContent = "¡Stock actualizado!";
                    statusEl.style.color = "green";
                    setTimeout(() => statusEl.textContent = '', 3000);
                } else {
                    statusEl.textContent = "Error";
                    statusEl.style.color = "red";
                }
            } catch (e) {
                statusEl.textContent = "Error de red";
                statusEl.style.color = "red";
            }
        }

        // We need to override switchTab so if they click "Nuevo Producto", we reset the form
        const originalSwitchTab = switchTab;
        switchTab = function(tabId, btn) {
            originalSwitchTab(tabId, btn);
            if (tabId === 'tab-crear') {
                if (!editModeId) {
                    // It's a real new product
                    document.getElementById('create-product-form').reset();
                    document.getElementById('custom-attributes-container').innerHTML = '';
                    document.getElementById('custom-attributes-container').parentElement.style.display = 'block';
                    document.getElementById('variants-manager-section').classList.add('hidden');
                    document.getElementById('btn-create-product').innerHTML = '<ion-icon name="checkmark-circle-outline"></ion-icon> Guardar y Publicar en Tienda';
                    document.querySelectorAll('.dash-tab')[1].innerHTML = '<ion-icon name="add-circle-outline"></ion-icon> Nuevo Producto';
                    document.getElementById('prod-image').setAttribute('required', 'true');
                    
                    const preview = document.getElementById('image-preview');
                    const img = preview.querySelector('img');
                    if (img) img.remove();
                    const placeholder = preview.querySelector('.placeholder');
                    if (placeholder) placeholder.style.display = 'block';
                    const input = document.getElementById('prod-image');
                    if (input) {
                        input.value = '';
                        input.setAttribute('required', 'true');
                    }

                    base64Image = null;
                }
            } else {
                editModeId = null; // Clear edit mode when switching away
                document.querySelectorAll('.dash-tab')[1].innerHTML = '<ion-icon name="add-circle-outline"></ion-icon> Nuevo Producto';
            }
        }


        document.getElementById('edit-product-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('edit-save-btn');
            btn.disabled = true;
            btn.textContent = 'Guardando...';
            
            const id = document.getElementById('edit-prod-id').value;
            const body = {
                name: document.getElementById('edit-prod-name').value,
                cost: document.getElementById('edit-prod-cost').value,
                priceUnidad: document.getElementById('edit-prod-price').value
            };
            
            try {
                const res = await fetch(API_BASE + '/products/' + id + '/edit', {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify(body)
                });
                if ((await res.json()).success) {
                    showToast('Producto actualizado');
                    document.getElementById('edit-modal').style.display = 'none';
                    loadProducts();
                } else {
                    showToast('Error al actualizar');
                }
            } catch (err) {
                showToast('Error de red');
            }
            btn.disabled = false;
            btn.textContent = 'Guardar Cambios';
        });

        
        document.getElementById('prod-inventario').addEventListener('change', function() {
            if (editModeId) {
                // If they are in edit mode, checking this box should immediately re-render variants
                openEditModal(editModeId);
                showToast(this.checked ? "Inventario Activado. Guarde los cambios." : "Inventario Desactivado.");
            }
        });

        // INIT
        window.onload = () => {
            const token = localStorage.getItem('supplier_token');
            if (token) {
                currentUser = JSON.parse(localStorage.getItem('supplier_user'));
                document.getElementById('auth-section').classList.add('hidden');
                document.getElementById('dashboard-section').classList.remove('hidden');
                document.getElementById('dashboard-welcome').innerHTML = `Panel de Proveedor <span style="font-weight:400; color:var(--text-muted); font-size:1rem; margin-left:8px;">| ${currentUser.name}</span>`;
                loadCategories();
                loadProducts();
            }
        };

        function logout() {
            localStorage.removeItem('supplier_token');
            localStorage.removeItem('supplier_user');
            window.location.reload();
        }

        function getAuthHeaders() {
            return {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('supplier_token')
            };
        }

        // LOAD DATA
        async function loadProducts() {
            const tbody = document.getElementById('products-table-body');
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);">Consultando Web Listex...</td></tr>';
            try {
                const res = await fetch(API_BASE + '/products', { headers: getAuthHeaders() });
                const data = await res.json();
                if(data.success) {
                    tbody.innerHTML = '';
                    if(data.products.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:40px; color:var(--text-muted);">Aún no tienes productos publicados.</td></tr>';
                        return;
                    }
                    data.products.forEach(p => {
                        const statusBadge = p.is_published 
                            ? '<span class="badge badge-success">Activo</span>' 
                            : '<span class="badge badge-warning">Oculto</span>';
                        const toggleBtn = p.is_published
                            ? `<button onclick="togglePublish(${p.id}, this)" class="btn" style="background:#fef2f2; color:#ef4444; padding:6px 12px; font-size:0.8rem;"><ion-icon name="eye-off-outline"></ion-icon> Ocultar</button>`
                            : `<button onclick="togglePublish(${p.id}, this)" class="btn" style="background:#ecfdf5; color:#10b981; padding:6px 12px; font-size:0.8rem;"><ion-icon name="eye-outline"></ion-icon> Publicar</button>`;
                        
                        tbody.innerHTML += `<tr id="tr-prod-${p.id}">
                            <td>#${p.id}</td>
                            <td style="font-weight:500;">${p.name}</td>
                            <td>${p.list_price.toFixed(2)}</td>
                            <td>${p.standard_price.toFixed(2)}</td>
                            <td id="status-td-${p.id}">${statusBadge}</td>
                            <td>
                                <div style="display:flex; gap:5px;">
                                    ${toggleBtn}
                                    <button onclick="openEditModal(${p.id})" class="btn" style="background:#e0f2fe; color:#0284c7; padding:6px 12px; font-size:0.8rem;" title="Editar"><ion-icon name="create-outline"></ion-icon></button>
                                    <button onclick="openVariantsModal(${p.id})" class="btn" style="background:var(--input-bg); color:var(--text-main); padding:6px 12px; font-size:0.8rem;" title="Fotos de Variantes"><ion-icon name="images-outline"></ion-icon></button>
                                </div>
                            </td>
                        </tr>`;
                    });
                } else {
                    if (data.error === "Invalid token") logout();
                }
            } catch (err) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:red;">Error de red</td></tr>';
            }
        }

        async function loadCategories() {
            try {
                const res = await fetch('/api/categories');
                const data = await res.json();
                if(data.success) {
                    const select = document.getElementById('prod-category');
                    data.categories.forEach(c => {
                        const opt = document.createElement('option');
                        opt.value = c.id;
                        opt.textContent = c.name;
                        select.appendChild(opt);
                    });
                }
            } catch(e) { console.error(e); }
        }

        // IMAGE PROCESSING (Client Side Compression to WebP)
        document.getElementById('prod-image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function(event) {
                const img = new Image();
                img.onload = function() {
                    const canvas = document.createElement('canvas');
                    const MAX_WIDTH = 800;
                    let scaleSize = 1;
                    if (img.width > MAX_WIDTH) {
                        scaleSize = MAX_WIDTH / img.width;
                    }
                    canvas.width = img.width * scaleSize;
                    canvas.height = img.height * scaleSize;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                    
                    // Convert to WebP with 0.8 quality
                    base64Image = canvas.toDataURL('image/webp', 0.8);
                    
                    // Show preview
                    const preview = document.getElementById('image-preview');
                    preview.innerHTML = `<img src="${base64Image}" /> <input type="file" id="prod-image-hidden" style="display:none;">`;
                }
                img.src = event.target.result;
            }
            reader.readAsDataURL(file);
        });

        
        function addAttributeRow() {
            const container = document.getElementById('custom-attributes-container');
            const row = document.createElement('div');
            row.style.cssText = "display:flex; gap:10px; margin-bottom:10px; align-items:center;";
            row.innerHTML = `
                <input type="text" class="attr-name" placeholder="Nombre (Ej: Talla)" style="flex:1; padding:8px; border:1px solid var(--border-color); border-radius:6px; font-size:0.85rem;">
                <input type="text" class="attr-values" placeholder="Valores separados por coma (Ej: S, M, L)" style="flex:2; padding:8px; border:1px solid var(--border-color); border-radius:6px; font-size:0.85rem;">
                <button type="button" onclick="this.parentElement.remove()" style="background:none; border:none; color:red; cursor:pointer; font-size:1.2rem;"><ion-icon name="trash-outline"></ion-icon></button>
            `;
            container.appendChild(row);
        }

        
        let currentTmplId = null;

        function closeVariantsModal() {
            document.getElementById('variants-modal').style.display = 'none';
            switchTab('tab-productos', document.querySelector('.dash-tab'));
        }

        async function openVariantsModal(tmplId) {
            currentTmplId = tmplId;
            const modal = document.getElementById('variants-modal');
            modal.style.display = 'flex';
            
            const list = document.getElementById('variants-list');
            list.innerHTML = '<p style="text-align:center;">Buscando variantes en Web Listex...</p>';
            
            try {
                // Wait a tiny bit for the system to finish generating variants if it's slow
                await new Promise(r => setTimeout(r, 1500));
                
                const res = await fetch(API_BASE + '/products/' + tmplId + '/variants', { headers: getAuthHeaders() });
                const data = await res.json();
                
                if (data.success && data.variants.length > 0) {
                    list.innerHTML = '';
                    data.variants.forEach(v => {
                        list.innerHTML += `
                            <div style="display:flex; align-items:center; gap:15px; padding:15px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-color);">
                                <div style="flex:1;">
                                    <strong style="color:var(--text-main);">${v.attribute_names}</strong>
                                    <p id="status-var-${v.id}" style="font-size:0.8rem; color:var(--text-muted); margin-top:5px;">Foto heredada de la principal</p>
                                </div>
                                <div style="width:80px; height:80px; border-radius:8px; overflow:hidden; background:#e2e8f0; display:flex; align-items:center; justify-content:center; position:relative; cursor:pointer;" onclick="document.getElementById('file-var-${v.id}').click()">
                                    <ion-icon name="camera-outline" style="font-size:1.5rem; color:var(--text-muted);" id="icon-var-${v.id}"></ion-icon>
                                    <img id="img-var-${v.id}" style="width:100%; height:100%; object-fit:cover; display:none;">
                                </div>
                                <input type="file" id="file-var-${v.id}" style="display:none;" accept="image/*" onchange="uploadVariantImage(this, ${v.id})">
                            </div>
                        `;
                    });
                } else {
                    list.innerHTML = '<p style="text-align:center; color:var(--text-muted);">El producto es simple (no tiene opciones). Todo listo.</p>';
                }
            } catch (err) {
                list.innerHTML = '<p style="text-align:center; color:red;">Error al consultar variantes.</p>';
            }
        }

        async function uploadVariantImage(input, variantId) {
            const file = input.files[0];
            if (!file) return;
            
            document.getElementById('status-var-' + variantId).textContent = "Procesando...";
            document.getElementById('status-var-' + variantId).style.color = "var(--primary)";
            
            const reader = new FileReader();
            reader.onload = function(event) {
                const img = new Image();
                img.onload = async function() {
                    const canvas = document.createElement('canvas');
                    const MAX_WIDTH = 800;
                    let scaleSize = 1;
                    if (img.width > MAX_WIDTH) scaleSize = MAX_WIDTH / img.width;
                    canvas.width = img.width * scaleSize;
                    canvas.height = img.height * scaleSize;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                    
                    const base64Image = canvas.toDataURL('image/webp', 0.8);
                    
                    // Show visually
                    document.getElementById('icon-var-' + variantId).style.display = 'none';
                    const imgEl = document.getElementById('img-var-' + variantId);
                    imgEl.src = base64Image;
                    imgEl.style.display = 'block';
                    
                    // Upload to server
                    document.getElementById('status-var-' + variantId).textContent = "Subiendo...";
                    try {
                        const res = await fetch(API_BASE + '/variants/' + variantId + '/image', {
                            method: 'POST',
                            headers: getAuthHeaders(),
                            body: JSON.stringify({ imageBase64: base64Image })
                        });
                        if ((await res.json()).success) {
                            document.getElementById('status-var-' + variantId).textContent = "¡Foto Exclusiva Subida!";
                            document.getElementById('status-var-' + variantId).style.color = "green";
                        }
                    } catch (e) {
                        document.getElementById('status-var-' + variantId).textContent = "Error al subir";
                        document.getElementById('status-var-' + variantId).style.color = "red";
                    }
                }
                img.src = event.target.result;
            }
            reader.readAsDataURL(file);
        }

        // CREATE PRODUCT
        
        document.getElementById('create-product-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('btn-create-product');
            btn.disabled = true;
            btn.innerHTML = '<ion-icon name="sync-outline" class="spin"></ion-icon> ' + (editModeId ? 'Guardando Cambios...' : 'Sincronizando con Web Listex...');
            
            try {
                const body = {
                    name: document.getElementById('prod-name').value,
                    categoryId: document.getElementById('prod-category').value,
                    cost: document.getElementById('prod-cost').value,
                    priceUnidad: document.getElementById('prod-price-unidad').value,
                    priceDocena: document.getElementById('prod-price-docena').value,
                    priceBulto: document.getElementById('prod-price-bulto').value,
                    imageBase64: base64Image,
                    isStorable: document.getElementById('prod-inventario').checked,
                    customAttributes: Array.from(document.getElementById('custom-attributes-container').children).map(row => ({
                        name: row.querySelector('.attr-name').value,
                        values: row.querySelector('.attr-values').value.split(',').map(v => v.trim()).filter(v => v)
                    }))
                };

                const url = editModeId ? (API_BASE + '/products/' + editModeId + '/edit') : (API_BASE + '/products');
                
                const res = await fetch(url, {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify(body)
                });
                
                const data = await res.json();
                if(data.success) {
                    showToast(editModeId ? '¡Cambios guardados con éxito!' : '¡Producto creado con éxito!');
                    if (!editModeId) {
                        // Switch to edit mode automatically to allow photo/stock management
                        openEditModal(data.id);
                    }
                } else {
                    showToast(data.error || 'Error al procesar en Web Listex');
                }
            } catch (err) {
                showToast('Error de conexión con el servidor central');
            }
            
            // Note: If we switched to edit mode, the button was handled there.
            if (!editModeId) {
                btn.disabled = false;
                btn.innerHTML = '<ion-icon name="checkmark-circle-outline"></ion-icon> Guardar y Publicar en Tienda';
            }
btn.disabled = false;
            btn.innerHTML = '<ion-icon name="checkmark-circle-outline"></ion-icon> Guardar y Publicar en Tienda';
        });

        // AUTH FORMS
        document.getElementById('login-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('login-btn');
            btn.disabled = true;
            btn.textContent = 'Autenticando...';
            try {
                const res = await fetch(API_BASE + '/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: document.getElementById('login-email').value, password: document.getElementById('login-password').value })
                });
                const data = await res.json();
                if (data.success) {
                    localStorage.setItem('supplier_token', data.token);
                    localStorage.setItem('supplier_user', JSON.stringify(data.user));
                    showToast('Conexión exitosa');
                    setTimeout(() => window.location.reload(), 800);
                } else { showToast(data.error || 'Credenciales inválidas'); }
            } catch (err) { showToast('Error de conexión'); }
            btn.disabled = false; btn.textContent = 'Ingresar al Portal';
        });

        document.getElementById('register-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('register-btn');
            btn.disabled = true;
            btn.textContent = 'Procesando...';
            try {
                const res = await fetch(API_BASE + '/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: document.getElementById('reg-name').value,
                        email: document.getElementById('reg-email').value,
                        rif: document.getElementById('reg-rif').value,
                        phone: document.getElementById('reg-phone').value,
                        address: document.getElementById('reg-address').value,
                        password: document.getElementById('reg-password').value
                    })
                });
                const data = await res.json();
                if (data.success) {
                    showToast(data.message);
                    setTimeout(() => toggleAuthMode(), 2000);
                } else { showToast(data.error || 'Error al registrar'); }
            } catch (err) { showToast('Error de conexión'); }
            btn.disabled = false; btn.textContent = 'Enviar Solicitud a Listex';
        });
    