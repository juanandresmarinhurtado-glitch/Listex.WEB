const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        const stockLocations = await executeKw('stock.location', 'search_read', [[['usage', '=', 'internal']]], { fields: ['id', 'complete_name'] });
        console.log("Internal Locations:", stockLocations);
    } catch (e) {
        console.error("Error:", e);
    }
});
