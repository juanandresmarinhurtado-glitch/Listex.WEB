const fs = require('fs');

// --- 1. PATCH SERVER.JS ---
let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const editRoutes = `
// Toggle Publish Status
app.post('/api/supplier/products/:id/toggle_publish', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const tmplId = parseInt(req.params.id);
        
        // Security check
        const supplierInfos = await executeKw('product.supplierinfo', 'search_count', [[['partner_id', '=', req.user.id], ['product_tmpl_id', '=', tmplId]]]);
        if (supplierInfos === 0) return res.status(403).json({ error: "Access denied" });
        
        const products = await executeKw('product.template', 'search_read', [[['id', '=', tmplId]], ['is_published']]);
        if (products.length === 0) return res.status(404).json({ error: "Not found" });
        
        const newStatus = !products[0].is_published;
        await executeKw('product.template', 'write', [[tmplId], { is_published: newStatus }]);
        
        res.json({ success: true, is_published: newStatus });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
`;

if (!serverJs.includes('/toggle_publish')) {
    serverJs = serverJs.replace("// Categories endpoint", editRoutes + "\n// Categories endpoint");
    fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
}


// --- 2. PATCH HTML ---
let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// Update Table Headers
html = html.replace('<th>Estatus</th>', '<th>Estatus</th>\n                                    <th>Acciones</th>');

// Update Table Body in loadProducts
const oldLoadLogic = `const statusBadge = p.is_published 
                            ? '<span class="badge badge-success">Activo en Web</span>' 
                            : '<span class="badge badge-warning">Oculto</span>';
                        tbody.innerHTML += \`<tr>
                            <td>#\${p.id}</td>
                            <td style="font-weight:500;">\${p.name}</td>
                            <td>$\${p.list_price.toFixed(2)}</td>
                            <td>$\${p.standard_price.toFixed(2)}</td>
                            <td>\${statusBadge}</td>
                        </tr>\`;`;

const newLoadLogic = `const statusBadge = p.is_published 
                            ? '<span class="badge badge-success">Activo</span>' 
                            : '<span class="badge badge-warning">Oculto</span>';
                        const toggleBtn = p.is_published
                            ? \`<button onclick="togglePublish(\${p.id}, this)" class="btn" style="background:#fef2f2; color:#ef4444; padding:6px 12px; font-size:0.8rem;"><ion-icon name="eye-off-outline"></ion-icon> Ocultar</button>\`
                            : \`<button onclick="togglePublish(\${p.id}, this)" class="btn" style="background:#ecfdf5; color:#10b981; padding:6px 12px; font-size:0.8rem;"><ion-icon name="eye-outline"></ion-icon> Publicar</button>\`;
                        
                        tbody.innerHTML += \`<tr id="tr-prod-\${p.id}">
                            <td>#\${p.id}</td>
                            <td style="font-weight:500;">\${p.name}</td>
                            <td>$\${p.list_price.toFixed(2)}</td>
                            <td>$\${p.standard_price.toFixed(2)}</td>
                            <td id="status-td-\${p.id}">\${statusBadge}</td>
                            <td>
                                <div style="display:flex; gap:5px;">
                                    \${toggleBtn}
                                    <button onclick="openVariantsModal(\${p.id})" class="btn" style="background:var(--input-bg); color:var(--text-main); padding:6px 12px; font-size:0.8rem;" title="Fotos de Variantes"><ion-icon name="images-outline"></ion-icon></button>
                                </div>
                            </td>
                        </tr>\`;`;

html = html.replace(oldLoadLogic, newLoadLogic);
html = html.replace('<td colspan="5"', '<td colspan="6"');
html = html.replace('<td colspan="5"', '<td colspan="6"');

// Add JS function for togglePublish
const toggleJs = `
        async function togglePublish(id, btn) {
            btn.innerHTML = '<ion-icon name="sync-outline" class="spin"></ion-icon>';
            try {
                const res = await fetch(API_BASE + '/products/' + id + '/toggle_publish', {
                    method: 'POST',
                    headers: getAuthHeaders()
                });
                const data = await res.json();
                if (data.success) {
                    showToast(data.is_published ? 'Producto publicado' : 'Producto oculto');
                    loadProducts(); // reload row
                } else {
                    showToast('Error al cambiar estado');
                    loadProducts();
                }
            } catch (err) {
                showToast('Error de red');
                loadProducts();
            }
        }
`;

if (!html.includes('function togglePublish(')) {
    html = html.replace('// INIT', toggleJs + '\n        // INIT');
}

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("HTML updated successfully.");
