const { pool } = require('../db/init');
const { executeKw } = require('./odooApi');

// ── Robust stock setter: tries action_apply_inventory with fallback ────────
async function applyOdooStock(odooVariantId, qty, locId) {
    const existing = await executeKw('stock.quant', 'search_read', [
        [['product_id', '=', odooVariantId], ['location_id', '=', locId]]
    ], { fields: ['id', 'quantity'] });

    let quantId;
    if (existing.length > 0) {
        quantId = existing[0].id;
        await executeKw('stock.quant', 'write', [[quantId], { inventory_quantity: qty }]);
    } else {
        quantId = await executeKw('stock.quant', 'create', [{
            product_id: odooVariantId,
            location_id: locId,
            inventory_quantity: qty
        }]);
    }
    try {
        await executeKw('stock.quant', 'action_apply_inventory', [[quantId]]);
    } catch(e) {
        // Some Odoo versions require a different call — try action_apply_all on quant
        console.warn(`[STOCK] action_apply_inventory failed (${e.message}), trying write fallback`);
        try { await executeKw('stock.quant', 'write', [[quantId], { inventory_quantity_set: true }]); } catch(_) {}
    }
}

async function getStockLocId() {
    let locs = await executeKw('stock.location', 'search_read',
        [[['usage', '=', 'internal'], ['complete_name', 'ilike', 'WH/']]],
        { fields: ['id'], limit: 1 });
    if (locs.length === 0) locs = await executeKw('stock.location', 'search_read',
        [[['usage', '=', 'internal']]], { fields: ['id'], limit: 1 });
    return locs.length > 0 ? locs[0].id : null;
}

// ── UPDATE existing Odoo product (edit flow) ──────────────────────────────
async function syncUpdateToOdoo(odoo_tmpl_id, item, localVariants) {
    const { name, cost, price_unidad, price_docena, price_bulto, category_id, image_base64 } = item;

    // Update template fields
    const updateData = {
        name,
        list_price:    parseFloat(price_unidad) || 0,
        standard_price: parseFloat(cost) || 0,
        // Campos Presentación Universal (web3)
        x_web3_detal_usd:         parseFloat(item.x_web3_detal_usd || price_unidad) || 0,
        x_web3_combo_habilitado:  item.x_web3_combo_habilitado || false,
        x_web3_combo_usd:         parseFloat(item.x_web3_combo_usd) || 0,
        x_web3_combo_piezas:      parseInt(item.x_web3_combo_piezas) || 3,
        x_web3_combo_surtido:     item.x_web3_combo_surtido || false,
        x_web3_docena_habilitado: item.x_web3_docena_habilitado || false,
        x_web3_docena_usd:        parseFloat(item.x_web3_docena_usd || price_docena) || 0,
        x_web3_docena_surtido:    item.x_web3_docena_surtido || false,
        x_web3_bulto_habilitado:  item.x_web3_bulto_habilitado || false,
        x_web3_bulto_usd:         parseFloat(item.x_web3_bulto_usd || price_bulto) || 0,
        x_web3_bulto_piezas:      parseInt(item.x_web3_bulto_piezas) || 24,
        x_web3_bulto_surtido:     item.x_web3_bulto_surtido || false,
        x_web3_cost_usd:          parseFloat(cost) || 0,
        x_web3_precio_ves:        parseFloat(item.x_web3_precio_ves) || 0,
    };
    if (category_id) updateData.public_categ_ids = [[6, 0, [parseInt(category_id)]]];
    if (image_base64) {
        const raw = image_base64.split(',')[1] || image_base64;
        updateData.image_1920 = raw;
    }
    await executeKw('product.template', 'write', [[odoo_tmpl_id], updateData]);
    console.log(`[SYNC] Updated template tmplId=${odoo_tmpl_id}: name="${name}"`);

    // Actualizar Tipo de Venta (no_variant) y valores surtido
    const existingAttrMap = {}, existingValMap = {};
    const odooAttrs = await executeKw('product.attribute', 'search_read', [[]], { fields: ['id', 'name'] });
    odooAttrs.forEach(a => existingAttrMap[a.name] = a.id);
    const odooVals = await executeKw('product.attribute.value', 'search_read', [[]], { fields: ['id', 'name', 'attribute_id'] });
    odooVals.forEach(v => { if (v.attribute_id) existingValMap[`${v.attribute_id[0]}_${v.name}`] = v.id; });
    const { tvAttrId } = await ensureTipoVentaAttr(item, existingAttrMap, existingValMap);

    // PL a nivel variante (precio dividido)
    await setVariantPricelists(odoo_tmpl_id, item, existingValMap, tvAttrId);

    // Update variant photos/stock if there are local variants with data
    if (localVariants && localVariants.length > 0) {
        const locId = await getStockLocId();
        const odooVariants = await executeKw('product.product', 'search_read',
            [[['product_tmpl_id', '=', odoo_tmpl_id]]],
            { fields: ['id', 'product_template_attribute_value_ids'] });

        if (odooVariants.length > 0) {
            const allPtavIds = new Set();
            odooVariants.forEach(v => (v.product_template_attribute_value_ids || []).forEach(id => allPtavIds.add(id)));
            let ptavNameMap = {}, ptavAttrMap = {}, presAttrId = null;
            if (allPtavIds.size > 0) {
                const ptavs = await executeKw('product.template.attribute.value', 'search_read',
                    [[['id', 'in', [...allPtavIds]]]], { fields: ['id', 'name', 'attribute_id'] });
                ptavs.forEach(pt => { ptavNameMap[pt.id] = pt.name; ptavAttrMap[pt.id] = pt.attribute_id[0]; });
                const presNames = new Set(['unidad variada', 'docena cerrada', 'bulto']);
                for (const pt of ptavs) { if (presNames.has(pt.name)) { presAttrId = pt.attribute_id[0]; break; } }
            }
            const matched = new Set();
            for (const ov of odooVariants) {
                const customParts = (ov.product_template_attribute_value_ids || [])
                    .filter(id => ptavAttrMap[id] !== presAttrId)
                    .map(id => ptavNameMap[id] || '').filter(Boolean);
                const customName = customParts.length > 0 ? customParts.join(' / ') : 'Variante Base';
                const lv = localVariants.find(v => !matched.has(v.id) && v.attributes === customName);
                if (!lv) continue;
                matched.add(lv.id);
                await pool.query("UPDATE portal_variants SET odoo_prod_id=$1 WHERE id=$2", [ov.id, lv.id]);
                if (lv.image_base64) {
                    try {
                        const raw = lv.image_base64.split(',')[1] || lv.image_base64;
                        await executeKw('product.product', 'write', [[ov.id], { image_1920: raw }]);
                    } catch(e) { console.error('[SYNC UPDATE] photo failed:', e.message); }
                }
                if (lv.qty > 0 && locId) {
                    try { await applyOdooStock(ov.id, lv.qty, locId); } catch(e) { console.error('[SYNC UPDATE] stock failed:', e.message); }
                }
            }
        }
    }
}

// ── Helper: ejecutar DATA WEB 3 en Odoo (actualiza JSON del catálogo) ────────
async function triggerDataWeb3() {
    try {
        await executeKw('ir.actions.server', 'run', [[3047]]);
        console.log('[SYNC] ✓ DATA WEB 3 ejecutado — JSON v3 actualizado');
    } catch(e) {
        console.warn('[SYNC] DATA WEB 3 falló (no crítico):', e.message);
    }
}

// ── Helper: calcular precios divididos por presentación ──────────────────────
function calcPreciosPresentacion(item) {
    const detalUsd  = parseFloat(item.x_web3_detal_usd  || item.price_unidad) || 0;
    const comboUsd  = parseFloat(item.x_web3_combo_usd)  || 0;
    const docenaUsd = parseFloat(item.x_web3_docena_usd) || 0;
    const bultoUsd  = parseFloat(item.x_web3_bulto_usd)  || 0;
    const comboPiezas  = parseInt(item.x_web3_combo_piezas) || 3;
    const bultoPiezas  = parseInt(item.x_web3_bulto_piezas) || 24;

    return {
        detalUsd,
        comboUsd, comboPiezas,
        // Precio individual por pieza = precio_total / piezas (2 decimales)
        comboPieza:  comboPiezas  > 0 ? Math.round((comboUsd  / comboPiezas)  * 100) / 100 : comboUsd,
        docenaUsd,
        docenaPieza: Math.round((docenaUsd / 12)          * 100) / 100,
        bultoUsd, bultoPiezas,
        bultoPieza:  bultoPiezas  > 0 ? Math.round((bultoUsd  / bultoPiezas)  * 100) / 100 : bultoUsd,
    };
}

// ── Asegurar Tipo de Venta (no_variant) con Unidad + valores surtido ─────────
async function ensureTipoVentaAttr(item, existingAttrMap, existingValMap) {
    if (!existingAttrMap['Tipo de Venta']) {
        existingAttrMap['Tipo de Venta'] = await executeKw('product.attribute', 'create', [{ name: 'Tipo de Venta', create_variant: 'no_variant' }]);
    }
    const tvAttrId = existingAttrMap['Tipo de Venta'];
    try { await executeKw('product.attribute', 'write', [[tvAttrId], { create_variant: 'no_variant' }]); } catch(e) {}

    // Siempre crear valor "Unidad"
    const unidadKey = `${tvAttrId}_Unidad`;
    if (!existingValMap[unidadKey]) existingValMap[unidadKey] = await executeKw('product.attribute.value', 'create', [{ name: 'Unidad', attribute_id: tvAttrId }]);

    // Valores surtido (solo los habilitados)
    const surtidoNames = [];
    if (item.x_web3_combo_habilitado  && item.x_web3_combo_surtido)  surtidoNames.push('Combo (surtido)');
    if (item.x_web3_docena_habilitado && item.x_web3_docena_surtido) surtidoNames.push('Docena (surtido)');
    if (item.x_web3_bulto_habilitado  && item.x_web3_bulto_surtido)  surtidoNames.push('Bulto (surtido)');
    for (const vName of surtidoNames) {
        const k = `${tvAttrId}_${vName}`;
        if (!existingValMap[k]) existingValMap[k] = await executeKw('product.attribute.value', 'create', [{ name: vName, attribute_id: tvAttrId }]);
    }

    const allTvValIds = [existingValMap[unidadKey], ...surtidoNames.map(n => existingValMap[`${tvAttrId}_${n}`])];
    return { tvAttrId, allTvValIds, surtidoNames };
}

// ── Asignar precios a variantes (PL a nivel variante para precios divididos) ──
async function setVariantPricelists(tmplId, item, existingValMap, tvAttrId) {
    const { detalUsd, comboPieza, docenaPieza, bultoPieza, comboUsd, docenaUsd, bultoUsd } = calcPreciosPresentacion(item);

    const variants = await executeKw('product.product', 'search_read',
        [[['product_tmpl_id', '=', tmplId], ['active', '=', true]]],
        { fields: ['id', 'product_template_attribute_value_ids'] });

    if (variants.length === 0) return;

    // Leer PTAVs para identificar cuáles son variantes surtido vs normales
    const allPtavIds = new Set();
    variants.forEach(v => v.product_template_attribute_value_ids.forEach(id => allPtavIds.add(id)));
    let ptavNameMap = {};
    if (allPtavIds.size > 0) {
        const ptavs = await executeKw('product.template.attribute.value', 'search_read',
            [[['id', 'in', [...allPtavIds]]]], { fields: ['id', 'name', 'attribute_id'] });
        ptavs.forEach(pt => { ptavNameMap[pt.id] = pt.name; });
    }

    const costVal = parseFloat(item.x_web3_cost_usd || item.cost) || 0;

    for (const variant of variants) {
        // Es "surtido" si ALGUNO de sus atributos de variante tiene valor "Surtido"
        const isSurtido = variant.product_template_attribute_value_ids.some(id =>
            ptavNameMap[id] && ptavNameMap[id].toLowerCase() === 'surtido'
        );

        // Costo en product.product
        if (costVal > 0) {
            try { await executeKw('product.product', 'write', [[variant.id], { standard_price: costVal }]); } catch(e) {}
        }

        // Construir lista de PL a aplicar a esta variante
        const plEntries = [];

        if (isSurtido) {
            // Variante surtido: precio COMPLETO del combo/docena/bulto (sin dividir)
            if (item.x_web3_combo_habilitado  && item.x_web3_combo_surtido  && comboUsd  > 0) plEntries.push([10, comboUsd]);
            if (item.x_web3_docena_habilitado && item.x_web3_docena_surtido && docenaUsd > 0) plEntries.push([11, docenaUsd]);
            if (item.x_web3_bulto_habilitado  && item.x_web3_bulto_surtido  && bultoUsd  > 0) plEntries.push([12, bultoUsd]);
        } else {
            // Variante normal: precio DIVIDIDO por piezas
            if (detalUsd > 0) plEntries.push([9, detalUsd]);
            if (item.x_web3_combo_habilitado  && !item.x_web3_combo_surtido  && comboPieza  > 0) plEntries.push([10, comboPieza]);
            if (item.x_web3_docena_habilitado && !item.x_web3_docena_surtido && docenaPieza > 0) plEntries.push([11, docenaPieza]);
            if (item.x_web3_bulto_habilitado  && !item.x_web3_bulto_surtido  && bultoPieza  > 0) plEntries.push([12, bultoPieza]);
        }

        for (const [plId, price] of plEntries) {
            try {
                const existing = await executeKw('product.pricelist.item', 'search_read',
                    [[['pricelist_id', '=', plId], ['product_id', '=', variant.id]]],
                    { fields: ['id'] });
                if (existing.length > 0) {
                    await executeKw('product.pricelist.item', 'write', [[existing[0].id], { fixed_price: price }]);
                } else {
                    await executeKw('product.pricelist.item', 'create', [{
                        pricelist_id: plId, applied_on: '0_product_variant',
                        product_id: variant.id, compute_price: 'fixed', fixed_price: price
                    }]);
                }
            } catch(e) { console.warn('[SYNC] PL item error:', e.message); }
        }
    }
    console.log(`[SYNC] ✓ Precios por variante asignados: ${variants.length} variantes`);
}

// ── CREATE new Odoo product (new product flow) ────────────────────────────
async function syncCreateToOdoo(item, localVariants, customAttributes) {
    const { name, cost, price_unidad, category_id, image_base64, supplier_id } = item;

    const existingAttrMap = {}, existingValMap = {};
    const odooAttrs = await executeKw('product.attribute', 'search_read', [[]], { fields: ['id', 'name', 'create_variant'] });
    odooAttrs.forEach(a => existingAttrMap[a.name] = a.id);
    const odooVals = await executeKw('product.attribute.value', 'search_read', [[]], { fields: ['id', 'name', 'attribute_id'] });
    odooVals.forEach(v => { if (v.attribute_id) existingValMap[`${v.attribute_id[0]}_${v.name}`] = v.id; });

    const ptalPayload = [];
    const hasSurtido = (item.x_web3_combo_habilitado && item.x_web3_combo_surtido)
                    || (item.x_web3_docena_habilitado && item.x_web3_docena_surtido)
                    || (item.x_web3_bulto_habilitado  && item.x_web3_bulto_surtido);

    // ── 1. Tipo de Venta (no_variant): Unidad + valores surtido ───────────────
    const { tvAttrId, allTvValIds } = await ensureTipoVentaAttr(item, existingAttrMap, existingValMap);
    ptalPayload.push([0, 0, { attribute_id: tvAttrId, value_ids: [[6, 0, allTvValIds]] }]);

    // ── 2. Atributos custom (Color, Talla, etc.) ───────────────────────────────
    // Si hay presentación surtida: agregar "Surtido" como valor adicional en cada atributo
    for (const customAttr of customAttributes) {
        if (!customAttr.name || !customAttr.values || customAttr.values.length === 0) continue;
        if (!existingAttrMap[customAttr.name]) {
            existingAttrMap[customAttr.name] = await executeKw('product.attribute', 'create', [{ name: customAttr.name, create_variant: 'always' }]);
        }
        const attrId = existingAttrMap[customAttr.name];
        const values = [...customAttr.values];
        // Agregar "Surtido" para poder crear variante universal surtida
        if (hasSurtido && !values.map(v => v.toLowerCase()).includes('surtido')) values.push('Surtido');
        const valIds = [];
        for (const valName of values) {
            const key = `${attrId}_${valName}`;
            if (!existingValMap[key]) existingValMap[key] = await executeKw('product.attribute.value', 'create', [{ name: valName, attribute_id: attrId }]);
            valIds.push(existingValMap[key]);
        }
        ptalPayload.push([0, 0, { attribute_id: attrId, value_ids: [[6, 0, valIds]] }]);
    }

    const detalUsd = parseFloat(item.x_web3_detal_usd || price_unidad) || 0;
    const productPayload = {
        name, list_price: detalUsd, standard_price: parseFloat(cost) || 0,
        sale_ok: true, purchase_ok: true, is_published: true, is_storable: true,
        seller_ids: [[0, 0, { partner_id: supplier_id, delay: 1 }]],
        attribute_line_ids: ptalPayload,
        x_web3_detal_usd:         detalUsd,
        x_web3_cost_usd:          parseFloat(item.x_web3_cost_usd || cost) || 0,
        x_web3_combo_habilitado:  item.x_web3_combo_habilitado  || false,
        x_web3_combo_usd:         parseFloat(item.x_web3_combo_usd) || 0,
        x_web3_combo_piezas:      parseInt(item.x_web3_combo_piezas) || 3,
        x_web3_combo_surtido:     item.x_web3_combo_surtido  || false,
        x_web3_docena_habilitado: item.x_web3_docena_habilitado || false,
        x_web3_docena_usd:        parseFloat(item.x_web3_docena_usd) || 0,
        x_web3_docena_surtido:    item.x_web3_docena_surtido || false,
        x_web3_bulto_habilitado:  item.x_web3_bulto_habilitado  || false,
        x_web3_bulto_usd:         parseFloat(item.x_web3_bulto_usd) || 0,
        x_web3_bulto_piezas:      parseInt(item.x_web3_bulto_piezas) || 24,
        x_web3_bulto_surtido:     item.x_web3_bulto_surtido  || false,
    };
    if (category_id) productPayload.public_categ_ids = [[6, 0, [parseInt(category_id)]]];

    const tmplId = await executeKw('product.template', 'create', [productPayload]);

    if (image_base64) {
        const raw = image_base64.split(',')[1] || image_base64;
        await executeKw('product.template', 'write', [[tmplId], { image_1920: raw }]);
    }

    // ── 3. PL a nivel VARIANTE exclusivamente (sin fallback template)
    // NO crear PL a nivel template para evitar que el precio detal se aplique
    // a variantes surtido cuando Odoo busca precio por pricelist cascada
    await setVariantPricelists(tmplId, item, existingValMap, tvAttrId);

    // Match and sync variant assets
    if (localVariants.length > 0) {
        const attrOrder = { [presAttrId]: -1 };
        customAttributes.forEach((ca, idx) => {
            if (existingAttrMap[ca.name]) attrOrder[existingAttrMap[ca.name]] = idx;
        });

        const odooVariants = await executeKw('product.product', 'search_read',
            [[['product_tmpl_id', '=', tmplId]]],
            { fields: ['id', 'product_template_attribute_value_ids'] });

        const allPtavIds = new Set();
        odooVariants.forEach(v => (v.product_template_attribute_value_ids || []).forEach(id => allPtavIds.add(id)));
        let ptavNameMap = {}, ptavAttrMap = {};
        if (allPtavIds.size > 0) {
            const ptavs = await executeKw('product.template.attribute.value', 'search_read',
                [[['id', 'in', [...allPtavIds]]]], { fields: ['id', 'name', 'attribute_id'] });
            ptavs.forEach(pt => { ptavNameMap[pt.id] = pt.name; ptavAttrMap[pt.id] = pt.attribute_id[0]; });
        }

        const locId = await getStockLocId();
        const matched = new Set();

        await Promise.allSettled(odooVariants.map(async ov => {
            const customParts = (ov.product_template_attribute_value_ids || [])
                .filter(id => ptavAttrMap[id] !== presAttrId)
                .sort((a, b) => (attrOrder[ptavAttrMap[a]] ?? 99) - (attrOrder[ptavAttrMap[b]] ?? 99))
                .map(id => ptavNameMap[id] || '').filter(Boolean);
            const customName = customParts.length > 0 ? customParts.join(' / ') : 'Variante Base';

            const lv = localVariants.find(v => !matched.has(v.id) && v.attributes === customName);
            if (!lv) return;
            matched.add(lv.id);

            await pool.query("UPDATE portal_variants SET odoo_prod_id=$1 WHERE id=$2", [ov.id, lv.id]);
            console.log(`[SYNC] Variant "${customName}" → odoo id=${ov.id}`);

            if (lv.image_base64) {
                try {
                    const raw = lv.image_base64.split(',')[1] || lv.image_base64;
                    await executeKw('product.product', 'write', [[ov.id], { image_1920: raw }]);
                    console.log(`[SYNC] ✓ Photo for "${customName}"`);
                } catch(e) { console.error(`[SYNC] ✗ Photo for "${customName}":`, e.message); }
            }

            if (lv.qty > 0 && locId) {
                try {
                    await applyOdooStock(ov.id, lv.qty, locId);
                    console.log(`[SYNC] ✓ Stock for "${customName}": qty=${lv.qty}`);
                } catch(e) { console.error(`[SYNC] ✗ Stock for "${customName}":`, e.message); }
            }
        }));
    }

    return tmplId;
}

// ── Main processor ─────────────────────────────────────────────────────────
async function processSingleProduct(item) {
    const tempId = item.id;
    try {
        const claimed = await pool.query(
            "UPDATE portal_products SET sync_status='processing' WHERE id=$1 AND sync_status IN ('pending','error') RETURNING id",
            [tempId]
        );
        if (claimed.rowCount === 0) return;

        let customAttributes = [];
        try { customAttributes = JSON.parse(item.custom_attributes || '[]'); } catch(e) {}

        const vRes = await pool.query("SELECT * FROM portal_variants WHERE product_id=$1", [tempId]);
        const localVariants = vRes.rows;

        if (item.odoo_tmpl_id) {
            // ── EDIT: product already exists in Odoo → UPDATE ────────────
            await syncUpdateToOdoo(item.odoo_tmpl_id, item, localVariants);
            await pool.query("UPDATE portal_products SET sync_status='synced' WHERE id=$1", [tempId]);
            console.log(`[SYNC] ✓ Updated "${item.name}" (tmplId=${item.odoo_tmpl_id})`);
        } else {
            // ── NEW: product doesn't exist in Odoo yet → CREATE ──────────
            const tmplId = await syncCreateToOdoo(item, localVariants, customAttributes);
            await pool.query("UPDATE portal_products SET sync_status='synced', odoo_tmpl_id=$1 WHERE id=$2", [tmplId, tempId]);
            console.log(`[SYNC] ✓ Created "${item.name}" → Odoo tmplId=${tmplId}`);
        }

        // ── Ejecutar DATA WEB 3 automáticamente para actualizar el catálogo ─
        triggerDataWeb3();

    } catch (syncErr) {
        console.error(`[SYNC] ✗ "${item.name}":`, syncErr.message);
        try {
            await pool.query("UPDATE portal_products SET sync_status='error', sync_error=$1 WHERE id=$2", [syncErr.message, tempId]);
        } catch(e) {}
    }
}

async function processQueue() {
    try {
        const qRes = await pool.query(
            "SELECT * FROM portal_products WHERE sync_status IN ('pending','error') ORDER BY created_at ASC LIMIT 10"
        );
        if (qRes.rows.length === 0) return;
        console.log(`[SYNC] Processing ${qRes.rows.length} product(s)...`);
        await Promise.allSettled(qRes.rows.map(item => processSingleProduct(item)));
    } catch (err) {
        console.error("[SYNC] Queue error:", err.message);
    }
}

function startWorker() {
    setInterval(processQueue, 15000);
    console.log("[SYNC] Worker started — create/update aware, parallel, every 15s");
}

module.exports = { startWorker };
