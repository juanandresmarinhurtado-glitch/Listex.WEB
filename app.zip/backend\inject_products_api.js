const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const productsApi = `
// ==========================================
// SUPPLIER PRODUCTS API
// ==========================================

app.get('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        
        // Find supplier info records for this partner
        const supplierInfos = await executeKw('product.supplierinfo', 'search_read', [
            [['partner_id', '=', req.user.id]],
            ['product_tmpl_id']
        ]);
        
        if (supplierInfos.length === 0) {
            return res.json({ success: true, products: [] });
        }
        
        const templateIds = supplierInfos.map(s => s.product_tmpl_id[0]);
        
        const products = await executeKw('product.template', 'search_read', [
            [['id', 'in', templateIds]],
            ['id', 'name', 'list_price', 'standard_price', 'qty_available', 'is_published']
        ]);
        
        res.json({ success: true, products: products });
    } catch (error) {
        console.error("Get Products Error:", error);
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const { name, cost, priceUnidad, priceDocena, priceBulto, categoryId, sizes, colors, imageBase64 } = req.body;
        
        // 1. Create Product Template
        const productData = {
            name: name,
            type: 'product',
            list_price: parseFloat(priceUnidad) || 0,
            standard_price: parseFloat(cost) || 0,
            sale_ok: true,
            purchase_ok: true,
            is_published: false // Require admin approval or publish immediately? User said they can publish. We set to false just in case, or true? Let's do true.
            // Odoo website uses is_published for visibility
        };
        
        if (imageBase64) {
            productData.image_1920 = imageBase64.split(',')[1] || imageBase64;
        }
        
        if (categoryId) {
            productData.public_categ_ids = [[6, 0, [parseInt(categoryId)]]];
        }
        
        const tmplId = await executeKw('product.template', 'create', [productData]);
        
        // Publish it on website
        await executeKw('product.template', 'write', [[tmplId], { is_published: true }]);
        
        // 2. Link Supplier
        await executeKw('product.supplierinfo', 'create', [{
            partner_id: req.user.id,
            product_tmpl_id: tmplId,
            delay: 1
        }]);
        
        // 3. Create Attributes (Presentación)
        // Hardcoded attribute ID 34 = Presentación
        let presentacionValues = ['Unidad'];
        if (priceDocena) presentacionValues.push('Docena');
        if (priceBulto) presentacionValues.push('Bulto');
        
        // Find Value IDs for these string values in attribute 34
        const attrValues = await executeKw('product.attribute.value', 'search_read', [
            [['attribute_id', '=', 34], ['name', 'in', presentacionValues]],
            ['id', 'name']
        ]);
        
        const valueIdsToLink = attrValues.map(v => v.id);
        
        // Link Attribute Line
        if (valueIdsToLink.length > 0) {
            await executeKw('product.template.attribute.line', 'create', [{
                product_tmpl_id: tmplId,
                attribute_id: 34,
                value_ids: [[6, 0, valueIdsToLink]]
            }]);
        }
        
        // 4. Set Pricelist Items for Docena (TIPO3 = id 3) and Bulto (TIPO2 = id 2)
        if (priceDocena) {
            await executeKw('product.pricelist.item', 'create', [{
                pricelist_id: 3,
                applied_on: '1_product',
                product_tmpl_id: tmplId,
                compute_price: 'fixed',
                fixed_price: parseFloat(priceDocena)
            }]);
        }
        
        if (priceBulto) {
            await executeKw('product.pricelist.item', 'create', [{
                pricelist_id: 2,
                applied_on: '1_product',
                product_tmpl_id: tmplId,
                compute_price: 'fixed',
                fixed_price: parseFloat(priceBulto)
            }]);
        }
        
        res.json({ success: true, message: "Producto creado exitosamente", id: tmplId });
    } catch (error) {
        console.error("Create Product Error:", error);
        res.status(500).json({ error: error.message });
    }
});

// Categories endpoint for the form
app.get('/api/categories', async (req, res) => {
    try {
        await authenticate();
        const cats = await executeKw('product.public.category', 'search_read', [[], ['id', 'name']]);
        res.json({ success: true, categories: cats });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ==========================================
`;

if (!serverJs.includes("/api/supplier/products")) {
    serverJs = serverJs.replace("app.listen(PORT", productsApi + "\napp.listen(PORT");
    fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
    console.log("Injected product routes");
} else {
    console.log("Product routes already exist");
}
