// ─── Helpers compartidos para sincronización Odoo ────────────────────────────
// Usados por: syncWorker.js y routes/products.js (createProductInOdooBackground)

/**
 * Calcula precios divididos por presentación
 */
function calcPreciosPresentacion(item) {
    const detalUsd  = parseFloat(item.x_web3_detal_usd  || item.price_unidad) || 0;
    const comboUsd  = parseFloat(item.x_web3_combo_usd)  || 0;
    const docenaUsd = parseFloat(item.x_web3_docena_usd) || 0;
    const bultoUsd  = parseFloat(item.x_web3_bulto_usd)  || 0;
    const comboPiezas  = parseInt(item.x_web3_combo_piezas) || 3;
    const bultoPiezas  = parseInt(item.x_web3_bulto_piezas) || 24;
    return {
        detalUsd,
        comboUsd, comboPiezas,
        comboPieza:  comboPiezas  > 0 ? Math.round((comboUsd  / comboPiezas)  * 100) / 100 : comboUsd,
        docenaUsd,
        docenaPieza: Math.round((docenaUsd / 12) * 100) / 100,
        bultoUsd, bultoPiezas,
        bultoPieza:  bultoPiezas  > 0 ? Math.round((bultoUsd  / bultoPiezas)  * 100) / 100 : bultoUsd,
    };
}

/**
 * Asegura el atributo Tipo de Venta (no_variant) con:
 * - Valor "Unidad" (siempre)
 * - Valores surtido (según item.x_web3_*_surtido)
 */
async function ensureTipoVentaAttr(item, existingAttrMap, existingValMap, executeKw) {
    if (!existingAttrMap['Tipo de Venta']) {
        existingAttrMap['Tipo de Venta'] = await executeKw('product.attribute', 'create',
            [{ name: 'Tipo de Venta', create_variant: 'no_variant' }]);
    }
    const tvAttrId = existingAttrMap['Tipo de Venta'];
    try { await executeKw('product.attribute', 'write', [[tvAttrId], { create_variant: 'no_variant' }]); } catch(e) {}

    // Siempre crear "Unidad"
    const unidadKey = `${tvAttrId}_Unidad`;
    if (!existingValMap[unidadKey]) {
        existingValMap[unidadKey] = await executeKw('product.attribute.value', 'create',
            [{ name: 'Unidad', attribute_id: tvAttrId }]);
    }

    // Valores surtido opcionales
    const surtidoNames = [];
    if (item.x_web3_combo_habilitado  && item.x_web3_combo_surtido)  surtidoNames.push('Combo (surtido)');
    if (item.x_web3_docena_habilitado && item.x_web3_docena_surtido) surtidoNames.push('Docena (surtido)');
    if (item.x_web3_bulto_habilitado  && item.x_web3_bulto_surtido)  surtidoNames.push('Bulto (surtido)');
    for (const vName of surtidoNames) {
        const k = `${tvAttrId}_${vName}`;
        if (!existingValMap[k]) {
            existingValMap[k] = await executeKw('product.attribute.value', 'create',
                [{ name: vName, attribute_id: tvAttrId }]);
        }
    }

    const allTvValIds = [
        existingValMap[unidadKey],
        ...surtidoNames.map(n => existingValMap[`${tvAttrId}_${n}`])
    ];
    return { tvAttrId, allTvValIds, surtidoNames };
}

/**
 * Asigna precios a nivel variante en las listas PL 9-12:
 * - Variantes normales: precio detal (PL9) + precio dividido combo/docena/bulto
 * - Variante surtido (Surtido/Surtido): precio completo combo/docena/bulto
 */
async function setVariantPricelists(tmplId, item, executeKw) {
    const precios = calcPreciosPresentacion(item);
    const { detalUsd, comboPieza, docenaPieza, bultoPieza, comboUsd, docenaUsd, bultoUsd } = precios;

    const variants = await executeKw('product.product', 'search_read',
        [[['product_tmpl_id', '=', tmplId], ['active', '=', true]]],
        { fields: ['id', 'display_name', 'product_template_attribute_value_ids'] });

    if (variants.length === 0) return;

    // Leer PTAVs
    const allPtavIds = new Set();
    variants.forEach(v => v.product_template_attribute_value_ids.forEach(id => allPtavIds.add(id)));
    let ptavNameMap = {};
    if (allPtavIds.size > 0) {
        const ptavs = await executeKw('product.template.attribute.value', 'search_read',
            [[['id', 'in', [...allPtavIds]]]], { fields: ['id', 'name', 'attribute_id'] });
        ptavs.forEach(pt => { ptavNameMap[pt.id] = pt.name; });
    }

    const costVal = parseFloat(item.x_web3_cost_usd || item.cost) || 0;

    for (const variant of variants) {
        // Identificar si es variante surtido (todos los atributos de variante = "Surtido")
        const varPtavs = variant.product_template_attribute_value_ids
            .map(id => ptavNameMap[id])
            .filter(n => n && n !== 'Unidad' && !['Combo (surtido)', 'Docena (surtido)', 'Bulto (surtido)'].includes(n));
        const isSurtido = varPtavs.length > 0 && varPtavs.every(n => n.toLowerCase() === 'surtido');

        // Costo por variante (Odoo 18)
        if (costVal > 0) {
            try { await executeKw('product.product', 'write', [[variant.id], { standard_price: costVal }]); } catch(e) {}
        }

        // PL entries según tipo de variante
        const plEntries = [];
        if (isSurtido) {
            // Variante surtido: SOLO precio completo de presentación surtida
            // NO agregar PL9 (detal) — evita que Odoo use precio detal al buscar en cascada
            if (item.x_web3_docena_habilitado && item.x_web3_docena_surtido && docenaUsd > 0)
                plEntries.push([11, docenaUsd]);
            if (item.x_web3_bulto_habilitado  && item.x_web3_bulto_surtido  && bultoUsd  > 0)
                plEntries.push([12, bultoUsd]);
            // Eliminar cualquier PL9 que pudiera existir en esta variante surtido
            try {
                const oldPl9 = await executeKw('product.pricelist.item', 'search',
                    [[['pricelist_id', '=', 9], ['product_id', '=', variant.id]]]);
                if (oldPl9.length > 0) await executeKw('product.pricelist.item', 'unlink', [oldPl9]);
            } catch(e) {}
        } else {
            if (detalUsd > 0) plEntries.push([9, detalUsd]);
            if (item.x_web3_combo_habilitado  && !item.x_web3_combo_surtido  && comboPieza  > 0)
                plEntries.push([10, comboPieza]);
            if (item.x_web3_docena_habilitado && !item.x_web3_docena_surtido && docenaPieza > 0)
                plEntries.push([11, docenaPieza]);
            if (item.x_web3_bulto_habilitado  && !item.x_web3_bulto_surtido  && bultoPieza  > 0)
                plEntries.push([12, bultoPieza]);
        }

        for (const [plId, price] of plEntries) {
            try {
                const existing = await executeKw('product.pricelist.item', 'search_read',
                    [[['pricelist_id', '=', plId], ['product_id', '=', variant.id]]],
                    { fields: ['id'] });
                if (existing.length > 0) {
                    await executeKw('product.pricelist.item', 'write',
                        [[existing[0].id], { fixed_price: price }]);
                } else {
                    await executeKw('product.pricelist.item', 'create', [{
                        pricelist_id: plId, applied_on: '0_product_variant',
                        product_id: variant.id, compute_price: 'fixed', fixed_price: price
                    }]);
                }
            } catch(e) { console.warn('[PL] Error variante', variant.id, ':', e.message); }
        }
    }
    console.log(`[SYNC] ✓ PL por variante: ${variants.length} variantes procesadas`);
}

module.exports = { calcPreciosPresentacion, ensureTipoVentaAttr, setVariantPricelists };
