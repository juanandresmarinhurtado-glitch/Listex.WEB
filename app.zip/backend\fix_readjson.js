const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const injectionCode = `
const path = require('path');
const queueFile = path.join(__dirname, 'queue.json');
const variantsFile = path.join(__dirname, 'queue_variants.json');

function readJson(file) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch(e) { return {}; } }
function writeJson(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }

app.get('/api/supplier/products', authenticateSupplier, async (req, res) => {`;

serverJs = serverJs.replace(`app.get('/api/supplier/products', authenticateSupplier, async (req, res) => {`, injectionCode);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Fixed readJson missing error.");
