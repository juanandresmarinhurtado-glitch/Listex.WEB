/* ============================================= */
/* APP.JS - Lógica principal de la aplicación    */
/* Listex - Plataforma mayorista                 */
/* ============================================= */

// ---- Constants ----
const API_CATALOG_URL = 'https://listex.odoo.com/web/content/17653/api_catalogo_jerarquia.json';
const API_CATALOG_FALLBACK = 'https://listex.odoo.com/web/content/16027/api_catalogo_listex.json';
const BACKEND_URL = 'http://localhost:3000';
const WHATSAPP_PHONE = '584244329649';

// ---- Global State ----
let allProducts = [];
let productIndex = {};       // grouped by product name (handle)
let parentCategories = [];
let childCategories = {};    // keyed by parent category nombre
let cart = {};
let currentOrderId = null;

/* ============================================= */
/* 1. INIT APP                                   */
/* ============================================= */
async function initApp() {
  showSkeletons();

  try {
    let data = null;
    const isProduction = window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1';
    // Use relative path to ensure it hits the Render backend in production, or localhost in dev
    const catalogUrl = isProduction ? '/api/catalog' : `${BACKEND_URL}/api/catalog`;

    try {
      const response = await fetch(catalogUrl);
      if (!response.ok) throw new Error('Proxy fetch failed: ' + response.status);
      data = await response.json();
    } catch (error) {
      console.error('Error fetching from catalog proxy:', error);
      showToast('Error al cargar el catálogo. Intenta recargar la página.', 'error');
      removeSkeletons();
      return;
    }

    if (data) {
      // The JSON may be an array directly or an object with a key containing products
      if (Array.isArray(data)) {
        allProducts = data;
      } else if (data.productos && Array.isArray(data.productos)) {
        allProducts = data.productos;
      } else if (data.products && Array.isArray(data.products)) {
        allProducts = data.products;
      } else if (data.data && Array.isArray(data.data)) {
        allProducts = data.data;
      } else {
        // Try to find the first array property
        const keys = Object.keys(data);
        for (const key of keys) {
          if (Array.isArray(data[key]) && data[key].length > 0) {
            allProducts = data[key];
            break;
          }
        }
        if (allProducts.length === 0) {
          allProducts = [data];
        }
      }
    }

    console.log(`Loaded ${allProducts.length} products from catalog`);

    buildProductIndex();
    buildCategoryTree();
    renderNavCategories();
    renderSections();

    loadCartFromStorage();
    updateCartBadge();

    setupSearch();
    setupScrollAnimations();
    setupHeaderScroll();
    setupCartDrawer();
    setupMobileMenu();

  } catch (error) {
    console.error('Error during app initialization:', error);
    showToast('Ocurrió un error al inicializar. Intenta recargar.', 'error');
    removeSkeletons();
  }
}

/* ============================================= */
/* 2. BUILD PRODUCT INDEX                        */
/* ============================================= */
function buildProductIndex() {
  productIndex = {};

  for (let i = 0; i < allProducts.length; i++) {
    const product = allProducts[i];
    const handle = product.nombre || product.name || ('producto-' + (product.id_producto || i));

    if (!productIndex[handle]) {
      productIndex[handle] = [];
    }
    productIndex[handle].push(product);
  }

  console.log(`Built product index with ${Object.keys(productIndex).length} unique product groups`);
}

/* ============================================= */
/* 3. BUILD CATEGORY TREE                        */
/* ============================================= */
function buildCategoryTree() {
  const parentSet = new Map();
  const childMap = {};
  const categoryCounts = {};

  for (const product of allProducts) {
    const cats = product.categorias_web || [];

    for (const cat of cats) {
      const catName = cat.nombre || cat.name || '';
      if (!catName) continue;

      if (cat.es_padre === true || cat.es_padre === 'true' || cat.es_padre === 1) {
        if (!parentSet.has(catName)) {
          parentSet.set(catName, {
            nombre: catName,
            count: 0,
            image: null
          });
        }
        const parentObj = parentSet.get(catName);
        parentObj.count++;
        if (!parentObj.image && product.imagen_url) {
          parentObj.image = product.imagen_url;
        }
      } else {
        const parentName = cat.padre_nombre || cat.parent_name || '';
        if (!childMap[parentName]) {
          childMap[parentName] = new Map();
        }
        if (!childMap[parentName].has(catName)) {
          childMap[parentName].set(catName, {
            nombre: catName,
            padre_nombre: parentName,
            count: 0
          });
        }
        childMap[parentName].get(catName).count++;
      }

      // Count products per category (for any category name)
      if (!categoryCounts[catName]) {
        categoryCounts[catName] = 0;
      }
      categoryCounts[catName]++;
    }

    // Also count by categoria_principal
    const mainCat = product.categoria_principal || product.main_category || '';
    if (mainCat) {
      if (!categoryCounts[mainCat]) {
        categoryCounts[mainCat] = 0;
      }
      categoryCounts[mainCat]++;
    }
  }

  parentCategories = Array.from(parentSet.values());

  // If no parent categories found from categorias_web, try to build from categoria_principal
  if (parentCategories.length === 0) {
    const mainCatMap = new Map();
    for (const product of allProducts) {
      const mainCat = product.categoria_principal || product.main_category || '';
      if (mainCat) {
        if (!mainCatMap.has(mainCat)) {
          mainCatMap.set(mainCat, {
            nombre: mainCat,
            count: 0,
            image: null
          });
        }
        const obj = mainCatMap.get(mainCat);
        obj.count++;
        if (!obj.image && product.imagen_url) {
          obj.image = product.imagen_url;
        }
      }
    }
    parentCategories = Array.from(mainCatMap.values());
  }

  // Sort parent categories by count descending
  parentCategories.sort((a, b) => b.count - a.count);

  // Convert child maps to arrays
  childCategories = {};
  for (const parentName in childMap) {
    childCategories[parentName] = Array.from(childMap[parentName].values());
    childCategories[parentName].sort((a, b) => b.count - a.count);
  }

  // Update parent category counts with accurate totals from categoryCounts
  for (const parent of parentCategories) {
    if (categoryCounts[parent.nombre] && categoryCounts[parent.nombre] > parent.count) {
      parent.count = categoryCounts[parent.nombre];
    }
  }

  console.log(`Category tree: ${parentCategories.length} parent categories`);
}

/* ============================================= */
/* 4. RENDER NAV CATEGORIES                      */
/* ============================================= */
function renderNavCategories() {
  const navLinksContainer = document.getElementById('nav-links');
  if (!navLinksContainer || parentCategories.length === 0) return;

  // Clear existing default links
  navLinksContainer.innerHTML = '';

  // Show up to 8 parent categories in nav
  const maxNav = 8;
  const navCats = parentCategories.slice(0, maxNav);

  for (const cat of navCats) {
    const link = document.createElement('a');
    link.className = 'nav-link';
    link.href = 'category.html?cat=' + encodeURIComponent(cat.nombre.toLowerCase());
    link.textContent = cat.nombre;
    link.title = cat.nombre + ' (' + cat.count + ' productos)';
    navLinksContainer.appendChild(link);
  }
}

/* ============================================= */
/* 5. RENDER SECTIONS                            */
/* ============================================= */
function renderSections() {
  // Get unique products (first of each group = deduplicated)
  const uniqueProducts = getUniqueProducts();

  // --- Categories Grid ---
  renderCategoriesGrid();

  // --- Offers: sort by price ascending, take top 15 ---
  const offersProducts = [...uniqueProducts]
    .filter(p => p.precio_base != null && p.precio_base > 0)
    .sort((a, b) => parseFloat(a.precio_base) - parseFloat(b.precio_base))
    .slice(0, 15);
  renderProductsToContainer(offersProducts, 'offers-grid');

  // --- Most Viewed: sort by pseudo views descending, take top 15 ---
  const mostViewedProducts = [...uniqueProducts]
    .sort((a, b) => {
      const handleA = a.nombre || '';
      const handleB = b.nombre || '';
      return getPseudoViews(handleB) - getPseudoViews(handleA);
    })
    .slice(0, 15);
  renderProductsToContainer(mostViewedProducts, 'most-viewed-grid');

  // --- New Arrivals: sort by id_producto descending, take top 15 ---
  const newArrivals = [...uniqueProducts]
    .sort((a, b) => {
      const idA = parseInt(a.id_producto) || 0;
      const idB = parseInt(b.id_producto) || 0;
      return idB - idA;
    })
    .slice(0, 15);
  renderProductsToContainer(newArrivals, 'new-arrivals-grid');

  removeSkeletons();
}

/**
 * Get unique products (first variant of each product group)
 */
function getUniqueProducts() {
  const unique = [];
  for (const handle in productIndex) {
    if (productIndex[handle].length > 0) {
      unique.push(productIndex[handle][0]);
    }
  }
  return unique;
}

/* ============================================= */
/* 6. RENDER PRODUCTS TO CONTAINER               */
/* ============================================= */
function renderProductsToContainer(products, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.innerHTML = '';

  if (products.length === 0) {
    container.innerHTML = '<p style="text-align:center;color:#94a3b8;padding:40px;grid-column:1/-1;">No se encontraron productos en esta sección.</p>';
    return;
  }

  for (const product of products) {
    const card = createProductCard(product);
    container.appendChild(card);
  }
}

/**
 * Create a product card element
 */
function createProductCard(product) {
  const card = document.createElement('div');
  card.className = 'product-card reveal';

  const handle = product.nombre || '';
  const imageUrl = product.imagen_url || '';
  const category = product.categoria_principal || '';
  const price = parseFloat(product.precio_base) || 0;
  const currency = product.moneda || '$';
  const variantes = product.variantes || [];
  const tarifas = product.tarifas_multiples || [];

  // Calculate badge
  const badgeInfo = calculateBadge(product, tarifas);

  // Calculate discount price if applicable
  const discountInfo = calculateDiscount(price, tarifas);

  // Get size pills from variants
  const sizePills = extractSizes(variantes);

  // Build card HTML
  card.innerHTML = `
    <div class="product-card-image-wrap" onclick="openProductDetail('${escapeHtml(handle)}')">
      ${imageUrl
        ? `<img src="${escapeHtml(imageUrl)}" alt="${escapeHtml(handle)}" loading="lazy" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22200%22 fill=%22%23e2e8f0%22><rect width=%22200%22 height=%22200%22/><text x=%2250%25%22 y=%2250%25%22 text-anchor=%22middle%22 dy=%22.3em%22 fill=%22%2394a3b8%22 font-size=%2214%22>Sin imagen</text></svg>';">`
        : `<div style="width:100%;height:100%;background:var(--gray-100);display:flex;align-items:center;justify-content:center;color:var(--gray-400);font-size:0.85rem;">Sin imagen</div>`
      }
      ${badgeInfo.text ? `<span class="product-card-badge ${badgeInfo.class}">${badgeInfo.text}</span>` : ''}
      <button class="product-card-wishlist" onclick="event.stopPropagation();toggleWishlist(this,'${escapeHtml(handle)}')" aria-label="Agregar a favoritos">
        <svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
      </button>
    </div>
    <div class="product-card-body">
      ${category ? `<span class="product-card-category">${escapeHtml(category)}</span>` : ''}
      <h3 class="product-card-name" title="${escapeHtml(handle)}">${escapeHtml(handle)}</h3>
      <div class="product-card-price">
        <span class="product-card-price-current">${currency}${formatPrice(discountInfo.currentPrice)}</span>
        ${discountInfo.hasDiscount ? `<span class="product-card-price-old">${currency}${formatPrice(discountInfo.originalPrice)}</span>` : ''}
      </div>
      ${sizePills.length > 0 ? `
        <div class="product-card-sizes">
          ${sizePills.slice(0, 6).map(s => `<span class="size-pill">${escapeHtml(s)}</span>`).join('')}
          ${sizePills.length > 6 ? `<span class="size-pill">+${sizePills.length - 6}</span>` : ''}
        </div>
      ` : ''}
    </div>
    <div class="product-card-actions">
      <button class="product-card-btn" onclick="openProductDetail('${escapeHtml(handle)}')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        Ver detalles
      </button>
    </div>
  `;

  return card;
}

/**
 * Calculate badge information for a product
 */
function calculateBadge(product, tarifas) {
  // Check if there's a discount via tarifas_multiples
  const price = parseFloat(product.precio_base) || 0;

  if (tarifas && tarifas.length > 0) {
    // Look for a tarifa with a lower price (representing a discount)
    for (const tarifa of tarifas) {
      const tarifaPrice = parseFloat(tarifa.precio) || parseFloat(tarifa.price) || 0;
      if (tarifaPrice > 0 && tarifaPrice < price) {
        const discountPct = Math.round(((price - tarifaPrice) / price) * 100);
        if (discountPct >= 5) {
          return { text: `-${discountPct}%`, class: 'badge-discount' };
        }
      }
    }
  }

  // Check if product might be "new" (high ID = recent)
  const id = parseInt(product.id_producto) || 0;
  const hashVal = simpleHash(product.nombre || '');

  // Pseudo-random: some products get NEW badge, some get small discount badge
  if (hashVal % 5 === 0) {
    return { text: 'NUEVO', class: 'badge-new' };
  } else if (hashVal % 7 === 0) {
    const fakeDiscount = 10 + (hashVal % 25);
    return { text: `-${fakeDiscount}%`, class: 'badge-discount' };
  } else if (hashVal % 11 === 0) {
    return { text: 'TOP', class: 'badge-hot' };
  }

  return { text: '', class: '' };
}

/**
 * Calculate discount from tarifas_multiples
 */
function calculateDiscount(basePrice, tarifas) {
  if (!tarifas || tarifas.length === 0) {
    return { hasDiscount: false, currentPrice: basePrice, originalPrice: basePrice };
  }

  // Find lowest tarifa price
  let lowestPrice = basePrice;
  for (const tarifa of tarifas) {
    const tp = parseFloat(tarifa.precio) || parseFloat(tarifa.price) || 0;
    if (tp > 0 && tp < lowestPrice) {
      lowestPrice = tp;
    }
  }

  if (lowestPrice < basePrice) {
    return {
      hasDiscount: true,
      currentPrice: lowestPrice,
      originalPrice: basePrice
    };
  }

  return { hasDiscount: false, currentPrice: basePrice, originalPrice: basePrice };
}

/**
 * Extract size labels from variantes array
 */
function extractSizes(variantes) {
  if (!variantes || !Array.isArray(variantes) || variantes.length === 0) return [];

  const sizes = new Set();
  for (const v of variantes) {
    // Try common attribute names for size
    const size = v.talla || v.size || v.talla_nombre || v.size_name || v.atributo_valor || '';
    if (size) {
      sizes.add(String(size));
    }
  }
  return Array.from(sizes);
}

/* ============================================= */
/* 7. RENDER CATEGORIES GRID                     */
/* ============================================= */
function renderCategoriesGrid() {
  const container = document.getElementById('categories-grid');
  if (!container) return;

  container.innerHTML = '';

  if (parentCategories.length === 0) {
    container.innerHTML = '<p style="text-align:center;color:#94a3b8;padding:40px;grid-column:1/-1;">Cargando categorías...</p>';
    return;
  }

  for (const cat of parentCategories) {
    const card = document.createElement('a');
    card.className = 'category-card reveal';
    card.href = 'category.html?cat=' + encodeURIComponent(cat.nombre.toLowerCase());

    const imageHtml = cat.image
      ? `<img class="category-card-img" src="${escapeHtml(cat.image)}" alt="${escapeHtml(cat.nombre)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
         <div class="category-card-placeholder" style="display:none;">
           <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="2" width="20" height="20" rx="2"/><circle cx="8" cy="8" r="2"/><path d="m21 15-5-5L5 21"/></svg>
         </div>`
      : `<div class="category-card-placeholder">
           <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="2" width="20" height="20" rx="2"/><circle cx="8" cy="8" r="2"/><path d="m21 15-5-5L5 21"/></svg>
         </div>`;

    card.innerHTML = `
      ${imageHtml}
      <div class="category-card-overlay">
        <span class="category-card-name">${escapeHtml(cat.nombre)}</span>
        <span class="category-card-count">${cat.count} producto${cat.count !== 1 ? 's' : ''}</span>
      </div>
    `;

    container.appendChild(card);
  }
}

/* ============================================= */
/* 8. GET PSEUDO VIEWS                           */
/* ============================================= */
function getPseudoViews(handle) {
  // Check if Firebase is available and has a cached view count
  if (typeof window._viewCounts === 'object' && window._viewCounts[handle] != null) {
    return window._viewCounts[handle];
  }

  // Fallback: generate a pseudo-random but deterministic number based on handle hash
  const hash = simpleHash(handle);
  // Generate views between 50 and 5000 based on hash
  return 50 + (hash % 4951);
}

/**
 * Simple string hash function (deterministic)
 */
function simpleHash(str) {
  let hash = 0;
  if (!str || str.length === 0) return hash;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash);
}

/**
 * Try to fetch real view counts from Firebase
 */
async function fetchFirebaseViews() {
  try {
    if (typeof firebase !== 'undefined' && firebase.firestore) {
      const db = firebase.firestore();
      const snapshot = await db.collection('product_views').get();
      window._viewCounts = {};
      snapshot.forEach(doc => {
        window._viewCounts[doc.id] = doc.data().views || 0;
      });
      console.log('Loaded Firebase view counts:', Object.keys(window._viewCounts).length);
    }
  } catch (error) {
    console.warn('Could not fetch Firebase views, using pseudo-views:', error.message);
  }
}

/* ============================================= */
/* 9. SEARCH FUNCTIONALITY                       */
/* ============================================= */
function setupSearch() {
  const searchInput = document.getElementById('search-input');
  const searchResults = document.getElementById('search-results');
  if (!searchInput || !searchResults) return;

  let debounceTimer = null;

  searchInput.addEventListener('input', function () {
    clearTimeout(debounceTimer);
    const query = this.value.trim().toLowerCase();

    if (query.length < 2) {
      searchResults.classList.remove('active');
      searchResults.innerHTML = '';
      return;
    }

    debounceTimer = setTimeout(() => {
      performSearch(query);
    }, 300);
  });

  searchInput.addEventListener('focus', function () {
    const query = this.value.trim().toLowerCase();
    if (query.length >= 2 && searchResults.children.length > 0) {
      searchResults.classList.add('active');
    }
  });

  // Close search results on click outside
  document.addEventListener('click', function (e) {
    const searchBar = document.getElementById('search-bar');
    if (searchBar && !searchBar.contains(e.target)) {
      searchResults.classList.remove('active');
    }
  });

  // Close on Escape
  searchInput.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      searchResults.classList.remove('active');
      this.blur();
    }
  });
}

/**
 * Perform search and display results
 */
function performSearch(query) {
  const searchResults = document.getElementById('search-results');
  if (!searchResults) return;

  const words = query.split(/\s+/).filter(w => w.length > 0);

  // Search through unique product handles
  const results = [];
  const seen = new Set();

  for (const product of allProducts) {
    const handle = product.nombre || '';
    if (seen.has(handle)) continue;

    const searchableText = [
      handle,
      product.descripcion || '',
      product.categoria_principal || '',
      product.description || ''
    ].join(' ').toLowerCase();

    // All words must match
    const allMatch = words.every(word => searchableText.includes(word));

    if (allMatch) {
      seen.add(handle);
      results.push(product);
      if (results.length >= 10) break;
    }
  }

  if (results.length === 0) {
    searchResults.innerHTML = '<div class="search-no-results">No se encontraron productos para "' + escapeHtml(query) + '"</div>';
    searchResults.classList.add('active');
    return;
  }

  searchResults.innerHTML = '';
  for (const product of results) {
    const item = document.createElement('div');
    item.className = 'search-result-item';

    const handle = product.nombre || '';
    const imageUrl = product.imagen_url || '';
    const price = parseFloat(product.precio_base) || 0;
    const currency = product.moneda || '$';

    item.innerHTML = `
      ${imageUrl
        ? `<img src="${escapeHtml(imageUrl)}" alt="${escapeHtml(handle)}" loading="lazy" onerror="this.style.display='none';">`
        : `<div style="width:44px;height:44px;border-radius:6px;background:#f1f5f9;flex-shrink:0;"></div>`
      }
      <div class="search-result-info">
        <div class="search-result-name">${escapeHtml(handle)}</div>
        <div class="search-result-price">${currency}${formatPrice(price)}</div>
      </div>
    `;

    item.addEventListener('click', () => {
      searchResults.classList.remove('active');
      document.getElementById('search-input').value = '';
      openProductDetail(handle);
    });

    searchResults.appendChild(item);
  }

  searchResults.classList.add('active');
}

/* ============================================= */
/* 10. CART FUNCTIONS                            */
/* ============================================= */
function getCartCount() {
  let count = 0;
  for (const key in cart) {
    if (cart.hasOwnProperty(key)) {
      count += cart[key].qty || 0;
    }
  }
  return count;
}

function updateCartBadge() {
  const badge = document.getElementById('cart-badge');
  if (!badge) return;

  const count = getCartCount();
  badge.textContent = count;
  badge.setAttribute('data-count', count);

  if (count > 0) {
    badge.style.display = 'flex';
  } else {
    badge.style.display = 'none';
  }
}

function loadCartFromStorage() {
  try {
    const stored = localStorage.getItem('listex_cart');
    if (stored) {
      cart = JSON.parse(stored);
    }
  } catch (e) {
    console.warn('Error loading cart from storage:', e);
    cart = {};
  }
}

function saveCartToStorage() {
  try {
    localStorage.setItem('listex_cart', JSON.stringify(cart));
  } catch (e) {
    console.warn('Error saving cart to storage:', e);
  }
}

/**
 * Add item to cart
 */
function addToCart(productName, variantId, qty, price, imageUrl, variantLabel) {
  const key = variantId || productName;

  if (cart[key]) {
    cart[key].qty += qty;
  } else {
    cart[key] = {
      name: productName,
      variantId: variantId,
      variantLabel: variantLabel || '',
      qty: qty,
      price: parseFloat(price) || 0,
      image: imageUrl || ''
    };
  }

  saveCartToStorage();
  updateCartBadge();
  renderCartDrawer();
  showToast(`"${productName}" agregado al carrito`, 'success');
}

/**
 * Remove item from cart
 */
function removeFromCart(key) {
  if (cart[key]) {
    delete cart[key];
    saveCartToStorage();
    updateCartBadge();
    renderCartDrawer();
  }
}

/**
 * Update cart item quantity
 */
function updateCartQty(key, delta) {
  if (cart[key]) {
    cart[key].qty += delta;
    if (cart[key].qty <= 0) {
      delete cart[key];
    }
    saveCartToStorage();
    updateCartBadge();
    renderCartDrawer();
  }
}

/* ============================================= */
/* CART DRAWER                                   */
/* ============================================= */
function setupCartDrawer() {
  const cartBtn = document.getElementById('cart-btn');
  const cartDrawer = document.getElementById('cart-drawer');
  const cartOverlay = document.getElementById('cart-drawer-overlay');
  const cartClose = document.getElementById('cart-drawer-close');
  const checkoutBtn = document.getElementById('cart-checkout-btn');
  const whatsappBtn = document.getElementById('cart-whatsapp-btn');

  if (cartBtn) {
    cartBtn.addEventListener('click', function (e) {
      e.preventDefault();
      toggleCartDrawer();
    });
  }

  if (cartOverlay) {
    cartOverlay.addEventListener('click', closeCartDrawer);
  }

  if (cartClose) {
    cartClose.addEventListener('click', closeCartDrawer);
  }

  if (checkoutBtn) {
    checkoutBtn.addEventListener('click', handleCheckout);
  }

  if (whatsappBtn) {
    whatsappBtn.addEventListener('click', handleWhatsAppOrder);
  }
}

function toggleCartDrawer() {
  const cartDrawer = document.getElementById('cart-drawer');
  const cartOverlay = document.getElementById('cart-drawer-overlay');

  if (cartDrawer && cartOverlay) {
    const isOpen = cartDrawer.classList.contains('open');
    if (isOpen) {
      closeCartDrawer();
    } else {
      openCartDrawer();
    }
  }
}

function openCartDrawer() {
  const cartDrawer = document.getElementById('cart-drawer');
  const cartOverlay = document.getElementById('cart-drawer-overlay');

  if (cartDrawer) cartDrawer.classList.add('open');
  if (cartOverlay) cartOverlay.classList.add('open');
  document.body.style.overflow = 'hidden';
  renderCartDrawer();
}

function closeCartDrawer() {
  const cartDrawer = document.getElementById('cart-drawer');
  const cartOverlay = document.getElementById('cart-drawer-overlay');

  if (cartDrawer) cartDrawer.classList.remove('open');
  if (cartOverlay) cartOverlay.classList.remove('open');
  document.body.style.overflow = '';
}

function renderCartDrawer() {
  const body = document.getElementById('cart-drawer-body');
  const subtotalEl = document.getElementById('cart-subtotal');
  const totalEl = document.getElementById('cart-total');
  if (!body) return;

  const keys = Object.keys(cart);

  if (keys.length === 0) {
    body.innerHTML = `
      <div class="cart-empty-state">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" stroke-width="1"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
        <p>Tu carrito está vacío</p>
        <span>Explora nuestro catálogo y agrega productos</span>
      </div>
    `;
    if (subtotalEl) subtotalEl.textContent = '$0,00';
    if (totalEl) totalEl.textContent = '$0,00';
    return;
  }

  let html = '';
  let subtotal = 0;

  for (const key of keys) {
    const item = cart[key];
    const itemTotal = item.price * item.qty;
    subtotal += itemTotal;

    html += `
      <div class="cart-item">
        ${item.image
          ? `<img class="cart-item-img" src="${escapeHtml(item.image)}" alt="${escapeHtml(item.name)}" onerror="this.style.display='none';">`
          : `<div class="cart-item-img" style="background:var(--gray-100);"></div>`
        }
        <div class="cart-item-info">
          <div class="cart-item-name">${escapeHtml(item.name)}</div>
          ${item.variantLabel ? `<div class="cart-item-variant">${escapeHtml(item.variantLabel)}</div>` : ''}
          <div class="cart-item-controls">
            <button class="cart-item-qty-btn" onclick="updateCartQty('${escapeKey(key)}', -1)">−</button>
            <span class="cart-item-qty">${item.qty}</span>
            <button class="cart-item-qty-btn" onclick="updateCartQty('${escapeKey(key)}', 1)">+</button>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px;">
          <span class="cart-item-price">$${formatPrice(itemTotal)}</span>
          <button class="cart-item-remove" onclick="removeFromCart('${escapeKey(key)}')" aria-label="Eliminar">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
          </button>
        </div>
      </div>
    `;
  }

  body.innerHTML = html;

  if (subtotalEl) subtotalEl.textContent = '$' + formatPrice(subtotal);
  if (totalEl) totalEl.textContent = '$' + formatPrice(subtotal);
}

/**
 * Handle checkout button
 */
function handleCheckout() {
  const count = getCartCount();
  if (count === 0) {
    showToast('Tu carrito está vacío', 'error');
    return;
  }
  // Navigate to portal for order confirmation
  window.location.href = 'portal.html';
}

/**
 * Handle WhatsApp order
 */
function handleWhatsAppOrder() {
  const count = getCartCount();
  if (count === 0) {
    showToast('Tu carrito está vacío', 'error');
    return;
  }

  let message = '¡Hola! Me gustaría hacer un pedido mayorista:%0A%0A';
  let subtotal = 0;

  for (const key in cart) {
    const item = cart[key];
    const itemTotal = item.price * item.qty;
    subtotal += itemTotal;
    message += `• ${item.name}`;
    if (item.variantLabel) message += ` (${item.variantLabel})`;
    message += ` x${item.qty} - $${formatPrice(itemTotal)}%0A`;
  }

  message += `%0A*Total estimado: $${formatPrice(subtotal)}*`;
  message += `%0A%0AGracias!`;

  const url = `https://wa.me/${WHATSAPP_PHONE}?text=${message}`;
  window.open(url, '_blank');
}

/* ============================================= */
/* OPEN PRODUCT DETAIL                           */
/* ============================================= */
function openProductDetail(productName) {
  // This function is called when clicking on a product card
  // It will be fully handled by product-detail.js if available
  // Fallback: show basic modal
  const modal = document.getElementById('product-modal');
  const modalContent = document.getElementById('modal-content');
  if (!modal || !modalContent) return;

  const variants = productIndex[productName] || [];
  if (variants.length === 0) {
    showToast('Producto no encontrado', 'error');
    return;
  }

  const product = variants[0];
  const imageUrl = product.imagen_url || '';
  const price = parseFloat(product.precio_base) || 0;
  const currency = product.moneda || '$';
  const description = product.descripcion || product.description || 'Sin descripción disponible.';
  const category = product.categoria_principal || '';
  const stock = product.stock_disponible != null ? product.stock_disponible : 'N/A';
  const allVariants = product.variantes || [];
  const tarifas = product.tarifas_multiples || [];

  // Build variants selector
  let variantsHtml = '';
  if (allVariants.length > 0) {
    variantsHtml = '<div style="margin-top:16px;"><h4 style="font-size:0.9rem;font-weight:600;margin-bottom:8px;color:#334155;">Variantes disponibles:</h4><div style="display:flex;flex-wrap:wrap;gap:6px;">';
    for (const v of allVariants) {
      const label = v.talla || v.size || v.talla_nombre || v.atributo_valor || v.nombre || '';
      if (label) {
        variantsHtml += `<span style="padding:6px 14px;border:1px solid #e2e8f0;border-radius:8px;font-size:0.82rem;color:#475569;cursor:pointer;transition:all 0.15s;" onmouseover="this.style.borderColor='#0d9488';this.style.color='#0d9488'" onmouseout="this.style.borderColor='#e2e8f0';this.style.color='#475569'">${escapeHtml(label)}</span>`;
      }
    }
    variantsHtml += '</div></div>';
  }

  // Build tarifas info
  let tarifasHtml = '';
  if (tarifas.length > 0) {
    tarifasHtml = '<div style="margin-top:16px;"><h4 style="font-size:0.9rem;font-weight:600;margin-bottom:8px;color:#334155;">Precios por volumen:</h4><div style="display:flex;flex-direction:column;gap:4px;">';
    for (const t of tarifas) {
      const tName = t.nombre || t.name || t.tarifa || '';
      const tPrice = parseFloat(t.precio) || parseFloat(t.price) || 0;
      const tMin = t.cantidad_minima || t.min_qty || '';
      if (tPrice > 0) {
        tarifasHtml += `<div style="display:flex;justify-content:space-between;padding:6px 12px;background:#f8fafc;border-radius:6px;font-size:0.82rem;">
          <span style="color:#475569;">${escapeHtml(tName)}${tMin ? ' (mín. ' + tMin + ' uds.)' : ''}</span>
          <span style="font-weight:700;color:#0f172a;">${currency}${formatPrice(tPrice)}</span>
        </div>`;
      }
    }
    tarifasHtml += '</div></div>';
  }

  // Check if product-detail.js has a more complete render function
  if (typeof renderProductDetailModal === 'function') {
    renderProductDetailModal(productName);
    return;
  }

  modalContent.innerHTML = `
    <button onclick="closeProductModal()" style="position:absolute;top:16px;right:16px;width:36px;height:36px;border-radius:50%;background:rgba(0,0,0,0.05);display:flex;align-items:center;justify-content:center;cursor:pointer;border:none;z-index:2;transition:background 0.15s;" onmouseover="this.style.background='rgba(0,0,0,0.1)'" onmouseout="this.style.background='rgba(0,0,0,0.05)'">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#334155" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
    </button>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0;">
      <div style="padding:32px;display:flex;align-items:center;justify-content:center;background:#f8fafc;border-radius:24px 0 0 24px;">
        ${imageUrl
          ? `<img src="${escapeHtml(imageUrl)}" alt="${escapeHtml(productName)}" style="max-width:100%;max-height:420px;object-fit:contain;border-radius:12px;" onerror="this.parentElement.innerHTML='<div style=\\'padding:60px;text-align:center;color:#94a3b8;\\'>Sin imagen</div>';">`
          : `<div style="padding:60px;text-align:center;color:#94a3b8;font-size:1rem;">Sin imagen disponible</div>`
        }
      </div>
      <div style="padding:32px;overflow-y:auto;max-height:80vh;">
        ${category ? `<span style="font-size:0.75rem;font-weight:600;color:#0d9488;text-transform:uppercase;letter-spacing:0.05em;">${escapeHtml(category)}</span>` : ''}
        <h2 style="font-family:'Outfit',sans-serif;font-size:1.5rem;font-weight:800;color:#0f172a;margin:8px 0 16px;line-height:1.2;">${escapeHtml(productName)}</h2>
        <div style="display:flex;align-items:baseline;gap:12px;margin-bottom:16px;">
          <span style="font-family:'Outfit',sans-serif;font-size:2rem;font-weight:800;color:#0f172a;">${currency}${formatPrice(price)}</span>
          <span style="font-size:0.82rem;color:#64748b;">+ impuestos</span>
        </div>
        <p style="font-size:0.9rem;color:#475569;line-height:1.7;margin-bottom:16px;">${escapeHtml(description)}</p>
        <div style="display:flex;gap:12px;margin-bottom:16px;">
          <div style="padding:8px 16px;background:#f0fdfa;border-radius:8px;font-size:0.82rem;color:#0d9488;font-weight:600;">Stock: ${stock}</div>
          <div style="padding:8px 16px;background:#f8fafc;border-radius:8px;font-size:0.82rem;color:#475569;">ID: ${product.id_producto || 'N/A'}</div>
        </div>
        ${variantsHtml}
        ${tarifasHtml}
        <div style="margin-top:24px;display:flex;gap:10px;">
          <div style="display:flex;align-items:center;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;">
            <button id="modal-qty-minus" onclick="changeModalQty(-1)" style="width:40px;height:44px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;cursor:pointer;border:none;background:transparent;color:#475569;">−</button>
            <span id="modal-qty" style="min-width:40px;text-align:center;font-weight:700;font-size:1rem;color:#0f172a;">1</span>
            <button id="modal-qty-plus" onclick="changeModalQty(1)" style="width:40px;height:44px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;cursor:pointer;border:none;background:transparent;color:#475569;">+</button>
          </div>
          <button onclick="addToCartFromModal('${escapeHtml(productName)}')" style="flex:1;padding:14px 24px;background:#0f172a;color:white;font-size:0.92rem;font-weight:600;border-radius:10px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;border:none;transition:background 0.15s;" onmouseover="this.style.background='#0d9488'" onmouseout="this.style.background='#0f172a'">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
            Agregar al carrito
          </button>
        </div>
      </div>
    </div>
  `;

  modal.classList.add('active');
  document.body.style.overflow = 'hidden';

  // Track product view
  trackProductView(productName);
}

/**
 * Modal quantity control
 */
let modalQty = 1;

function changeModalQty(delta) {
  modalQty = Math.max(1, modalQty + delta);
  const el = document.getElementById('modal-qty');
  if (el) el.textContent = modalQty;
}

/**
 * Add to cart from modal
 */
function addToCartFromModal(productName) {
  const variants = productIndex[productName] || [];
  const product = variants.length > 0 ? variants[0] : null;
  if (!product) return;

  addToCart(
    productName,
    product.id_producto || productName,
    modalQty,
    product.precio_base,
    product.imagen_url,
    ''
  );

  modalQty = 1;
  closeProductModal();
}

function closeProductModal() {
  const modal = document.getElementById('product-modal');
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
  modalQty = 1;
}

/**
 * Track product view (Firebase or local)
 */
function trackProductView(productName) {
  try {
    if (typeof firebase !== 'undefined' && firebase.firestore) {
      const db = firebase.firestore();
      db.collection('product_views').doc(productName).set({
        views: firebase.firestore.FieldValue.increment(1),
        lastViewed: new Date()
      }, { merge: true }).catch(() => {});
    }
  } catch (e) {
    // Silently fail
  }
}

/* ============================================= */
/* UI UTILITIES                                  */
/* ============================================= */

/**
 * Show skeleton loading placeholders
 */
function showSkeletons() {
  const grids = ['categories-grid', 'offers-grid', 'most-viewed-grid', 'new-arrivals-grid'];

  for (const gridId of grids) {
    const container = document.getElementById(gridId);
    if (!container) continue;

    let count = gridId === 'offers-grid' ? 8 : 10;
    let html = '';
    for (let i = 0; i < count; i++) {
      html += '<div class="skeleton skeleton-card"></div>';
    }
    container.innerHTML = html;
  }
}

/**
 * Remove skeleton loading placeholders
 */
function removeSkeletons() {
  const skeletons = document.querySelectorAll('.skeleton-card');
  skeletons.forEach(s => s.remove());
}

/**
 * Show toast notification
 */
function showToast(message, type) {
  type = type || 'info';
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'toast toast-' + type;
  toast.innerHTML = `
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      ${type === 'success'
        ? '<polyline points="20 6 9 17 4 12"/>'
        : type === 'error'
          ? '<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>'
          : '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>'
      }
    </svg>
    <span>${escapeHtml(message)}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'toastSlideOut 0.35s ease forwards';
    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 350);
  }, 3500);
}

/**
 * Format price with decimal separator
 */
function formatPrice(value) {
  const num = parseFloat(value) || 0;
  return num.toFixed(2).replace('.', ',');
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = String(str);
  return div.innerHTML;
}

/**
 * Escape key for inline onclick handlers
 */
function escapeKey(str) {
  if (!str) return '';
  return String(str).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '\\"');
}

/**
 * Toggle wishlist heart
 */
function toggleWishlist(btn, productName) {
  btn.classList.toggle('active');

  let wishlist = [];
  try {
    wishlist = JSON.parse(localStorage.getItem('listex_wishlist') || '[]');
  } catch (e) {
    wishlist = [];
  }

  const index = wishlist.indexOf(productName);
  if (index > -1) {
    wishlist.splice(index, 1);
    showToast('Eliminado de favoritos', 'info');
  } else {
    wishlist.push(productName);
    showToast('Agregado a favoritos', 'success');
  }

  try {
    localStorage.setItem('listex_wishlist', JSON.stringify(wishlist));
  } catch (e) {
    // Silently fail
  }
}

/* ============================================= */
/* SCROLL ANIMATIONS                             */
/* ============================================= */
function setupScrollAnimations() {
  const observerOptions = {
    root: null,
    rootMargin: '0px 0px -60px 0px',
    threshold: 0.1
  };

  const observer = new IntersectionObserver(function (entries) {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    }
  }, observerOptions);

  // Observe all elements with .reveal class
  function observeRevealElements() {
    const elements = document.querySelectorAll('.reveal');
    elements.forEach(el => observer.observe(el));
  }

  // Initial observation
  observeRevealElements();

  // Re-observe after new content is rendered (MutationObserver)
  const bodyObserver = new MutationObserver(function () {
    observeRevealElements();
  });

  bodyObserver.observe(document.body, {
    childList: true,
    subtree: true
  });
}

/* ============================================= */
/* HEADER SCROLL BEHAVIOR                        */
/* ============================================= */
function setupHeaderScroll() {
  const header = document.getElementById('main-header');
  if (!header) return;

  let lastScroll = 0;
  let ticking = false;

  window.addEventListener('scroll', function () {
    if (!ticking) {
      window.requestAnimationFrame(function () {
        const currentScroll = window.pageYOffset;

        if (currentScroll > 10) {
          header.classList.add('scrolled');
        } else {
          header.classList.remove('scrolled');
        }

        lastScroll = currentScroll;
        ticking = false;
      });
      ticking = true;
    }
  });
}

/* ============================================= */
/* MOBILE MENU                                   */
/* ============================================= */
function setupMobileMenu() {
  const toggle = document.getElementById('mobile-menu-toggle');
  const navbar = document.getElementById('main-navbar');

  if (toggle && navbar) {
    toggle.addEventListener('click', function () {
      navbar.classList.toggle('mobile-open');
      this.classList.toggle('active');
    });
  }

  // Categories toggle (hamburger in navbar)
  const catToggle = document.getElementById('categories-toggle');
  const navLinks = document.getElementById('nav-links');

  if (catToggle && navLinks) {
    catToggle.addEventListener('click', function () {
      navLinks.classList.toggle('mobile-expanded');
    });
  }
}

/* ============================================= */
/* MODAL CLOSE ON OVERLAY CLICK / ESCAPE         */
/* ============================================= */
document.addEventListener('click', function (e) {
  const modal = document.getElementById('product-modal');
  if (modal && modal.classList.contains('active') && e.target === modal) {
    closeProductModal();
  }
});

document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape') {
    closeProductModal();
    closeCartDrawer();
  }
});

/* ============================================= */
/* INIT ON DOM CONTENT LOADED                    */
/* ============================================= */
document.addEventListener('DOMContentLoaded', function () {
  initApp();

  // Try to fetch Firebase views in the background
  fetchFirebaseViews();
});
