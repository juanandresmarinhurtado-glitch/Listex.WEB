const fs = require('fs');
const html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');
const js = html.substring(html.indexOf('<script>') + 8, html.lastIndexOf('</script>'));
fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/test_syntax.js', js, 'utf8');
