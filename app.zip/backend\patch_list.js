const fs = require('fs');

let serverJs = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', 'utf8');

const getProductsRegex = /app\.get\('\/api\/supplier\/products', authenticateSupplier, async \(req, res\) => \{[\s\S]*?(?=\napp\.post\('\/api\/supplier\/products')/;

const newGetProductsCode = `app.get('/api/supplier/products', authenticateSupplier, async (req, res) => {
    try {
        await authenticate();
        const supplierInfos = await executeKw('product.supplierinfo', 'search_read', [
            [['partner_id', '=', req.user.id]]
        ], {
            fields: ['product_tmpl_id']
        });
        
        let products = [];
        if (supplierInfos.length > 0) {
            const templateIds = supplierInfos.map(s => s.product_tmpl_id[0]);
            products = await executeKw('product.template', 'search_read', [
                [['id', 'in', templateIds]],
                ['id', 'name', 'list_price', 'standard_price', 'qty_available', 'is_published', 'image_128']
            ]);
        }
        
        // Merge pending products from local queue
        try {
            const queue = readJson(queueFile);
            for (const [tempId, item] of Object.entries(queue)) {
                if (item.partner_id === req.user.id && (item.status === 'pending' || item.status === 'processing')) {
                    products.unshift({
                        id: tempId,
                        name: item.data.name + ' (Procesando...)',
                        list_price: item.data.priceUnidad,
                        standard_price: item.data.cost,
                        qty_available: 0,
                        is_published: false,
                        isPending: true
                    });
                }
            }
        } catch(e) { console.error("Error merging queue", e); }
        
        res.json({ success: true, products: products });
    } catch (error) {
        console.error("Get Products Error:", error);
        res.status(500).json({ error: error.message });
    }
});`;

serverJs = serverJs.replace(getProductsRegex, newGetProductsCode);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/backend/server.js', serverJs, 'utf8');
console.log("Patched GET products list to include pending items.");
