const express = require('express');
const cors = require('cors');
require('dotenv').config();

const { initDB } = require('./db/init');
const { startWorker } = require('./services/syncWorker');
const { refreshDueSources } = require('./services/jsonIngest');

const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const publicRoutes = require('./routes/public');
const path = require('path');

const app = express();

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

app.use(express.static(path.join(__dirname, '..')));

app.use('/api', publicRoutes); // cart, checkout, catalog, portal
app.use('/api/supplier', authRoutes); // login, register
app.use('/api/supplier/products', productRoutes);

// Healthcheck
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: Date.now() });
});

// Database Diagnostics
app.get('/api/db-status', async (req, res) => {
    const { pool } = require('./db/init');
    try {
        const dbRes = await pool.query("SELECT NOW()");
        res.json({ status: 'connected', time: dbRes.rows[0].now });
    } catch (err) {
        res.status(500).json({ 
            status: 'error', 
            message: err.message, 
            env_has_db_url: !!process.env.DATABASE_URL,
            database_url_masked: process.env.DATABASE_URL ? process.env.DATABASE_URL.replace(/:[^:@]+@/, ':***@') : null
        });
    }
});

const PORT = process.env.PORT || 10000;

async function bootstrap() {
    console.log("[SERVER] Starting backend...");
    console.log("[SERVER] DATABASE_URL set:", !!process.env.DATABASE_URL);
    console.log("[SERVER] ODOO_URL:", process.env.ODOO_URL || '(default)');
    console.log("[SERVER] ODOO_API_KEY set:", !!process.env.ODOO_API_KEY);
    
    try {
        await initDB();
    } catch (e) {
        console.error("[SERVER] DB init failed (non-fatal):", e.message);
    }
    
    startWorker();

    // Refresco automático de enlaces JSON de proveedores (cada 5 min revisa los vencidos)
    setInterval(() => { refreshDueSources().catch(() => {}); }, 5 * 60 * 1000);

    app.listen(PORT, () => {
        console.log(`[SERVER] Listening on port ${PORT}`);
    });
}

bootstrap();
