require('dotenv').config();
const express = require('express');
const cors = require('cors');
const xmlrpc = require('xmlrpc');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

// Servir la página web (archivos estáticos) alojada un nivel arriba (spatial-aurora)
app.use(express.static(path.join(__dirname, '..')));

const ODOO_URL = process.env.ODOO_URL;
const ODOO_DB = process.env.ODOO_DB;
const ODOO_USERNAME = process.env.ODOO_USERNAME;
const ODOO_API_KEY = process.env.ODOO_API_KEY;
const PORT = process.env.PORT || 3000;

// Diagnóstico de Arranque: Verificar qué credenciales están cargadas
console.log(`[START] ODOO_URL: ${ODOO_URL}`);
console.log(`[START] API_KEY (últimos 8 chars): ...${ODOO_API_KEY ? ODOO_API_KEY.slice(-8) : 'UNDEFINED'}`);

// Helper para crear el cliente XML-RPC correcto analizando la URL
function getClientConfig(endpoint) {
    const url = new URL(ODOO_URL);
    const host = url.hostname;
    const port = url.port || (url.protocol === 'https:' ? 443 : 80);
    const isSecure = url.protocol === 'https:';

    const clientOptions = { host, port, path: endpoint };
    return isSecure ? xmlrpc.createSecureClient(clientOptions) : xmlrpc.createClient(clientOptions);
}

const commonClient = getClientConfig('/xmlrpc/2/common');
const modelsClient = getClientConfig('/xmlrpc/2/object');

let uid = null;

// Función de Autenticación en Odoo
function authenticate() {
    return new Promise((resolve, reject) => {
        if (uid) return resolve(uid); // Reutilizar uid
        commonClient.methodCall('authenticate', [ODOO_DB, ODOO_USERNAME, ODOO_API_KEY, {}], (error, result) => {
            if (error || !result) {
                console.error("Error autenticando con Odoo:", error);
                return reject(error || new Error("Fallo de autenticación"));
            }
            uid = result;
            console.log("Autenticado exitosamente con UID:", uid);
            resolve(uid);
        });
    });
}

// Función genérica para ejecutar métodos en Odoo
function executeKw(model, method, args, kwargs = {}) {
    return new Promise((resolve, reject) => {
        modelsClient.methodCall('execute_kw', [ODOO_DB, uid, ODOO_API_KEY, model, method, args, kwargs], (error, result) => {
            if (error) {
                console.error(`Error Odoo [${model}.${method}]:`, error);
                return reject(error);
            }
            resolve(result);
        });
    });
}

// Obtener o crear un Partner Genérico Web
async function getWebPartnerId() {
    const records = await executeKw('res.partner', 'search', [[['name', '=', 'Cliente Web (Listex)']]], { limit: 1 });
    if (records && records.length > 0) {
        return records[0];
    }
    // Si no existe, crearlo
    const newPartnerId = await executeKw('res.partner', 'create', [{
        name: 'Cliente Web (Listex)',
        comment: 'Cliente genérico usado dinámicamente desde el carrito de la web.'
    }]);
    return newPartnerId;
}

// =========================================================================
// RUTAS DE LA API (Consumidas por app.js en el frontend)
// =========================================================================

// FASE 1: Crear el Presupuesto al agregar el primer producto
app.post('/api/cart/create', async (req, res) => {
    try {
        await authenticate();
        const partnerId = await getWebPartnerId();

        // Crear sale.order en estado 'draft'
        const orderId = await executeKw('sale.order', 'create', [{
            partner_id: partnerId,
            state: 'draft'
            // Odoo llena automáticamente otros campos por defecto
        }]);

        res.json({ success: true, order_id: orderId });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// FASE 1 (Cont.): Agregar línea de pedido a la cotización
app.post('/api/cart/add-line', async (req, res) => {
    try {
        const { order_id, product_id, quantity, price_unit } = req.body;
        if (!order_id || !product_id || !quantity) {
            return res.status(400).json({ success: false, error: "Datos insuficientes (order_id, product_id, quantity)" });
        }

        await authenticate();

        const parsedOrderId = parseInt(order_id);
        const parsedProductId = parseInt(product_id);
        const parsedQty = parseFloat(quantity);

        const lineData = {
            order_id: parsedOrderId,
            product_id: parsedProductId,
            product_uom_qty: parsedQty
        };

        // If a price_unit is provided, override Odoo's default list price
        if (price_unit !== undefined && price_unit !== null) {
            lineData.price_unit = parseFloat(price_unit);
        }

        const lineId = await executeKw('sale.order.line', 'create', [lineData]);

        res.json({ success: true, line_id: lineId });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// FASE 2: Confirmar pedido y actualizar datos reales del cliente
app.post('/api/checkout', async (req, res) => {
    try {
        const { order_id, customer_data, cart_items } = req.body;
        if (!order_id || !customer_data) {
            return res.status(400).json({ success: false, error: "Datos insuficientes." });
        }

        await authenticate();
        const parsedOrderId = parseInt(order_id);

        // 0. Re-sync cart lines: get existing lines and compare with cart_items
        //    This ensures even if add-line failed silently, items are added here
        if (cart_items && cart_items.length > 0) {
            // Get existing lines for this order
            let existingLines = [];
            try {
                existingLines = await executeKw('sale.order.line', 'search_read',
                    [[['order_id', '=', parsedOrderId]]],
                    { fields: ['product_id', 'product_uom_qty'] }
                );
            } catch (e) {
                console.warn('Could not fetch existing order lines:', e.message);
            }

            const existingProductIds = new Set(existingLines.map(l => l.product_id && l.product_id[0]));

            for (const item of cart_items) {
                const pId = parseInt(item.product_id);
                if (!pId || isNaN(pId)) continue; // skip if no valid numeric ID
                if (existingProductIds.has(pId)) continue; // already in the order

                try {
                    const lineData = {
                        order_id: parsedOrderId,
                        product_id: pId,
                        product_uom_qty: parseFloat(item.quantity)
                    };
                    // Apply effective price if provided (handles docena/TIPO3)
                    if (item.price !== undefined && item.price !== null) {
                        lineData.price_unit = parseFloat(item.price);
                    }
                    await executeKw('sale.order.line', 'create', [lineData]);
                    console.log(`Re-synced missing product ${pId} (${item.product_name}) with price ${item.price} to order ${parsedOrderId}`);
                } catch (lineErr) {
                    console.warn(`Could not add product ${pId} (${item.product_name}):`, lineErr.message);
                }
            }
        }

        // 1. Crear el Contacto Real en Odoo con los datos del formulario web
        const realPartnerId = await executeKw('res.partner', 'create', [{
            name: `${customer_data.fname || ''} ${customer_data.lname || ''}`.trim(),
            vat: customer_data.cedula || '',
            email: customer_data.email || '',
            phone: customer_data.phone || '',
            street: customer_data.address || '',
            city: customer_data.state || '',
            comment: `Cédula: ${customer_data.cedula || ''}\nMétodo de Envío: ${customer_data.shipping_method}\nAgencia/Dirección: ${customer_data.agency || ''}`
        }]);

        // 2. Escribir (Asignar) este cliente real al Presupuesto existente y añadir notas
        await executeKw('sale.order', 'write', [[parsedOrderId], {
            partner_id: realPartnerId,
            client_order_ref: `ENVÍO: ${customer_data.shipping_method} | ${customer_data.agency || ''}`.substring(0, 100),
            note: `**DATOS COMPLETOS DE FACTURACIÓN**\nCédula: ${customer_data.cedula || ''}\nMétodo: ${customer_data.shipping_method}\nAgencia/Dirección: ${customer_data.agency || ''}`,
            state: 'sent'
        }]);

        // 3. Intentar disparar notificación Odoo (ignorar si falla)
        try {
            await executeKw('sale.order', 'action_quotation_send', [[parsedOrderId]]);
        } catch (e) { /* Ignorar si falla por requerir wizard interactiva */ }

        res.json({ success: true, message: "Cotización enviada exitosamente", order_id: parsedOrderId });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// =========================================================================
// RUTA CATÁLOGO (Proxy para evitar bloqueos CORS temporales)
// =========================================================================
app.get('/api/products', async (req, res) => {
    try {
        const cacheBuster = `?t=${new Date().getTime()}`;
        // Listex Odoo Public JSON Endpoint
        const catalogUrl = 'https://listex.odoo.com/web/content/16027/api_catalogo_listex.json';

        // El servidor hace el fetch (no sufre de políticas CORS)
        const response = await fetch(catalogUrl + cacheBuster);
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }
        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error("Error al obtener catálogo desde Odoo JSON:", error);
        res.status(500).json({ success: false, error: "No se pudo cargar el catálogo" });
    }
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`Backend Listex Odoo escuchando en el puerto ${PORT}`);
});
