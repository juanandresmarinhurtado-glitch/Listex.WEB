const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

common.methodCall('authenticate', [db, username, password, {}], function (error, uid) {
    if (error) {
        console.error("Auth Error:", error);
        return;
    }
    
    // Check if we can list models
    models.methodCall('execute_kw', [db, uid, password, 'ir.module.module', 'search_read', [[['name', '=', 'web_studio']]], {fields: ['state']}], function (err, res) {
        if (err) {
            console.error("Model Error:", err);
        } else {
            console.log("Studio Installed?:", res);
        }
    });
});
