/* ==========================================================================
   LISTEX - Inicialización de Firebase
   Requiere que los scripts de Firebase (compat) estén cargados en el HTML:
   - firebase-app-compat.js
   - firebase-firestore-compat.js
   - firebase-analytics-compat.js
   ========================================================================== */

// --- Configuración del proyecto Firebase ---
const firebaseConfig = {
  apiKey: 'AIzaSyA8EmR7AKLUhaZ3_Wh4zpqjmcEQBRQxGL0',
  authDomain: 'listex-web.firebaseapp.com',
  projectId: 'listex-web',
  storageBucket: 'listex-web.firebasestorage.app',
  messagingSenderId: '55599345584',
  appId: '1:55599345584:web:2630f7103548bc5a6fb075',
  measurementId: 'G-PTRG18T97D'
};

// --- Variables globales de Firebase ---
let firebaseApp = null;
let db = null;
let analytics = null;

/**
 * Verifica si Firebase está disponible en el contexto global
 * @returns {boolean} - verdadero si Firebase está cargado
 */
function isFirebaseAvailable() {
  return typeof firebase !== 'undefined' && firebase.app;
}

/**
 * Inicializa Firebase, Firestore y Analytics.
 * Se ejecuta automáticamente al cargar el script.
 */
function initializeFirebase() {
  try {
    // --- Verificar disponibilidad de Firebase ---
    if (!isFirebaseAvailable()) {
      console.warn('[Listex Firebase] Firebase SDK no encontrado. Las funciones de Firebase estarán deshabilitadas.');
      return;
    }

    // --- Inicializar la aplicación de Firebase ---
    if (!firebase.apps.length) {
      firebaseApp = firebase.initializeApp(firebaseConfig);
    } else {
      firebaseApp = firebase.app();
    }

    // --- Inicializar Firestore ---
    if (firebase.firestore) {
      db = firebase.firestore();
      // --- Habilitar persistencia offline para mejor rendimiento ---
      db.enablePersistence({ synchronizeTabs: true }).catch(function(err) {
        if (err.code === 'failed-precondition') {
          console.warn('[Listex Firebase] Persistencia no disponible: múltiples pestañas abiertas.');
        } else if (err.code === 'unimplemented') {
          console.warn('[Listex Firebase] Persistencia no soportada por este navegador.');
        }
      });
      console.log('[Listex Firebase] Firestore inicializado correctamente.');
    } else {
      console.warn('[Listex Firebase] Firestore SDK no encontrado.');
    }

    // --- Inicializar Analytics ---
    if (firebase.analytics) {
      analytics = firebase.analytics();
      console.log('[Listex Firebase] Analytics inicializado correctamente.');
    } else {
      console.warn('[Listex Firebase] Analytics SDK no encontrado.');
    }

    console.log('[Listex Firebase] Inicialización completa.');

  } catch (error) {
    console.error('[Listex Firebase] Error durante la inicialización:', error);
  }
}

// --- Ejecutar inicialización al cargar ---
initializeFirebase();

/* ==========================================================================
   Funciones de Firestore - Contadores de Vistas
   ========================================================================== */

/**
 * Incrementa el contador de vistas de un producto en Firestore.
 * Usa la operación FieldValue.increment para atomicidad.
 * @param {string} handle - Identificador único del producto (slug/handle)
 */
function incrementProductViews(handle) {
  try {
    // --- Verificar que Firestore esté disponible ---
    if (!db) {
      console.warn('[Listex Firebase] Firestore no disponible. No se pudo incrementar vistas.');
      return;
    }

    if (!handle || typeof handle !== 'string') {
      console.warn('[Listex Firebase] Handle de producto inválido:', handle);
      return;
    }

    // --- Referencia al documento del producto ---
    var productRef = db.collection('product_views').doc(handle);

    // --- Incrementar el contador atómicamente ---
    productRef.set({
      views: firebase.firestore.FieldValue.increment(1),
      lastViewed: firebase.firestore.FieldValue.serverTimestamp(),
      handle: handle
    }, { merge: true }).then(function() {
      console.log('[Listex Firebase] Vistas incrementadas para:', handle);
    }).catch(function(error) {
      console.error('[Listex Firebase] Error al incrementar vistas:', error);
    });

  } catch (error) {
    console.error('[Listex Firebase] Error en incrementProductViews:', error);
  }
}

/**
 * Escucha en tiempo real los cambios en el contador de vistas de un producto.
 * Usa onSnapshot para actualizaciones instantáneas.
 * @param {string} handle - Identificador único del producto
 * @param {function} callback - Función que recibe el número de vistas (number)
 * @returns {function|null} - Función para cancelar la suscripción, o null si no está disponible
 */
function getProductViews(handle, callback) {
  try {
    // --- Verificar que Firestore esté disponible ---
    if (!db) {
      console.warn('[Listex Firebase] Firestore no disponible. No se pudo obtener vistas.');
      if (typeof callback === 'function') {
        callback(0);
      }
      return null;
    }

    if (!handle || typeof handle !== 'string') {
      console.warn('[Listex Firebase] Handle de producto inválido:', handle);
      if (typeof callback === 'function') {
        callback(0);
      }
      return null;
    }

    // --- Referencia al documento del producto ---
    var productRef = db.collection('product_views').doc(handle);

    // --- Suscripción en tiempo real ---
    var unsubscribe = productRef.onSnapshot(function(doc) {
      if (doc.exists) {
        var data = doc.data();
        var views = data.views || 0;
        if (typeof callback === 'function') {
          callback(views);
        }
      } else {
        // --- Si el documento no existe, retornar 0 vistas ---
        if (typeof callback === 'function') {
          callback(0);
        }
      }
    }, function(error) {
      console.error('[Listex Firebase] Error al escuchar vistas:', error);
      if (typeof callback === 'function') {
        callback(0);
      }
    });

    // --- Retornar función para cancelar suscripción ---
    return unsubscribe;

  } catch (error) {
    console.error('[Listex Firebase] Error en getProductViews:', error);
    if (typeof callback === 'function') {
      callback(0);
    }
    return null;
  }
}

/* ==========================================================================
   Funciones de Analytics - Registro de Eventos
   ========================================================================== */

/**
 * Registra un evento personalizado en Firebase Analytics.
 * @param {string} eventName - Nombre del evento (ej: 'page_view', 'search')
 * @param {Object} params - Parámetros adicionales del evento
 */
function logEvent(eventName, params) {
  try {
    // --- Verificar que Analytics esté disponible ---
    if (!analytics) {
      console.warn('[Listex Firebase] Analytics no disponible. Evento no registrado:', eventName);
      return;
    }

    if (!eventName || typeof eventName !== 'string') {
      console.warn('[Listex Firebase] Nombre de evento inválido.');
      return;
    }

    // --- Registrar el evento con parámetros ---
    var eventParams = params || {};
    analytics.logEvent(eventName, eventParams);
    console.log('[Listex Firebase] Evento registrado:', eventName, eventParams);

  } catch (error) {
    console.error('[Listex Firebase] Error al registrar evento:', error);
  }
}

/**
 * Registra un evento de vista de producto (view_item) según estándar de GA4.
 * @param {Object} product - Datos del producto
 * @param {string} product.id - ID del producto
 * @param {string} product.name - Nombre del producto
 * @param {string} product.category - Categoría del producto
 * @param {number} product.price - Precio del producto
 * @param {string} [product.brand] - Marca del producto
 * @param {string} [product.variant] - Variante (talla, color, etc.)
 */
function logViewItem(product) {
  try {
    // --- Verificar que Analytics esté disponible ---
    if (!analytics) {
      console.warn('[Listex Firebase] Analytics no disponible. view_item no registrado.');
      return;
    }

    if (!product || typeof product !== 'object') {
      console.warn('[Listex Firebase] Datos de producto inválidos para view_item.');
      return;
    }

    // --- Construir parámetros del evento según GA4 ---
    var eventParams = {
      currency: 'USD',
      value: product.price || 0,
      items: [{
        item_id: product.id || '',
        item_name: product.name || '',
        item_category: product.category || '',
        price: product.price || 0,
        item_brand: product.brand || 'Listex',
        item_variant: product.variant || ''
      }]
    };

    analytics.logEvent('view_item', eventParams);
    console.log('[Listex Firebase] view_item registrado:', product.name);

  } catch (error) {
    console.error('[Listex Firebase] Error al registrar view_item:', error);
  }
}

/**
 * Registra un evento de agregar al carrito (add_to_cart) según estándar de GA4.
 * @param {Object} product - Datos del producto
 * @param {string} product.id - ID del producto
 * @param {string} product.name - Nombre del producto
 * @param {string} product.category - Categoría del producto
 * @param {number} product.price - Precio del producto
 * @param {string} [product.brand] - Marca del producto
 * @param {string} [product.variant] - Variante (talla, color, etc.)
 * @param {number} quantity - Cantidad agregada al carrito
 * @param {number} value - Valor total (precio × cantidad)
 */
function logAddToCart(product, quantity, value) {
  try {
    // --- Verificar que Analytics esté disponible ---
    if (!analytics) {
      console.warn('[Listex Firebase] Analytics no disponible. add_to_cart no registrado.');
      return;
    }

    if (!product || typeof product !== 'object') {
      console.warn('[Listex Firebase] Datos de producto inválidos para add_to_cart.');
      return;
    }

    // --- Construir parámetros del evento según GA4 ---
    var eventParams = {
      currency: 'USD',
      value: value || (product.price || 0) * (quantity || 1),
      items: [{
        item_id: product.id || '',
        item_name: product.name || '',
        item_category: product.category || '',
        price: product.price || 0,
        item_brand: product.brand || 'Listex',
        item_variant: product.variant || '',
        quantity: quantity || 1
      }]
    };

    analytics.logEvent('add_to_cart', eventParams);
    console.log('[Listex Firebase] add_to_cart registrado:', product.name, 'x', quantity);

  } catch (error) {
    console.error('[Listex Firebase] Error al registrar add_to_cart:', error);
  }
}

/**
 * Registra un evento de generación de lead (generate_lead) según estándar de GA4.
 * Se usa cuando un cliente envía un pedido por WhatsApp.
 * @param {number} value - Valor total del pedido
 * @param {string} orderId - Identificador único del pedido
 */
function logGenerateLead(value, orderId) {
  try {
    // --- Verificar que Analytics esté disponible ---
    if (!analytics) {
      console.warn('[Listex Firebase] Analytics no disponible. generate_lead no registrado.');
      return;
    }

    // --- Construir parámetros del evento ---
    var eventParams = {
      currency: 'USD',
      value: value || 0,
      transaction_id: orderId || 'order_' + Date.now()
    };

    analytics.logEvent('generate_lead', eventParams);
    console.log('[Listex Firebase] generate_lead registrado. Orden:', orderId, 'Valor:', value);

  } catch (error) {
    console.error('[Listex Firebase] Error al registrar generate_lead:', error);
  }
}
