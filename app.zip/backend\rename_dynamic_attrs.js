const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        // Find all dynamic attributes
        const dynamicAttrs = await executeKw('product.attribute', 'search_read', [
            [['create_variant', '=', 'dynamic']],
            ['id', 'name']
        ]);
        
        console.log("Found dynamic attrs:", dynamicAttrs.length);
        
        for (const attr of dynamicAttrs) {
            try {
                // Try to change it directly first
                await executeKw('product.attribute', 'write', [
                    [attr.id],
                    { create_variant: 'always' }
                ]);
                console.log("Updated " + attr.name + " to always successfully.");
            } catch (err) {
                // If it fails, rename it so our code can create a fresh one!
                console.log("Could not update " + attr.name + ", renaming it...");
                await executeKw('product.attribute', 'write', [
                    [attr.id],
                    { name: attr.name + " (Antiguo/Dinamico)" }
                ]);
                console.log("Renamed " + attr.name + " successfully.");
            }
        }
        
    } catch (e) {
        console.error("Error fixing attributes:", e);
    }
});
