const fs = require('fs');

let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// Replace "Odoo" with "Web Listex"
html = html.replace(/Odoo/gi, "Web Listex");

// Append Variants UI logic
// We need a modal to display variants and let the user upload images
const variantsModal = `
    <!-- Variants Modal -->
    <div id="variants-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:9999; align-items:center; justify-content:center;">
        <div style="background:var(--card-bg); width:90%; max-width:600px; border-radius:12px; padding:30px; max-height:90vh; overflow-y:auto; position:relative;">
            <button onclick="closeVariantsModal()" style="position:absolute; top:15px; right:15px; background:none; border:none; font-size:1.5rem; cursor:pointer; color:var(--text-muted);"><ion-icon name="close-circle-outline"></ion-icon></button>
            <h2 style="margin-bottom:10px; color:var(--primary); display:flex; align-items:center; gap:8px;"><ion-icon name="images-outline"></ion-icon> Fotos de Variantes</h2>
            <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:20px;">Tu producto tiene múltiples variantes (tallas, colores, presentaciones). Sube la foto correspondiente a cada una o déjalas en blanco para usar la foto principal.</p>
            
            <div id="variants-list" style="display:flex; flex-direction:column; gap:15px;">
                <!-- variants will be injected here -->
            </div>
            
            <button class="btn btn-primary w-100" style="margin-top:20px;" onclick="closeVariantsModal()">¡Listo, finalizar!</button>
        </div>
    </div>
`;

if (!html.includes('id="variants-modal"')) {
    html = html.replace('</main>', '</main>\n' + variantsModal);
}

// Modify JS
const jsModifications = `
        let currentTmplId = null;

        function closeVariantsModal() {
            document.getElementById('variants-modal').style.display = 'none';
            switchTab('tab-productos', document.querySelector('.dash-tab'));
        }

        async function openVariantsModal(tmplId) {
            currentTmplId = tmplId;
            const modal = document.getElementById('variants-modal');
            modal.style.display = 'flex';
            
            const list = document.getElementById('variants-list');
            list.innerHTML = '<p style="text-align:center;">Buscando variantes en Web Listex...</p>';
            
            try {
                // Wait a tiny bit for the system to finish generating variants if it's slow
                await new Promise(r => setTimeout(r, 1500));
                
                const res = await fetch(API_BASE + '/products/' + tmplId + '/variants', { headers: getAuthHeaders() });
                const data = await res.json();
                
                if (data.success && data.variants.length > 0) {
                    list.innerHTML = '';
                    data.variants.forEach(v => {
                        list.innerHTML += \`
                            <div style="display:flex; align-items:center; gap:15px; padding:15px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-color);">
                                <div style="flex:1;">
                                    <strong style="color:var(--text-main);">\${v.attribute_names}</strong>
                                    <p id="status-var-\${v.id}" style="font-size:0.8rem; color:var(--text-muted); margin-top:5px;">Foto heredada de la principal</p>
                                </div>
                                <div style="width:80px; height:80px; border-radius:8px; overflow:hidden; background:#e2e8f0; display:flex; align-items:center; justify-content:center; position:relative; cursor:pointer;" onclick="document.getElementById('file-var-\${v.id}').click()">
                                    <ion-icon name="camera-outline" style="font-size:1.5rem; color:var(--text-muted);" id="icon-var-\${v.id}"></ion-icon>
                                    <img id="img-var-\${v.id}" style="width:100%; height:100%; object-fit:cover; display:none;">
                                </div>
                                <input type="file" id="file-var-\${v.id}" style="display:none;" accept="image/*" onchange="uploadVariantImage(this, \${v.id})">
                            </div>
                        \`;
                    });
                } else {
                    list.innerHTML = '<p style="text-align:center; color:var(--text-muted);">El producto es simple (no tiene opciones). Todo listo.</p>';
                }
            } catch (err) {
                list.innerHTML = '<p style="text-align:center; color:red;">Error al consultar variantes.</p>';
            }
        }

        async function uploadVariantImage(input, variantId) {
            const file = input.files[0];
            if (!file) return;
            
            document.getElementById('status-var-' + variantId).textContent = "Procesando...";
            document.getElementById('status-var-' + variantId).style.color = "var(--primary)";
            
            const reader = new FileReader();
            reader.onload = function(event) {
                const img = new Image();
                img.onload = async function() {
                    const canvas = document.createElement('canvas');
                    const MAX_WIDTH = 800;
                    let scaleSize = 1;
                    if (img.width > MAX_WIDTH) scaleSize = MAX_WIDTH / img.width;
                    canvas.width = img.width * scaleSize;
                    canvas.height = img.height * scaleSize;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                    
                    const base64Image = canvas.toDataURL('image/webp', 0.8);
                    
                    // Show visually
                    document.getElementById('icon-var-' + variantId).style.display = 'none';
                    const imgEl = document.getElementById('img-var-' + variantId);
                    imgEl.src = base64Image;
                    imgEl.style.display = 'block';
                    
                    // Upload to server
                    document.getElementById('status-var-' + variantId).textContent = "Subiendo...";
                    try {
                        const res = await fetch(API_BASE + '/variants/' + variantId + '/image', {
                            method: 'POST',
                            headers: getAuthHeaders(),
                            body: JSON.stringify({ imageBase64: base64Image })
                        });
                        if ((await res.json()).success) {
                            document.getElementById('status-var-' + variantId).textContent = "¡Foto Exclusiva Subida!";
                            document.getElementById('status-var-' + variantId).style.color = "green";
                        }
                    } catch (e) {
                        document.getElementById('status-var-' + variantId).textContent = "Error al subir";
                        document.getElementById('status-var-' + variantId).style.color = "red";
                    }
                }
                img.src = event.target.result;
            }
            reader.readAsDataURL(file);
        }
`;

if (!html.includes('function closeVariantsModal()')) {
    html = html.replace('// CREATE PRODUCT', jsModifications + '\n        // CREATE PRODUCT');
}

html = html.replace("switchTab('tab-productos', document.querySelector('.dash-tab')); // go back to list", "openVariantsModal(data.id);");

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("UI HTML updated with Variant Modals.");
