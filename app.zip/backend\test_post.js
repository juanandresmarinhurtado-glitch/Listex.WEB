const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

function executeKw(model, method, args) {
    return new Promise((resolve, reject) => {
        models.methodCall('execute_kw', [db, uid, password, model, method, args], (err, res) => {
            if (err) reject(err);
            else resolve(res);
        });
    });
}

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    try {
        const name = "Test Prod Error";
        const priceUnidad = "10";
        const cost = "5";
        const priceDocena = "8";
        
        const productData = {
            name: name,
            list_price: parseFloat(priceUnidad) || 0,
            standard_price: parseFloat(cost) || 0,
            sale_ok: true,
            purchase_ok: true,
            is_published: false,
            taxes_id: false,
            supplier_taxes_id: false
        };
        
        console.log("Creating template...");
        const tmplId = await executeKw('product.template', 'create', [productData]);
        console.log("Created:", tmplId);
        
        const parallelTasks = [];
        parallelTasks.push(executeKw('product.template', 'write', [[tmplId], { is_published: true }]));
        parallelTasks.push(executeKw('product.supplierinfo', 'create', [{ partner_id: 174, product_tmpl_id: tmplId, delay: 1 }]));
        if (priceDocena) {
            parallelTasks.push(executeKw('product.pricelist.item', 'create', [{ pricelist_id: 3, applied_on: '1_product', product_tmpl_id: tmplId, compute_price: 'fixed', fixed_price: parseFloat(priceDocena) }]));
        }
        
        console.log("Waiting for parallel...");
        await Promise.all(parallelTasks);
        console.log("Parallel done.");
        
        async function getOrCreateAttribute(attrName) {
            const attrs = await executeKw('product.attribute', 'search_read', [[['name', '=', attrName]], ['id']]);
            if (attrs.length > 0) return attrs[0].id;
            return await executeKw('product.attribute', 'create', [{ name: attrName, create_variant: 'dynamic' }]);
        }

        async function getOrCreateAttrValue(attrId, valName) {
            const vals = await executeKw('product.attribute.value', 'search_read', [[['attribute_id', '=', attrId], ['name', '=', valName]], ['id']]);
            if (vals.length > 0) return vals[0].id;
            return await executeKw('product.attribute.value', 'create', [{ attribute_id: attrId, name: valName }]);
        }

        const presentacionId = await getOrCreateAttribute('Presentación');
        console.log("Presentacion attr:", presentacionId);
        let presValIds = [];
        presValIds.push(await getOrCreateAttrValue(presentacionId, 'unidad variada'));
        if (priceDocena) presValIds.push(await getOrCreateAttrValue(presentacionId, 'docena cerrada'));
        
        console.log("Linking attribute lines...");
        await executeKw('product.template.attribute.line', 'create', [{ product_tmpl_id: tmplId, attribute_id: presentacionId, value_ids: [[6, 0, presValIds]] }]);
        console.log("Done.");
        
    } catch(err) {
        console.error("Error:", err);
    }
});
