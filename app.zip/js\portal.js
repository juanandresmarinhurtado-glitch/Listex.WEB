/* =============================================
   PORTAL LOGIC - Listex Mayorista
   portal.js
   ============================================= */

(function () {
    'use strict';

    const PORTAL_USER_KEY = 'listex_portal_user';
    const BACKEND_URL_PORTAL = (typeof BACKEND_URL !== 'undefined') ? BACKEND_URL : 'http://localhost:3000';

    /* ------------------------------------------
       LOGIN
    ------------------------------------------ */

    window.handleLogin = function (event) {
        if (event) event.preventDefault();

        const cedulaInput = document.getElementById('login-vat');
        const errorEl = document.getElementById('login-error');
        const btnLogin = document.querySelector('#login-form button[type="submit"]');

        if (!cedulaInput) return;

        const vat = cedulaInput.value.trim();
        if (!vat) {
            showLoginError('Ingresa tu número de cédula');
            cedulaInput.focus();
            return;
        }

        // Disable button
        if (btnLogin) {
            btnLogin.disabled = true;
            btnLogin.innerHTML = '⏳ Verificando...';
        }

        hideLoginError();

        fetch(BACKEND_URL_PORTAL + '/api/portal/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ vat: vat })
        })
            .then(function (res) {
                if (!res.ok) throw new Error('not_found');
                return res.json();
            })
            .then(function (data) {
                if (data && data.partner_id) {
                    // Save to localStorage
                    const userData = {
                        partner_id: data.partner_id,
                        name: data.name || 'Cliente',
                        vat: vat,
                        email: data.email || ''
                    };
                    try {
                        localStorage.setItem(PORTAL_USER_KEY, JSON.stringify(userData));
                    } catch (e) { }

                    showDashboard(userData);
                    loadDashboard(data.partner_id);
                } else {
                    throw new Error('not_found');
                }
            })
            .catch(function (err) {
                console.warn('Login error:', err);
                showLoginError('Cliente no encontrado. Verifica tu número de cédula.');
                if (btnLogin) {
                    btnLogin.disabled = false;
                    btnLogin.innerHTML = '🔑 Ingresar';
                }
            });
    };

    function showLoginError(message) {
        const errorEl = document.getElementById('login-error');
        if (errorEl) {
            errorEl.textContent = message;
            errorEl.classList.add('visible');
            errorEl.style.display = 'block';
        }
    }

    function hideLoginError() {
        const errorEl = document.getElementById('login-error');
        if (errorEl) {
            errorEl.classList.remove('visible');
            errorEl.style.display = 'none';
        }
    }

    /* ------------------------------------------
       CHECK EXISTING SESSION
    ------------------------------------------ */
    window.checkExistingSession = function () {
        try {
            const raw = localStorage.getItem(PORTAL_USER_KEY);
            if (raw) {
                const userData = JSON.parse(raw);
                if (userData && userData.partner_id) {
                    showDashboard(userData);
                    loadDashboard(userData.partner_id);
                    return true;
                }
            }
        } catch (e) { }
        return false;
    };

    /* ------------------------------------------
       SHOW / HIDE SECTIONS
    ------------------------------------------ */
    function showDashboard(userData) {
        const loginSection = document.getElementById('portal-login');
        const dashboardSection = document.getElementById('portal-dashboard');

        if (loginSection) loginSection.style.display = 'none';
        if (dashboardSection) {
            dashboardSection.style.display = 'block';
            dashboardSection.classList.add('visible');
        }

        // Update welcome header
        const welcomeName = document.getElementById('dashboard-welcome');
        if (welcomeName) welcomeName.textContent = 'Bienvenido, ' + (userData.name || 'Cliente');

        const welcomeInitial = document.getElementById('welcomeInitial');
        if (welcomeInitial) {
            const name = userData.name || 'C';
            welcomeInitial.textContent = name.charAt(0).toUpperCase();
        }
    }

    function showLogin() {
        const loginSection = document.getElementById('portal-login');
        const dashboardSection = document.getElementById('portal-dashboard');

        if (loginSection) loginSection.style.display = 'block';
        if (dashboardSection) dashboardSection.style.display = 'none';

        const btnLogin = document.querySelector('#login-form button[type="submit"]');
        if (btnLogin) {
            btnLogin.disabled = false;
            btnLogin.innerHTML = 'Ingresar';
        }
    }

    /* ------------------------------------------
       LOAD DASHBOARD
    ------------------------------------------ */
    window.loadDashboard = function (partnerId) {
        fetch(BACKEND_URL_PORTAL + '/api/portal/dashboard/' + partnerId)
            .then(function (res) {
                if (!res.ok) throw new Error('Dashboard fetch failed');
                return res.json();
            })
            .then(function (data) {
                if (data) {
                    if (data.summary) renderSummary(data.summary);
                    if (data.top_products) renderTopProducts(data.top_products);
                    if (data.orders) renderOrders(data.orders);
                }
            })
            .catch(function (err) {
                console.warn('Dashboard load error:', err);
                // Show empty state
                renderSummary({ total_orders: 0, total_amount: 0 });
                renderTopProducts([]);
                renderOrders([]);
            });
    };

    /* ------------------------------------------
       RENDER SUMMARY
    ------------------------------------------ */
    function renderSummary(summary) {
        const totalOrdersEl = document.getElementById('stat-total-orders');
        const totalAmountEl = document.getElementById('stat-total-spent');

        if (totalOrdersEl) totalOrdersEl.textContent = summary.total_orders || 0;
        if (totalAmountEl) {
            const amount = parseFloat(summary.total_amount) || 0;
            totalAmountEl.textContent = '$' + amount.toFixed(2);
        }
    }

    /* ------------------------------------------
       RENDER TOP PRODUCTS
    ------------------------------------------ */
    function renderTopProducts(products) {
        const container = document.getElementById('topProductsRow');
        if (!container) return;

        if (!products || products.length === 0) {
            container.innerHTML = '<div class="no-orders"><p>Aún no tienes productos comprados</p></div>';
            return;
        }

        let html = '';
        const topFive = products.slice(0, 5);

        topFive.forEach(function (product) {
            html += '<div class="top-product-card">';
            html += '<div class="top-product-image">';
            if (product.image_url || product.imagen_url) {
                html += '<img src="' + escapeHTML(product.image_url || product.imagen_url) + '" alt="' + escapeHTML(product.name || product.nombre || '') + '" onerror="this.parentElement.innerHTML=\'<div class=placeholder-img>📦</div>\'">';
            } else {
                html += '<div class="placeholder-img">📦</div>';
            }
            html += '</div>';
            html += '<div class="top-product-info">';
            html += '<div class="top-product-name">' + escapeHTML(product.name || product.nombre || 'Producto') + '</div>';
            html += '<div class="top-product-qty">' + (product.quantity || product.qty || 0) + ' unidades</div>';
            html += '</div>';
            html += '</div>';
        });

        container.innerHTML = html;
    }

    /* ------------------------------------------
       RENDER ORDERS
    ------------------------------------------ */
    function renderOrders(orders) {
        const container = document.getElementById('orders-table-body');

        if (!container) return;

        if (!orders || orders.length === 0) {
            container.innerHTML = '<tr><td colspan="5" style="padding:20px; text-align:center;">No hay pedidos recientes.</td></tr>';
            return;
        }

        let html = '';
        orders.forEach(function (order) {
            const statusInfo = getStatusInfo(order.status || order.estado || '');

            html += '<tr>';
            html += '<td data-label="Referencia"><span class="order-reference">' + escapeHTML(order.reference || order.name || '') + '</span></td>';
            html += '<td data-label="Fecha">' + formatDate(order.date || order.fecha || '') + '</td>';
            html += '<td data-label="Monto">$' + (parseFloat(order.amount || order.monto || 0)).toFixed(2) + '</td>';
            html += '<td data-label="Estado"><span class="status-badge ' + statusInfo.cssClass + '">' + escapeHTML(statusInfo.label) + '</span></td>';
            html += '<td data-label="Acciones"><button class="btn-view-detail" onclick=\'viewOrderDetail(' + JSON.stringify(order).replace(/'/g, "\\'") + ')\'>Ver Detalle</button></td>';
            html += '</tr>';
        });

        container.innerHTML = html;
    }

    function getStatusInfo(status) {
        const lower = (status || '').toLowerCase();

        if (lower.includes('entregado') || lower.includes('agencia')) {
            return { label: status, cssClass: 'status-delivered' };
        }
        if (lower.includes('empacado') || lower.includes('listo')) {
            return { label: status, cssClass: 'status-packed' };
        }
        if (lower.includes('pago confirmado') || lower.includes('confirmado')) {
            return { label: status, cssClass: 'status-confirmed' };
        }
        if (lower.includes('esperando') || lower.includes('validación') || lower.includes('pendiente')) {
            return { label: status, cssClass: 'status-pending' };
        }
        if (lower.includes('cancelado')) {
            return { label: status, cssClass: 'status-cancelled' };
        }

        return { label: status || 'Procesando', cssClass: 'status-default' };
    }

    function formatDate(dateStr) {
        if (!dateStr) return '—';
        try {
            const d = new Date(dateStr);
            if (isNaN(d.getTime())) return dateStr;
            return d.toLocaleDateString('es-VE', { day: '2-digit', month: 'short', year: 'numeric' });
        } catch (e) {
            return dateStr;
        }
    }

    /* ------------------------------------------
       VIEW ORDER DETAIL
    ------------------------------------------ */
    window.viewOrderDetail = function (order) {
        const modal = document.getElementById('order-detail-modal');
        if (!modal) return;

        // Fill header
        const refEl = document.getElementById('modal-order-ref');
        const statusEl = document.getElementById('modal-order-status');

        if (refEl) refEl.textContent = 'Pedido ' + (order.reference || order.name || '');

        if (statusEl) {
            const statusInfo = getStatusInfo(order.status || order.estado || '');
            statusEl.innerHTML = '<span class="status-badge ' + statusInfo.cssClass + '">' + escapeHTML(statusInfo.label) + '</span>';
        }

        // Fill order lines
        const linesBody = document.getElementById('modal-order-lines');
        if (linesBody) {
            const lines = order.lines || order.lineas || [];
            let html = '';
            let grandTotal = 0;

            if (lines.length > 0) {
                lines.forEach(function (line) {
                    const qty = line.quantity || line.qty || 0;
                    const price = parseFloat(line.price || line.precio || 0);
                    const subtotal = qty * price;
                    grandTotal += subtotal;

                    html += '<tr>';
                    html += '<td style="padding:10px; border-bottom:1px solid #E2E8F0;">' + escapeHTML(line.product || line.producto || line.name || '') + '</td>';
                    html += '<td style="padding:10px; border-bottom:1px solid #E2E8F0;">' + qty + '</td>';
                    html += '<td style="padding:10px; border-bottom:1px solid #E2E8F0;">$' + price.toFixed(2) + '</td>';
                    html += '<td style="padding:10px; border-bottom:1px solid #E2E8F0;">$' + subtotal.toFixed(2) + '</td>';
                    html += '</tr>';
                });
            } else {
                html += '<tr><td colspan="4" style="text-align:center; color:#9ca3af; padding:20px;">Sin detalles disponibles</td></tr>';
                grandTotal = parseFloat(order.amount || order.monto || 0);
            }

            linesBody.innerHTML = html;

            const totalEl = document.getElementById('modal-order-total');
            if (totalEl) totalEl.textContent = '$' + grandTotal.toFixed(2);
        }

        // Tracking section
        const trackingSection = document.getElementById('modal-order-tracking');
        const trackingNumber = order.tracking_number || order.numero_guia || '';

        if (trackingSection) {
            if (trackingNumber) {
                trackingSection.style.display = 'block';
                const trackingValueEl = document.getElementById('modal-tracking-number');
                if (trackingValueEl) trackingValueEl.textContent = trackingNumber;

                // Store carrier info
                trackingSection.setAttribute('data-tracking', trackingNumber);
                trackingSection.setAttribute('data-carrier', order.carrier || order.transportista || 'mrw');
            } else {
                trackingSection.style.display = 'none';
            }
        }

        // Show modal
        modal.classList.add('visible');
        document.body.style.overflow = 'hidden';
    };

    /* ------------------------------------------
       CLOSE ORDER DETAIL MODAL
    ------------------------------------------ */
    window.closeOrderDetailModal = function () {
        const modal = document.getElementById('order-detail-modal');
        if (modal) {
            modal.classList.remove('visible');
            document.body.style.overflow = '';
        }
    };

    /* ------------------------------------------
       TRACKING ACTIONS
    ------------------------------------------ */
    window.copyTrackingNumber = function () {
        const trackingSection = document.getElementById('trackingSection');
        const trackingNumber = trackingSection ? trackingSection.getAttribute('data-tracking') : '';

        if (!trackingNumber) return;

        navigator.clipboard.writeText(trackingNumber).then(function () {
            const btn = document.getElementById('btnCopyTracking');
            if (btn) {
                btn.classList.add('copied');
                btn.innerHTML = '✓ Copiado';
                setTimeout(function () {
                    btn.classList.remove('copied');
                    btn.innerHTML = '📋 Copiar guía';
                }, 2000);
            }
        }).catch(function () {
            // Fallback
            const textarea = document.createElement('textarea');
            textarea.value = trackingNumber;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);

            const btn = document.getElementById('btnCopyTracking');
            if (btn) {
                btn.classList.add('copied');
                btn.innerHTML = '✓ Copiado';
                setTimeout(function () {
                    btn.classList.remove('copied');
                    btn.innerHTML = '📋 Copiar guía';
                }, 2000);
            }
        });
    };

    window.trackShipment = function () {
        const trackingSection = document.getElementById('trackingSection');
        if (!trackingSection) return;

        const carrier = (trackingSection.getAttribute('data-carrier') || '').toLowerCase();

        if (carrier.includes('zoom')) {
            window.open('https://www.zoom.com.ve/rastreo', '_blank');
        } else {
            // Default to MRW
            window.open('https://www.mrw.com.ve/rastreo', '_blank');
        }
    };

    /* ------------------------------------------
       LOGOUT
    ------------------------------------------ */
    window.handleLogout = function () {
        try {
            localStorage.removeItem(PORTAL_USER_KEY);
        } catch (e) { }

        showLogin();

        // Clear input
        const cedulaInput = document.getElementById('login-vat');
        if (cedulaInput) cedulaInput.value = '';

        hideLoginError();
    };

    /* ------------------------------------------
       HELPERS
    ------------------------------------------ */
    function escapeHTML(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    /* ------------------------------------------
       INIT
    ------------------------------------------ */
    document.addEventListener('DOMContentLoaded', function () {
        // Check existing session
        checkExistingSession();

        // Login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', handleLogin);
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                closeOrderDetailModal();
            }
        });

        // Close modal on overlay click
        const modal = document.getElementById('order-detail-modal');
        if (modal) {
            modal.addEventListener('click', function (e) {
                if (e.target === modal) {
                    closeOrderDetailModal();
                }
            });
        }
    });

})();
