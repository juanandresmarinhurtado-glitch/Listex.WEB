const fs = require('fs');

let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// 1. Remove variants-manager-section from wherever it is currently
html = html.replace(/<!-- Variants Manager[\s\S]*?<\/div>\s*<\/div>/, ''); // Remove the injected section entirely

// 2. Insert variants-manager-section directly inside tab-crear
const variantManagerHTML = `
    <!-- Variants Manager (Visible only in Edit Mode) -->
    <div id="variants-manager-section" class="form-section hidden" style="margin-top:30px; grid-column:1 / -1;">
        <h3><ion-icon name="images-outline"></ion-icon> Variantes y Stock</h3>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 15px;">Sube fotos exclusivas para cada variante y actualiza tu inventario disponible en tiempo real.</p>
        <div id="inline-variants-list" style="display:flex; flex-direction:column; gap:15px;"></div>
    </div>
`;

// Find the Create Product form save button and inject before it
const createSaveBtnRegex = /<button type="submit" class="btn btn-primary w-100" id="btn-create-product">/;
if (html.match(createSaveBtnRegex)) {
    html = html.replace(createSaveBtnRegex, variantManagerHTML + '\n                            <button type="submit" class="btn btn-primary w-100" id="btn-create-product">');
}

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("HTML structure fixed.");
