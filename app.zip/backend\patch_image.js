const fs = require('fs');
let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');
const badRegex = /document\.getElementById\('image-preview'\)\.innerHTML = \`<img src="\$\{base64Image\}" \/> <input type="file" id="prod-image-hidden" style="display:none;">\`;\s*document\.getElementById\('prod-image'\)\.removeAttribute\('required'\);/;
const goodCode = "document.getElementById('image-preview').innerHTML = \`<img src=\"\$\{base64Image\}\" /> <input type=\"file\" id=\"prod-image\" accept=\"image/png, image/jpeg, image/webp\" style=\"display:none;\">\`;";
html = html.replace(badRegex, goodCode);
fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log('Image logic patched');
