const fs = require('fs');

let html = fs.readFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', 'utf8');

// The offending line:
// <button onclick="openEditModal(${p.id}, '${p.name.replace(/'/g, \'\\'\')}', ${p.standard_price}, ${p.list_price})"
// Replace it with safe HTML entity
const regex = /<button onclick="openEditModal\(\$\{p\.id\}, '\$\{p\.name\.replace\(.*?\)\}', \$\{p\.standard_price\}, \$\{p\.list_price\}\)"/g;

html = html.replace(regex, `<button onclick="openEditModal(\${p.id}, '\${p.name.replace(/'/g, '&#39;').replace(/\"/g, '&quot;')}', \${p.standard_price}, \${p.list_price})"`);

// Another possible match where the backslashes are slightly different:
html = html.replace(/openEditModal\(\$\{p\.id\}, '\$\{p\.name[^}]*\}'/g, `openEditModal(\${p.id}, '\${p.name.replace(/'/g, '&#39;').replace(/"/g, '&quot;')}'`);

fs.writeFileSync('C:/Users/juan/Desktop/ECOMERCE LISTEX/spatial-aurora/proveedores.html', html, 'utf8');
console.log("Fixed syntax error in proveedores.html");
