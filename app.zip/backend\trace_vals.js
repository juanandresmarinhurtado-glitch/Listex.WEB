const xmlrpc = require('xmlrpc');

const db = 'listex';
const username = 'juanandresmarinhurtado@gmail.com';
const password = 'Seguridad400%';

const common = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/common' });
const models = xmlrpc.createSecureClient({ host: 'listex.odoo.com', port: 443, path: '/xmlrpc/2/object' });

let uid;
common.methodCall('authenticate', [db, username, password, {}], async function (error, resUid) {
    if (error) return console.error("Auth:", error);
    uid = resUid;
    
    function executeKw(model, method, params, kwargs = {}) {
        return new Promise((resolve, reject) => {
            const start = Date.now();
            models.methodCall('execute_kw', [db, uid, password, model, method, params, kwargs], (err, res) => {
                console.log(`[${model}.${method}] took ${(Date.now() - start)/1000}s`);
                if (err) reject(err);
                else resolve(res);
            });
        });
    }

    try {
        console.log("Creating 10 attribute values...");
        const payload = [];
        for (let i = 0; i < 10; i++) {
            payload.push({ attribute_id: 39, name: `Talla Test ${Date.now()}_${i}` });
        }
        
        const vals = await executeKw('product.attribute.value', 'create', [payload]);
        console.log("Vals created:", vals);
        
    } catch (e) {
        console.error("Error:", e);
    }
});
