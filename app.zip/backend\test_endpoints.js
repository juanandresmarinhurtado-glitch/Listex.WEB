const fetch = require('node-fetch');

async function testEndpoints() {
    const baseUrl = 'http://localhost:3000'; // Assuming server is running correctly

    console.log("--- Testing /api/cart/create ---");
    try {
        const createRes = await fetch(`${baseUrl}/api/cart/create`, { method: 'POST' });
        const createData = await createRes.json();
        console.log("Create Result:", createData);

        if (createData.success && createData.order_id) {
            const orderId = createData.order_id;
            console.log("--- Testing /api/cart/add-line ---");
            const addRes = await fetch(`${baseUrl}/api/cart/add-line`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    order_id: orderId,
                    product_id: 31599, // Use a known ID from our JSON sample
                    quantity: 1
                })
            });
            const addData = await addRes.json();
            console.log("Add Result:", addData);
        }
    } catch (e) {
        console.error("Test error:", e.message);
    }
}

testEndpoints();
