/* =============================================
   CART & CHECKOUT LOGIC - Listex Mayorista
   cart.js
   ============================================= */

(function () {
    'use strict';

    const CART_KEY = 'listex_cart';
    const ORDER_KEY = 'listex_odoo_order_id';
    const WHATSAPP_NUMBER = '584244329649';

    /* ------------------------------------------
       CART MANAGEMENT
    ------------------------------------------ */

    /**
     * Add item to cart
     */
    window.addToCart = function (product, variant, quantity, price) {
        const cartData = getCartData();

        const color = variant && variant.color ? variant.color : '';
        const talla = variant && variant.talla ? variant.talla : '';
        const presentacion = variant && variant.presentacion ? variant.presentacion : '';
        const cartKey = (product.nombre || '') + '|' + color + '|' + talla + '|' + presentacion;

        if (cartData[cartKey]) {
            cartData[cartKey].quantity += (quantity || 1);
        } else {
            cartData[cartKey] = {
                productName: product.nombre || '',
                productId: product.id_producto || '',
                color: color,
                talla: talla,
                presentacion: presentacion,
                price: parseFloat(price) || parseFloat(product.precio_base) || 0,
                currency: product.moneda || 'USD',
                quantity: quantity || 1,
                image: product.imagen_url || '',
                category: product.categoria_principal || ''
            };
        }

        saveCartData(cartData);
        updateAllCartBadges();
        return cartData[cartKey];
    };

    /**
     * Remove item from cart
     */
    window.removeFromCart = function (cartKey) {
        const cartData = getCartData();
        delete cartData[cartKey];
        saveCartData(cartData);
        updateAllCartBadges();

        if (typeof renderCartPage === 'function' && document.getElementById('cartItemsList')) {
            renderCartPage();
        }
    };

    /**
     * Update quantity of cart item
     */
    window.updateQuantity = function (cartKey, newQty) {
        const cartData = getCartData();
        if (cartData[cartKey]) {
            newQty = parseInt(newQty) || 1;
            if (newQty < 1) {
                delete cartData[cartKey];
            } else {
                cartData[cartKey].quantity = newQty;
            }
            saveCartData(cartData);
            updateAllCartBadges();
        }

        if (document.getElementById('cartItemsList')) {
            renderCartPage();
        }
    };

    /**
     * Get cart total
     */
    window.getCartTotal = function () {
        const cartData = getCartData();
        let total = 0;
        Object.keys(cartData).forEach(function (key) {
            const item = cartData[key];
            total += (item.price || 0) * (item.quantity || 0);
        });
        return total;
    };

    /**
     * Get all cart items as array
     */
    window.getCartItems = function () {
        const cartData = getCartData();
        const items = [];
        Object.keys(cartData).forEach(function (key) {
            items.push(Object.assign({}, cartData[key], { cartKey: key }));
        });
        return items;
    };

    /**
     * Get total items count
     */
    window.getCartItemCount = function () {
        const cartData = getCartData();
        let count = 0;
        Object.keys(cartData).forEach(function (key) {
            count += cartData[key].quantity || 0;
        });
        return count;
    };

    /**
     * Clear the entire cart
     */
    window.clearCart = function () {
        try {
            localStorage.removeItem(CART_KEY);
            localStorage.removeItem(ORDER_KEY);
        } catch (e) { }
        updateAllCartBadges();
    };

    /* ------------------------------------------
       RENDER CART PAGE
    ------------------------------------------ */

    window.renderCartPage = function () {
        const container = document.getElementById('cartItemsList');
        const summaryEl = document.getElementById('orderSummary');
        const emptyEl = document.getElementById('emptyCart');
        const cartSection = document.getElementById('cartSection');
        const checkoutSection = document.getElementById('checkoutSection');
        const confirmationSection = document.getElementById('confirmationSection');

        const items = getCartItems();

        if (items.length === 0) {
            if (container) container.style.display = 'none';
            if (summaryEl) summaryEl.style.display = 'none';
            if (emptyEl) emptyEl.style.display = 'block';
            if (checkoutSection) checkoutSection.style.display = 'none';

            // Update title badge
            const badge = document.querySelector('.cart-count-badge');
            if (badge) badge.textContent = '0 productos';
            return;
        }

        if (container) container.style.display = 'block';
        if (summaryEl) summaryEl.style.display = 'block';
        if (emptyEl) emptyEl.style.display = 'none';

        // Update title badge
        const badge = document.querySelector('.cart-count-badge');
        if (badge) {
            const totalQty = items.reduce(function (acc, item) { return acc + item.quantity; }, 0);
            badge.textContent = totalQty + ' producto' + (totalQty !== 1 ? 's' : '');
        }

        // Render items
        if (container) {
            let html = '';
            items.forEach(function (item) {
                const subtotal = (item.price || 0) * (item.quantity || 0);
                const variantParts = [];
                if (item.presentacion) variantParts.push(item.presentacion);
                if (item.color && item.color !== 'Surtido') variantParts.push('Color: ' + item.color);
                if (item.talla && item.talla !== 'Surtido') variantParts.push('Talla: ' + item.talla);
                const variantText = variantParts.join(' · ');

                html += '<div class="cart-item" data-key="' + escapeAttr(item.cartKey) + '">';

                // Image
                html += '<div class="cart-item-image">';
                if (item.image) {
                    html += '<img src="' + escapeAttr(item.image) + '" alt="' + escapeAttr(item.productName) + '" onerror="this.parentElement.innerHTML=\'<div class=placeholder-img>📦</div>\'">';
                } else {
                    html += '<div class="placeholder-img">📦</div>';
                }
                html += '</div>';

                // Info
                html += '<div class="cart-item-info">';
                html += '<div class="cart-item-name">' + escapeHTML(item.productName) + '</div>';
                if (variantText) {
                    html += '<div class="cart-item-variant">' + escapeHTML(variantText) + '</div>';
                }
                html += '<div class="cart-item-unit-price">' + formatCartPrice(item.price, item.currency) + ' c/u</div>';
                html += '</div>';

                // Quantity
                html += '<div class="cart-item-quantity">';
                html += '<button onclick="updateQuantity(\'' + escapeAttr(item.cartKey) + '\', ' + (item.quantity - 1) + ')">−</button>';
                html += '<span class="qty-value">' + item.quantity + '</span>';
                html += '<button onclick="updateQuantity(\'' + escapeAttr(item.cartKey) + '\', ' + (item.quantity + 1) + ')">+</button>';
                html += '</div>';

                // Subtotal
                html += '<div class="cart-item-subtotal">' + formatCartPrice(subtotal, item.currency) + '</div>';

                // Remove
                html += '<button class="cart-item-remove" onclick="removeFromCart(\'' + escapeAttr(item.cartKey) + '\')" title="Eliminar">&times;</button>';

                html += '</div>';
            });

            container.innerHTML = html;
        }

        // Update summary
        renderOrderSummary(items);
    };

    /* ------------------------------------------
       RENDER ORDER SUMMARY
    ------------------------------------------ */
    function renderOrderSummary(items) {
        const subtotalEl = document.getElementById('summarySubtotal');
        const shippingEl = document.getElementById('summaryShipping');
        const totalEl = document.getElementById('summaryTotal');

        if (!items) items = getCartItems();

        let subtotal = 0;
        items.forEach(function (item) {
            subtotal += (item.price || 0) * (item.quantity || 0);
        });

        const shipping = subtotal > 100 ? 0 : (items.length > 0 ? 5.00 : 0);
        const total = subtotal + shipping;

        if (subtotalEl) subtotalEl.textContent = formatCartPrice(subtotal, 'USD');
        if (shippingEl) shippingEl.textContent = shipping === 0 ? 'Gratis' : formatCartPrice(shipping, 'USD');
        if (totalEl) totalEl.textContent = formatCartPrice(total, 'USD');
    }

    /* ------------------------------------------
       RENDER CART DRAWER (Mini cart)
    ------------------------------------------ */
    window.renderCartDrawer = function () {
        const drawerItems = document.getElementById('drawerCartItems');
        const drawerTotal = document.getElementById('drawerCartTotal');
        const drawerCount = document.getElementById('drawerCartCount');
        const drawerEmpty = document.getElementById('drawerEmptyMsg');

        const items = getCartItems();

        if (drawerCount) {
            const totalQty = items.reduce(function (acc, item) { return acc + item.quantity; }, 0);
            drawerCount.textContent = totalQty;
        }

        if (items.length === 0) {
            if (drawerItems) drawerItems.innerHTML = '';
            if (drawerEmpty) drawerEmpty.style.display = 'block';
            if (drawerTotal) drawerTotal.textContent = formatCartPrice(0, 'USD');
            return;
        }

        if (drawerEmpty) drawerEmpty.style.display = 'none';

        if (drawerItems) {
            let html = '';
            items.forEach(function (item) {
                const subtotal = (item.price || 0) * (item.quantity || 0);
                html += '<div class="drawer-cart-item">';
                html += '<div class="drawer-item-image">';
                if (item.image) {
                    html += '<img src="' + escapeAttr(item.image) + '" alt="" onerror="this.parentElement.innerHTML=\'📦\'">';
                } else {
                    html += '📦';
                }
                html += '</div>';
                html += '<div class="drawer-item-info">';
                html += '<div class="drawer-item-name">' + escapeHTML(item.productName) + '</div>';
                html += '<div class="drawer-item-qty">' + item.quantity + ' × ' + formatCartPrice(item.price, item.currency) + '</div>';
                html += '</div>';
                html += '<div class="drawer-item-total">' + formatCartPrice(subtotal, item.currency) + '</div>';
                html += '</div>';
            });
            drawerItems.innerHTML = html;
        }

        if (drawerTotal) {
            const total = getCartTotal();
            drawerTotal.textContent = formatCartPrice(total, 'USD');
        }
    };

    /* ------------------------------------------
       CHECKOUT - PROCEED
    ------------------------------------------ */
    window.proceedToCheckout = function () {
        const items = getCartItems();
        if (items.length === 0) {
            if (typeof showToast === 'function') showToast('El carrito está vacío', 'error');
            return;
        }

        const cartSection = document.getElementById('cartSection');
        const checkoutSection = document.getElementById('checkoutSection');

        if (cartSection) cartSection.style.display = 'none';
        if (checkoutSection) {
            checkoutSection.style.display = 'block';
            checkoutSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        // Render checkout summary
        renderCheckoutSummary();
        populateVenezuelanStates();
    };

    function renderCheckoutSummary() {
        const items = getCartItems();
        const container = document.getElementById('checkoutSummaryItems');
        const totalEl = document.getElementById('checkoutTotal');

        if (container) {
            let html = '';
            items.forEach(function (item) {
                const subtotal = (item.price || 0) * (item.quantity || 0);
                html += '<div class="confirmation-summary-item">';
                html += '<span>' + escapeHTML(item.productName) + ' × ' + item.quantity + '</span>';
                html += '<span class="value">' + formatCartPrice(subtotal, item.currency) + '</span>';
                html += '</div>';
            });
            container.innerHTML = html;
        }

        if (totalEl) {
            totalEl.textContent = formatCartPrice(getCartTotal(), 'USD');
        }
    }

    /* ------------------------------------------
       CHECKOUT - SUBMIT
    ------------------------------------------ */
    window.handleCheckoutSubmit = function (event) {
        if (event) event.preventDefault();

        // Get form fields
        const nombre = document.getElementById('checkoutNombre');
        const cedula = document.getElementById('checkoutCedula');
        const telefono = document.getElementById('checkoutTelefono');
        const email = document.getElementById('checkoutEmail');
        const estado = document.getElementById('checkoutEstado');
        const ciudad = document.getElementById('checkoutCiudad');
        const direccion = document.getElementById('checkoutDireccion');
        const notas = document.getElementById('checkoutNotas');

        // Get delivery method
        const deliveryRadios = document.querySelectorAll('input[name="deliveryMethod"]');
        let deliveryMethod = '';
        deliveryRadios.forEach(function (r) {
            if (r.checked) deliveryMethod = r.value;
        });

        // Validate
        let isValid = true;
        const requiredFields = [
            { el: nombre, name: 'nombre' },
            { el: cedula, name: 'cédula' },
            { el: telefono, name: 'teléfono' },
            { el: email, name: 'email' },
            { el: estado, name: 'estado' },
            { el: ciudad, name: 'ciudad' },
            { el: direccion, name: 'dirección' }
        ];

        requiredFields.forEach(function (field) {
            if (field.el) {
                const val = field.el.value.trim();
                if (!val) {
                    field.el.classList.add('error');
                    isValid = false;
                } else {
                    field.el.classList.remove('error');
                }
            }
        });

        if (!deliveryMethod) {
            if (typeof showToast === 'function') showToast('Selecciona un método de entrega', 'error');
            isValid = false;
        }

        if (!isValid) {
            if (typeof showToast === 'function') showToast('Completa todos los campos requeridos', 'error');
            return;
        }

        // Disable button
        const btnSubmit = document.getElementById('btnConfirmOrder');
        if (btnSubmit) {
            btnSubmit.disabled = true;
            btnSubmit.innerHTML = '⏳ Procesando...';
        }

        const items = getCartItems();
        let orderId = null;
        try { orderId = localStorage.getItem(ORDER_KEY); } catch (e) { }

        const checkoutData = {
            order_id: orderId,
            customer: {
                name: nombre ? nombre.value.trim() : '',
                vat: cedula ? cedula.value.trim() : '',
                phone: telefono ? telefono.value.trim() : '',
                email: email ? email.value.trim() : '',
                state: estado ? estado.value : '',
                city: ciudad ? ciudad.value.trim() : '',
                address: direccion ? direccion.value.trim() : '',
                delivery_method: deliveryMethod,
                notes: notas ? notas.value.trim() : ''
            },
            items: items.map(function (item) {
                return {
                    product_id: item.productId,
                    product_name: item.productName,
                    quantity: item.quantity,
                    price: item.price,
                    color: item.color,
                    talla: item.talla,
                    presentacion: item.presentacion
                };
            }),
            total: getCartTotal()
        };

        const backendUrl = (typeof BACKEND_URL !== 'undefined') ? BACKEND_URL : 'http://localhost:3000';

        fetch(backendUrl + '/api/checkout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(checkoutData)
        })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (data && (data.success || data.order_ref)) {
                    showOrderConfirmation(data.order_ref || 'LTX-' + Date.now(), checkoutData, items);
                } else {
                    throw new Error(data.message || 'Error al procesar el pedido');
                }
            })
            .catch(function (err) {
                console.warn('Checkout error, showing confirmation anyway:', err);
                // Show confirmation even if backend fails
                const ref = 'LTX-' + Date.now().toString(36).toUpperCase();
                showOrderConfirmation(ref, checkoutData, items);
            });
    };

    /* ------------------------------------------
       ORDER CONFIRMATION
    ------------------------------------------ */
    function showOrderConfirmation(orderRef, checkoutData, items) {
        const checkoutSection = document.getElementById('checkoutSection');
        const confirmationSection = document.getElementById('confirmationSection');

        if (checkoutSection) checkoutSection.style.display = 'none';
        if (confirmationSection) {
            confirmationSection.style.display = 'block';
            confirmationSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        // Update reference
        const refEl = document.getElementById('confirmationRef');
        if (refEl) refEl.textContent = orderRef;

        // Build confirmation summary
        const summaryContainer = document.getElementById('confirmationItems');
        if (summaryContainer) {
            let html = '';
            items.forEach(function (item) {
                const subtotal = (item.price || 0) * (item.quantity || 0);
                html += '<div class="confirmation-summary-item">';
                html += '<span>' + escapeHTML(item.productName) + ' × ' + item.quantity + '</span>';
                html += '<span class="value">' + formatCartPrice(subtotal, item.currency) + '</span>';
                html += '</div>';
            });
            summaryContainer.innerHTML = html;
        }

        const confirmTotal = document.getElementById('confirmationTotal');
        if (confirmTotal) confirmTotal.textContent = formatCartPrice(getCartTotal(), 'USD');

        // Generate WhatsApp receipt
        const whatsappBtn = document.getElementById('btnWhatsAppConfirm');
        if (whatsappBtn) {
            const message = buildWhatsAppReceipt(orderRef, checkoutData, items);
            const link = 'https://wa.me/' + WHATSAPP_NUMBER + '?text=' + encodeURIComponent(message);
            whatsappBtn.onclick = function () {
                window.open(link, '_blank');
            };
        }

        // Firebase
        try {
            if (typeof logGenerateLead === 'function') {
                logGenerateLead({
                    value: getCartTotal(),
                    currency: 'USD',
                    order_ref: orderRef
                });
            }
        } catch (e) { }

        // Clear cart
        clearCart();
        updateAllCartBadges();
    }

    function buildWhatsAppReceipt(orderRef, checkoutData, items) {
        let msg = '🛒 *PEDIDO LISTEX MAYORISTA*\n';
        msg += '━━━━━━━━━━━━━━━━━\n';
        msg += '📋 Ref: *' + orderRef + '*\n';
        msg += '👤 ' + checkoutData.customer.name + '\n';
        msg += '🪪 Cédula/RIF: ' + checkoutData.customer.vat + '\n';
        msg += '📱 ' + checkoutData.customer.phone + '\n';
        msg += '📧 ' + checkoutData.customer.email + '\n';
        msg += '📍 ' + checkoutData.customer.state + ', ' + checkoutData.customer.city + '\n';
        msg += '🏠 ' + checkoutData.customer.address + '\n';
        msg += '🚚 ' + getDeliveryLabel(checkoutData.customer.delivery_method) + '\n';
        if (checkoutData.customer.notes) {
            msg += '📝 ' + checkoutData.customer.notes + '\n';
        }
        msg += '\n━━━━━━━━━━━━━━━━━\n';
        msg += '📦 *PRODUCTOS:*\n\n';

        let total = 0;
        items.forEach(function (item, idx) {
            const subtotal = (item.price || 0) * (item.quantity || 0);
            total += subtotal;
            msg += (idx + 1) + '. *' + item.productName + '*\n';
            const parts = [];
            if (item.presentacion) parts.push(item.presentacion);
            if (item.color && item.color !== 'Surtido') parts.push('Color: ' + item.color);
            if (item.talla && item.talla !== 'Surtido') parts.push('Talla: ' + item.talla);
            if (parts.length > 0) msg += '   ' + parts.join(' | ') + '\n';
            msg += '   ' + item.quantity + ' × $' + (item.price || 0).toFixed(2) + ' = *$' + subtotal.toFixed(2) + '*\n\n';
        });

        msg += '━━━━━━━━━━━━━━━━━\n';
        msg += '💰 *TOTAL: $' + total.toFixed(2) + ' USD*\n';
        msg += '━━━━━━━━━━━━━━━━━\n';
        msg += '\n_Enviado desde listex.com.ve_';

        return msg;
    }

    function getDeliveryLabel(method) {
        const labels = {
            'envio_nacional': 'Envío nacional (MRW/Zoom)',
            'delivery': 'Delivery local',
            'retiro_tienda': 'Retiro en tienda'
        };
        return labels[method] || method || 'No especificado';
    }

    /* ------------------------------------------
       BACK TO CART (from checkout)
    ------------------------------------------ */
    window.backToCart = function () {
        const cartSection = document.getElementById('cartSection');
        const checkoutSection = document.getElementById('checkoutSection');

        if (checkoutSection) checkoutSection.style.display = 'none';
        if (cartSection) {
            cartSection.style.display = 'block';
            cartSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    };

    /* ------------------------------------------
       VENEZUELAN STATES
    ------------------------------------------ */
    window.populateVenezuelanStates = function () {
        const select = document.getElementById('checkoutEstado');
        if (!select || select.options.length > 1) return;

        const states = [
            'Amazonas', 'Anzoátegui', 'Apure', 'Aragua', 'Barinas',
            'Bolívar', 'Carabobo', 'Cojedes', 'Delta Amacuro', 'Distrito Capital',
            'Falcón', 'Guárico', 'La Guaira', 'Lara', 'Mérida',
            'Miranda', 'Monagas', 'Nueva Esparta', 'Portuguesa', 'Sucre',
            'Táchira', 'Trujillo', 'Yaracuy', 'Zulia'
        ];

        states.forEach(function (state) {
            const option = document.createElement('option');
            option.value = state;
            option.textContent = state;
            select.appendChild(option);
        });
    };

    /* ------------------------------------------
       DELIVERY OPTION SELECTION
    ------------------------------------------ */
    window.selectDeliveryOption = function (radio) {
        const options = document.querySelectorAll('.delivery-option');
        options.forEach(function (opt) {
            opt.classList.remove('selected');
        });
        radio.closest('.delivery-option').classList.add('selected');
    };

    /* ------------------------------------------
       ODOO SYNC
    ------------------------------------------ */
    window.createOdooOrder = function () {
        const backendUrl = (typeof BACKEND_URL !== 'undefined') ? BACKEND_URL : 'http://localhost:3000';
        return fetch(backendUrl + '/api/cart/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (data && data.order_id) {
                    try { localStorage.setItem(ORDER_KEY, data.order_id); } catch (e) { }
                    return data.order_id;
                }
                return null;
            })
            .catch(function (err) {
                console.warn('Error creating Odoo order:', err);
                return null;
            });
    };

    window.addLineToOdoo = function (orderId, product) {
        const backendUrl = (typeof BACKEND_URL !== 'undefined') ? BACKEND_URL : 'http://localhost:3000';
        return fetch(backendUrl + '/api/cart/add-line', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                order_id: orderId,
                product_id: product.productId || product.id_producto,
                product_name: product.productName || product.nombre,
                quantity: product.quantity || 1,
                price_unit: product.price || product.precio_base
            })
        })
            .then(function (res) { return res.json(); })
            .catch(function (err) {
                console.warn('Error adding line to Odoo:', err);
            });
    };

    /* ------------------------------------------
       HELPERS
    ------------------------------------------ */
    function getCartData() {
        try {
            const raw = localStorage.getItem(CART_KEY);
            return raw ? JSON.parse(raw) : {};
        } catch (e) {
            return {};
        }
    }

    function saveCartData(data) {
        try {
            localStorage.setItem(CART_KEY, JSON.stringify(data));
        } catch (e) {
            console.warn('Error saving cart:', e);
        }
    }

    function updateAllCartBadges() {
        const count = getCartItemCount();
        const badges = document.querySelectorAll('.cart-badge, .cart-count, #cartBadge');
        badges.forEach(function (badge) {
            badge.textContent = count;
            if (badge.classList.contains('cart-badge') || badge.id === 'cartBadge') {
                badge.style.display = count > 0 ? 'flex' : 'none';
            }
        });
    }

    function formatCartPrice(amount, currency) {
        if (typeof formatPrice === 'function') {
            return formatPrice(amount, currency);
        }
        return '$' + parseFloat(amount || 0).toFixed(2);
    }

    function escapeHTML(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function escapeAttr(str) {
        if (!str) return '';
        return str.replace(/&/g, '&amp;').replace(/'/g, '&#39;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    /* ------------------------------------------
       INIT
    ------------------------------------------ */
    document.addEventListener('DOMContentLoaded', function () {
        updateAllCartBadges();

        // If on cart page, render
        if (document.getElementById('cartItemsList')) {
            renderCartPage();
        }

        // Populate states if on checkout
        if (document.getElementById('checkoutEstado')) {
            populateVenezuelanStates();
        }
    });

})();
